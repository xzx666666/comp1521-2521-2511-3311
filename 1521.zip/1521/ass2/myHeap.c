// COMP1521 18s1 Assignment 2
// Implementation of heap management system

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "myHeap.h"

// minimum total space for heap
#define MIN_HEAP  4096
// minimum amount of space for a free Chunk (excludes Header)
#define MIN_CHUNK 32

#define ALLOC     0x55555555
#define FREE      0xAAAAAAAA

typedef unsigned int uint;   // counters, bit-strings, ...

typedef void *Addr;          // addresses

typedef struct {             // headers for Chunks
   uint  status;             // status (ALLOC or FREE)
   uint  size;               // #bytes, including header
} Header;

static Addr  heapMem;        // space allocated for Heap
static int   heapSize;       // number of bytes in heapMem
static Addr *freeList;       // array of pointers to free chunks
static int   freeElems;      // number of elements in freeList[]
static int   nFree;          // number of free chunks


// initialise heap
int initHeap(int size)
{
    //set the size into right size
    if(size < MIN_HEAP){
        heapSize = MIN_HEAP;
        nFree = 1;
        freeElems = MIN_HEAP/MIN_CHUNK;
    }
    else if(size%4 != 0){
        heapSize = size + 4-size%4;
        nFree = 1;
        freeElems = heapSize/MIN_CHUNK;
    }
    else{
        heapSize = size;
        nFree = 1;
        freeElems = size/MIN_CHUNK;
    }
    //malloc the heapMem with the size
   heapMem = malloc(heapSize);
   if(heapMem == NULL){
        fprintf(stderr, "Can't initialise Memory\n");
        exit(EXIT_FAILURE);
        return -1;
   }
   //set the chunk 
   Header *h = (Header *)(Addr)(char *)heapMem;
   h->status = FREE;
   h->size = heapSize;
   //malloc the freeList 
   freeList = malloc(freeElems*sizeof(Addr));
   
   if(freeList == NULL){
        fprintf(stderr, "Can't initialise Memory\n");
        exit(EXIT_FAILURE);
        return -1;
   }
   //set the first element in freelist
   freeList[0] = (Addr)(char *)heapMem+sizeof(Header);
   return 0; // this just keeps the compiler quiet
}

// clean heap
void freeHeap()
{
   free(heapMem);
   free(freeList);
}

// allocate a chunk of memory
void *myMalloc(int size)
{
   Addr curr = (Addr)((char *)heapMem);
   Addr endHeap = (Addr)((char *)heapMem +heapSize);
   Addr i  = NULL;
   Header *fre = (Header*)curr;
   Header *allo = (Header*)curr;
   int n=0;
   int j=0;
   int len;
   //set the correct 
   if(size<1){
        return NULL;
   }
   if(size%4!=0){
        size = size +4-size%4;
   }
   //loop the first addr to end addr
   while(curr < endHeap){
        fre = (Header*)curr;
        //the condition chunk is free
        //make the chunk into alloc
        //if the chunk size less than the size 
        //find another free chunk where the chunk is meet the condition
        if(fre->status == FREE){
            
             if( fre->size >= (size+sizeof(Header)+MIN_CHUNK) && fre->size >= (size+sizeof(Header))){
                len = fre->size;
                allo = fre;
                allo->status = ALLOC;
                allo->size = size+sizeof(Header);
                
                fre = (Header*)(Addr)((char *)curr + allo->size);
                
                fre->status = FREE;
                fre->size = len-allo->size;
                if(i==NULL){
                    i = (Addr)((char *)curr+sizeof(Header));
                }
                freeList[n] = (Addr)((char *)curr+allo->size+sizeof(Header));
                
                break;
            
            }
            else if(fre->size < (size+sizeof(Header)+MIN_CHUNK)&& fre->size >= (size+sizeof(Header))){
                fre->status = ALLOC;
                size = size-fre->size;
                i = (Addr)((char *)curr+sizeof(Header));
                //set the freelist
                for(j = n;j < nFree;j++){
                    freeList[j] = freeList[j+1];
                
                }
                nFree--;
                
            }
            n++;
        }
    
        curr = (Addr)((char*)fre+fre->size);
    
   }
        
   
   return i; // this just keeps the compiler quiet
}

// free a chunk of memory
void myFree(void *block)
{
   if(block == NULL){
        fprintf(stderr,"Attempt to free unallocated chunk\n");
        exit(1);
   }
   //set free status of header where the address is located in block 
   Addr e = (Addr)(char*)block-sizeof(Header);
   Header *curr = (Header *)e;
   curr->status = FREE;
   //get the start of Memory and end of Memory
   Addr first = (Addr)((char *)heapMem);
   Addr endHeap = (Addr)((char *)heapMem +heapSize);
   //get the pointer of fre and n , init the addr next
   Addr next ;
   Header *pre;
   Header *n;
   int counter = 0;
   int i = 0;
   //to find the number of free element 
   //to find the header of next pointer is equal to curr
   //to find if curr is first header pointer 
   while(first < endHeap){
        pre = (Header*)first;
        if(pre->status == FREE) {
            counter++;
        }
        next = (Addr)((char*)pre+pre->size);
        n = (Header *)next;
        if(n == curr)break;
        if(curr == pre) break;
        first = (Addr)((char*)pre+pre->size);
        
   }
   //get the next pointer after the pointer of fre
    next = (Addr)((char*)curr+curr->size);
    n = (Header *)next;
    //the condition if the chunk next is free and the pre is not free 
    if(pre!=curr && n->status == FREE && pre->status != FREE){
       
        //make two chunk into one
        curr->size = curr->size+n->size;
        for(i=counter+1;i < nFree;i++){
            freeList[i] = freeList[i+1];
        
        }
        nFree--;
    
    }
    //the condition if the chunk next is not free and the pre is free 
    else if(pre != curr && pre->status == FREE && n->status != FREE){
        //make two chunk into one
        pre->size = pre->size +curr->size;
        for(i=counter-1;i < nFree;i++){
            freeList[i] = freeList[i+1];
        
        }
        nFree--;
    
    }
    //the condition if curr in the first addr
    else if(pre == curr && pre->status == FREE && n->status == FREE){
        //make two chunk into one
        pre->size = pre->size+n->size;
        for(i=0;i < nFree;i++){
            freeList[i] = freeList[i+1];
        
        }
        nFree--;
    }
    //the condition if the chunk next is free and the pre is free 
    else if(pre != curr && pre->status == FREE && n->status == FREE){
        //make three chunk into one
        pre->size = pre->size +curr->size +n->size;
        for(i=counter-1;i < nFree;i++){
            freeList[i] = freeList[i+2];
        
        }
        nFree-=2;
    }
          
      
   
}

// convert pointer to offset in heapMem
int  heapOffset(void *p)
{
   Addr heapTop = (Addr)((char *)heapMem + heapSize);
   if (p == NULL || p < heapMem || p >= heapTop)
      return -1;
   else
      return p - heapMem;
}

// dump contents of heap (for testing/debugging)
void dumpHeap()
{
   Addr    curr;
   Header *chunk;
   Addr    endHeap = (Addr)((char *)heapMem + heapSize);
   int     onRow = 0;  
   curr = heapMem;
   while (curr < endHeap) {
   
      char stat;
      chunk = (Header *)curr;
      switch (chunk->status) {
      case FREE:  stat = 'F'; break;
      case ALLOC: stat = 'A'; break;
      default:    fprintf(stderr,"Corrupted heap %08x\n",chunk->status); exit(1); break;
      }
      printf("+%05d (%c,%5d) ", heapOffset(curr), stat, chunk->size);
      onRow++;
      if (onRow%5 == 0) printf("\n");
      curr = (Addr)((char *)curr + chunk->size);
   }
   
   if (onRow > 0) printf("\n");
}

