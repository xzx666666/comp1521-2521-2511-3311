#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void){
    int *s;
    s = malloc(8);
    printf("%d\n",sizeof(s));
    return 0;
}
