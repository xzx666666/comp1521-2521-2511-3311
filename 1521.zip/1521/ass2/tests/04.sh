# alloc/free and final free from unallocated
./test3 4000 < data1 2>&1
