# alloc/frees
./test3 4000 < data4
