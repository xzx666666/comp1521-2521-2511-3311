# deleting most of a small tree
./test4 < tree1
