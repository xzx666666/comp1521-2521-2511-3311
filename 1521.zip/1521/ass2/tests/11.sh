# inserts/deletes into a small tree
./test4 < tree2
