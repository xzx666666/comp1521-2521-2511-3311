./stu tests/s4.dat
