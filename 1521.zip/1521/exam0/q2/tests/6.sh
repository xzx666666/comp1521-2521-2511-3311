./stu tests/s6.dat
