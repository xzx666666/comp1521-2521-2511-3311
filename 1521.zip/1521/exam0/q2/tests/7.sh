./stu tests/s7.dat
