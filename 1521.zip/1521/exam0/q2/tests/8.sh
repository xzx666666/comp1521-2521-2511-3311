./stu tests/s8.dat
