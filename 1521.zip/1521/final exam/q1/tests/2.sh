exe tests/a2.s
