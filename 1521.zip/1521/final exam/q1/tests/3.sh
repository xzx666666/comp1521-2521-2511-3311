exe tests/a3.s
