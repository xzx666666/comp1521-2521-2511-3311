exe tests/a5.s
