// Copy input to output
// COMP1521 18s1

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
void copy(FILE *, FILE *);

int main(int argc, char *argv[])
{
	copy(stdin,stdout);
	return EXIT_SUCCESS;
}

// Copy contents of input to output, char-by-char
// Assumes both files open in appropriate mode

void copy(FILE *input, FILE *output)
{
    if(input == NULL||output == NULL){
        exit(1);
    }
    char in;
    int n =0;
    
    while((n = fscanf(input,"%c",&in)) == 1){
    
        fprintf(output,"%c",in);
       
    }
    
}

