"./$1" < tests/1.txt
