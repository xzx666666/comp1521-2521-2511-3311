"./$1" < tests/3.txt
