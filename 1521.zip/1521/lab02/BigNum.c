// BigNum.h ... LARGE positive integer values
int isNumber(char c);

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
#include "BigNum.h"

// Initialise a BigNum to N bytes, all zero
void initBigNum(BigNum *n, int Nbytes)
{
   
   n->bytes = malloc(Nbytes*sizeof(Byte));
   n->nbytes = Nbytes;
   
}

// Add two BigNums and store result in a third BigNum
void addBigNums(BigNum n, BigNum m, BigNum *res)
{
  int i,num,change=0;
  
  if(m.nbytes>res->nbytes){
    res->bytes = realloc(res->bytes,m.nbytes);
    res->nbytes = n.nbytes;
  }
  else if(n.nbytes>res->nbytes){
    res->bytes = realloc(res->bytes,n.nbytes);
    res->nbytes = n.nbytes;
  }
  
  for(i = 0;i<res->nbytes;i++){
    num = n.bytes[i]+m.bytes[i]+change;
    
    if(num<10){
        change = 0;
        res->bytes[i] = num;
    }
    else{
        change = 1;
        res->bytes[i] = num%10;
    }
  }
  
 if(change == 1){
    res->bytes = realloc(res->bytes,res->nbytes+1);
    res->bytes[res->nbytes] = 1;
    res->nbytes++;
  }
}

// Set the value of a BigNum from a string of digits
// Returns 1 if it *was* a string of digits, 0 otherwise
int scanBigNum(char *s, BigNum *n)
{

    
    int i,j = strlen(s)-1;
    //check the string is or not digits
    for(i=strlen(s)-1;i>=0;i--){
        if(isNumber(s[i])==0) return 0;
    
    }
    /*if(j<n->nbytes)
        n->bytes = realloc(n->bytes,j);*/
    if(n->nbytes<j+1){ 
        n->bytes = realloc(n->bytes,j+1);
        
        n->nbytes = j+1;
    }
   
    i=0;
    while(i<n->nbytes){
        
       if(j<0) {
            
            break;
       }
       if(s[j]==' '){
            j--;
            continue;
       }
        
        n->bytes[i] = s[j]-'0';
        i++;
        j--;
    }
    
    //n->nbytes = strlen(s);
    return 1;
}

// Display a BigNum in decimal format
void showBigNum(BigNum n)
{
    int i,change = 0;
    for(i=n.nbytes-1;i>=0;i--){
        if(change ==0 && n.bytes[i]==0){
            
        }
        else{
            change = 1;
            printf("%d",n.bytes[i]);
       }
    }
    
   
}
int isNumber(char c)  
{  
    if((c>='0'&&c<='9')||c==' ')  return 1;
    
    return 0;
}  
