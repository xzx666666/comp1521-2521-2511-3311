// where_are_the_bits.c ... determine bit-field order
// COMP1521 Lab 03 Exercise
// Written by ...

#include <stdio.h>
#include <stdlib.h>
union num{
    int value;
    struct _bit_fields {
       unsigned int a : 4,
                    b : 8,
                    c : 20;
    }bits;
};

int main(void)
{
  
   union num nums;
   nums.value = 1;
   printf("value = %d, a = %d,b = %d,c = %d\n",nums.value,nums.bits.a,nums.bits.b,nums.bits.c);
   return 0;
}
