echo 5 | /usr/bin/spim -file fac1.s
