echo 12 | /usr/bin/spim -file fac1.s
