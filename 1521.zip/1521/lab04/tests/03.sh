echo 20 | /usr/bin/spim -file fac1.s
