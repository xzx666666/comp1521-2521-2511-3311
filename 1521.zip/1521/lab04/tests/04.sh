echo hello | /usr/bin/spim -file fac1.s
