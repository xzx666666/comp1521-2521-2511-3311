echo 12 | /usr/bin/spim -file fac2.s
