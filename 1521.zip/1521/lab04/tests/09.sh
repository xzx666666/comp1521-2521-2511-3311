echo hello | /usr/bin/spim -file fac2.s
