echo 5 | /usr/bin/spim -file fac3.s
