echo 12 | /usr/bin/spim -file fac3.s
