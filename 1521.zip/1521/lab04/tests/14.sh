echo hello | /usr/bin/spim -file fac3.s
