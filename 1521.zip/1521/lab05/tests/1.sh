cat tests/data1.s main.s print.s mult.s > exe.s
~cs1521/bin/spim -file exe.s > tests/1.out
