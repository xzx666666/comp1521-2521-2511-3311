cat tests/data6.s main.s print.s mult.s > exe.s
~cs1521/bin/spim -file exe.s > tests/6.out
