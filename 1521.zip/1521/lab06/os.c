#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
int main(void)
{
int handle;
char msg[]="This is a test";
char ch;
int i; 
/*create a file*/
handle=open("TEST.$$$",O_CREAT|O_RDWR,S_IREAD|S_IWRITE);
/*write some data to the file*/
write(handle,msg,strlen(msg));
/*seek to the begining of the file*/
if((i=lseek(handle,0,SEEK_SET))==-1){
    printf("error\n");
}
 printf("%d\n",i);
/*reads chars from the file until we hit EOF*/
do
{
read(handle,&ch,1);
printf("%c",ch);
}while(!EOF);
close(handle);
printf("\n");
return 0;
}

