#include <stdio.h>
int main(void){
    printf("%02x\n",0xFF & 0x0);
    return 0;
}
