./vmsim 4 4 < tests/trace01
