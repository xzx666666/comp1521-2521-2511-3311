./vmsim 3 3 < tests/trace02
