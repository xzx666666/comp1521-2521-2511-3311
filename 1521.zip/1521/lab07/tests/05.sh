./vmsim 2 2 < tests/trace03
