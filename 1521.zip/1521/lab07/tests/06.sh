./vmsim 2 1 < tests/trace03
