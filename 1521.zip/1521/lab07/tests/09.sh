./vmsim 3 2 < tests/trace05
