./vmsim 3 1 < tests/trace05
