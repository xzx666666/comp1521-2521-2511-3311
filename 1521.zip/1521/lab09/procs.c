// COMP1521 17s2 Lab08 ... processes competing for a resource
 
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

#define MAXLINE BUFSIZ

void copyInput(char *);

void handler (int sig) {
  printf ("Got signal %d\n", sig);
}

int  main(void) {
  struct sigaction act;
  memset (&act, 0, sizeof(act));
  act.sa_flags |= SA_RESTART;
  act.sa_handler = &handler;
  if (fork() != 0) {
  
    printf("return: %d\n", ret);
    copyInput("Parent");
  }
  else if (fork() != 0) {
    copyInput("Child");
  }
  else {
    copyInput("Grand-child");
  }
  return 0;
}

void copyInput(char *name)
{
  pid_t mypid = getpid();
  char  line[MAXLINE];
  printf("%s (%d) ready\n", name, mypid);
  while (fgets(line, MAXLINE, stdin) != NULL) {
    printf("%s: %s", name, line);
    sleep(1);
  }
  printf("%s quitting\n", name);
  return;
}
