
public  class Edges implements Comparable<Edges>{
	private int time;
	private Node dest;
	private Node src;
	private int distance;

	public Edges(int time,Node src,Node dest) {
		this.time = time;
		this.dest = dest;
		this.src = src;
		setdis();
	}
	/**
	 * get distance for two node add the days of src node
	 */
	public void setdis() {
		distance = src.getdays()+this.time;
		
	}
	public int getdis() {
		return this.distance;
	}
	public int gettime() {
		return this.time;
	}
	public Node getdest() {
		return this.dest;
	}
	public Node getsrc() {
		return this.src;
	}
	/**
	 * whether the edges e1 equal to curredges
	 * @param e1
	 * @return
	 */
	public boolean equals(Edges e1) {
		if(this.dest.equals(e1.getdest())) {
			return true;
		}
		return false;
	}
	/**
	 * a compartor with increasing order
	 */
	public int compareTo(Edges edges) {
		return this.time - edges.time;
	}
}
