import java.util.*;

public class Node{
	private String name;
	private int days;
	private ArrayList<Edges> edges;
	public Node(String name,int days) {
		this.name = name;
		this.days = days;
		edges = new ArrayList<Edges>();
	}
	public String getname() {
		return this.name;
	}
	public int getdays() {
		return this.days;
	}
	public void addEdge(int time,Node src,Node dest) {
		Edges e = new Edges(time,src,dest);
		edges.add(e);
	}
	public ArrayList<Edges> getEdges(){
		return edges;
	}
	/**
	 * check the node n is or not equal to the current node
	 * @param n
	 * @return
	 */
	public boolean equals(Node n) {
		if(this.name.equals(n.getname())) {
			return true;
		}
		return false;
	}
	
}
