
public class Ship {
	private Node src;
	private Node dest;
	private int distance;
	public Ship( Node src, Node dest) {
		this.src = src;
		this.dest = dest;
		setdis();
	}
	/**
	 * set the distance between src and dest add the days of src
	 */
	public void setdis() {
		int i;
		for(i=0;i<this.src.getEdges().size();i++) {
			
			if(this.src.getEdges().get(i).getdest().equals(this.dest)) {
				this.distance = src.getEdges().get(i).gettime()+this.src.getdays();
				
			}
		}
	}
	/**
	 * return boolean ship s equal the current ship
	 * @param s
	 * @return
	 */
	public boolean equals(Ship s) {
		if(this.src.equals(s.getsrc())&&this.dest.equals(s.getdest())) {
			return true;
		}
		return false;
	}
	public int getdis() {
		return this.distance;
	}
	public Node getsrc() {
		return this.src;
	}
	public Node getdest() {
		return this.dest;
	}
	/**
	 * get edges from ship
	 * @return
	 */
	public Edges getedge() {
		int i;
		for(i=0;i<this.src.getEdges().size();i++) {
			
			if(this.src.getEdges().get(i).getdest().equals(this.dest)) {
				return src.getEdges().get(i);
				
			}
		}
		return null;
	}
}
