import java.io.*;
import java.util.*;
public class ShipmentPlanner {
	private static ArrayList<Node> node = new ArrayList<Node>();
    private static ArrayList<Ship> unship = new ArrayList<Ship>();
    private static ArrayList<Ship> ship = new ArrayList<Ship>();
    private static int n_node = 0;
    private static Queue<leaves> PQopen = new PriorityQueue<leaves>(10000,new leavesLengthComparator());
    
   /**
    * get each refuelling node 
    * add the node into nodelist
    * @param s
    */
	public void refuelling(String s[]) {
		Node n = new Node(s[2],Integer.parseInt(s[1]));
		node.add(n);
	}
	/**
	 * get each edges and time of edges
	 * add the edges and time in edgeslist and add the edgeslist into each node of nodelist
	 * @param c
	 */
	public void time(String c[]) {
		int i,j;
		for(i=0;i<node.size();i++) {
				if(c[2].equals(node.get(i).getname())) {
					for(j=0;j<node.size();j++) {
						if(c[3].equals(node.get(j).getname())) {
							node.get(i).addEdge(Integer.parseInt(c[1]),node.get(i),node.get(j));
							node.get(j).addEdge(Integer.parseInt(c[1]),node.get(j),node.get(i));
						}
					}
				}
			}
	}
	/**
	 * add each ship into shiplist
	 * @param c
	 */
	public void Ship(String c[]) {
		int i,j;
		for(i=0;i<node.size();i++) {
				if(c[1].equals(node.get(i).getname())) {
					for(j=0;j<node.size();j++) {
						if(c[2].equals(node.get(j).getname())) {
							Ship sh = new Ship(node.get(i),node.get(j));
							unship.add(sh);
							
						}
					}
				}
			}
	}
	/**
	 * find a node which the name is equal to String s
	 * @param s
	 * @return
	 */
	static public Node findNode(String s) {
		int i;
		for(i=0;i<node.size();i++) {
			if(node.get(i).getname().equals(s)) {
				return node.get(i);
			}
		}
		return null;
	}
	/**
	 * find a edges which node src is equal s and node dest is equal d
	 * @param s
	 * @param d
	 * @return
	 */
	static public Edges findedge(Node s,Node d) {
		int i;
		for(i=0;i<s.getEdges().size();i++) {
			
			if(s.getEdges().get(i).getdest().equals(d)) {
				return s.getEdges().get(i);
			}
			
		}
		return null;
	}
	/**
	 * sort the edges by increase order in each node
	 */
	public void sortedges() {
		int i;
		for(i=0;i<node.size();i++) {
			Collections.sort(node.get(i).getEdges());
		}
		
	}
	/**
	 * removeship from the shiplist with excatly Ship
	 * @param s
	 * @param unfinish
	 */
	static public void removeship(Ship s,ArrayList<Ship> unfinish) {
		int i;
		for(i=0;i<unfinish.size();i++) {
			if(s.equals(unfinish.get(i))) {
				unfinish.remove(i);
				break;
			}
		}
		
	}
	/**
	 * add the ship to oldleaves and return a newleaves
	 * @param s
	 * @param oldleaves
	 * @return
	 */
	static public leaves ship_to_leaves(Ship s,leaves oldleaves) {
		ArrayList<Ship> finish = new ArrayList<Ship>();
	    ArrayList<Ship> unfinish = new ArrayList<Ship>();
	    //let the old ship into new ship
	    for(Ship currship:oldleaves.getunfinish()) {
	    		unfinish.add(currship);
	    }
	    for(Ship currship:oldleaves.getfinish()) {
    			finish.add(currship);
	    }
	    //add the ship s in to finish shiplist
	    finish.add(s);
	    //remove the ship s from unfinish shiplist
	    removeship(s,unfinish);
	    int fn;
	    int gn = oldleaves.getgn();
	    Node n = s.getdest();
	    int hn = findhn(n,unfinish);
	    //get the gn by add ship distance
	    if(oldleaves.getcurrnode().equals(s.getsrc())) {
	    		gn = gn+ s.getdis();
	    }
	    //get the gn by add ship distance and distance of edges 
	    else {
	    		gn = gn + s.getdis()+findedge(oldleaves.getcurrnode(),s.getsrc()).getdis();
	    }	
	    fn = gn + hn;
	    leaves newleaves = new leaves(fn,gn,hn,n,node,unfinish,finish);
		return newleaves;
	}
	/**
	 * give a hn that mean the distance of the next colesest ship add the distance of ship
	 * @param currnode
	 * @param unfinish
	 * @return
	 */
	static int findhn(Node currnode,ArrayList<Ship> unfinish) {
		//find the nearest ship path
		int dis=0,i;
		Queue<Integer> min = new PriorityQueue<Integer>();
		ArrayList<Ship> newunfinish = new ArrayList<Ship>();
		
		for(Ship currship:unfinish) {
			newunfinish.add(currship);
		}
		
		for(i=0;i<unfinish.size();i++) {
			if(currnode.equals(unfinish.get(i).getsrc())) {
				min.add(unfinish.get(i).getdis());
				//add the distance in to queue
			}
			else {
				//add the distance in to queue
				dis = unfinish.get(i).getdis()+findedge(currnode,unfinish.get(i).getsrc()).getdis();
				min.add(dis);
			}
			
		}
		if(min.size()!=0) {
			//get the min distance
			dis = min.poll();
			
		}
		
		return dis;
	}
	/**
	 * return most effcient ship path in leaves 
	 * use astar search to find most sorted fn
	 * use fn by increasing order in priorityqueue
	 * @return
	 */
	public leaves Astar() {
		int fn = 0,gn = 0,hn = 0;
		Node currnode = findNode("Sydney");
		//get the new leaves from sydney
		leaves i = new leaves(fn,gn,hn,currnode,node,unship,ship);//sydney  ship 0 unship 4
		PQopen.add(i);
		i = PQopen.poll();
		//while until the loop return 
		while(true) {
			//add each ship into the queue list
			for(Ship s : i.getunfinish()) {
				n_node++;
				leaves o = ship_to_leaves(s,i);
				PQopen.add(o);
				
			}
			
			i = PQopen.poll();
			//when the unfinishship size is 0 return the leaves
			if(i.getunfinish().size()==0) {
				return i;
			}
			
		}
        
	}
	/**
	 * print the path of ship by leaves finalpath
	 * Start at Sydney
	 * @param finalpath
	 */
	
	public void Print(leaves finalpath) {
		int i=0;
        Node n = findNode("Sydney");
        System.out.println(n_node +" nodes expanded");
        System.out.println("cost = "+finalpath.getfn());
        Ship s = finalpath.getfinish().get(0);
        
        while(i<finalpath.getfinish().size()) {
        		// when the curr node in sydney but the ship node not in sydney
       	 	if(i==0&&!n.equals(finalpath.getfinish().get(i).getsrc())) {
       	 		System.out.println("Ship "+n.getname()+" to "+finalpath.getfinish().get(i).getsrc().getname());
       	 	}
       	 	//when the curr node in next ship of node src and not the first ship
   	 		if(!s.getdest().equals(finalpath.getfinish().get(i).getsrc())&&i!=0) {
   	 			System.out.println("Ship "+s.getdest().getname()+" to "+finalpath.getfinish().get(i).getsrc().getname());
   	 		}
   	 		
   	 		System.out.println("Ship "+finalpath.getfinish().get(i).getsrc().getname()+" to "+finalpath.getfinish().get(i).getdest().getname());
       	 	
       	 	s = finalpath.getfinish().get(i);
       	 	i++;
        }
	}
	public static void main(String args[]) {
		ShipmentPlanner shipmentP = new ShipmentPlanner();
		Scanner sc = null;
	     try
	     {
	         sc = new Scanner(new File(args[0]));    // args[0] is the first command line argument
	         
	         while(sc.hasNextLine()) {
	        	 	String s = sc.nextLine();
	        	 	String[] c = s.split(" ");
	        	 	for(String ch : c) {
	        	 		if(ch.equals("Refuelling")) {
	        	 			shipmentP.refuelling(c);
	        	 		}
	        	 		else if(ch.equals("Time")) {
	        	 			shipmentP.time(c);
	        	 		}
	        	 		else if(ch.equals("Shipment")) {
	        	 			shipmentP.Ship(c);
	        	 		}
	
	        	 	}
	         }
	         
	         shipmentP.sortedges();
	         shipmentP.Print(shipmentP.Astar());
	         
	     }
	     catch (FileNotFoundException e)
	     {
	         System.out.println(e.getMessage());
	     }
	     finally
	     {
	         if (sc != null) sc.close();
	     }
	}
	
	
}
