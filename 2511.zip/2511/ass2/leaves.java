import java.util.ArrayList;

public class leaves {
	private int fn;
	private int gn;
	private int hn;
	private Node currnode;
	private ArrayList<Node> graph;
	private ArrayList<Ship> finishship;
	private ArrayList<Ship> unfinishship;
	public leaves(int fn,int gn,int hn,Node currnode,ArrayList<Node> graph,ArrayList<Ship> unfinishship,ArrayList<Ship> finishship) {
		this.fn = fn;
		this.gn = gn;
		this.hn = hn;
		this.currnode = currnode;
		this.graph = graph;
		this.finishship = finishship;
		this.unfinishship = unfinishship;
	}
	public int getfn() {
		return this.fn;
	}
	public int getgn() {
		return this.gn;
	}
	public int gethn() {
		return this.hn;
	}
	public Node getcurrnode() {
		return this.currnode;
	}
	public  ArrayList<Node> getgraph() {
		return this.graph;
	}
	public ArrayList<Ship> getfinish() {
		return this.finishship;
	}
	public ArrayList<Ship> getunfinish() {
		return this.unfinishship;
	}
	
}

