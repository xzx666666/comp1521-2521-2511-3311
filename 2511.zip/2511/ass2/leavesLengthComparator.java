import java.util.Comparator;

public class leavesLengthComparator implements Comparator<leaves>{
	public int compare(leaves x, leaves y)
    {
        
        if (x.getfn() < y.getfn())
        {
            return -1;
        }
        if (x.getfn() > y.getfn())
        {
            return 1;
        }
        return 0;
    }
}
