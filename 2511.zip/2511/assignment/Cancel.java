
public class Cancel {
	private int id;
	private boolean state;
	public Cancel(int id,boolean state) {
		this.id = id;
		this.state = state;
	}
	public boolean getstate(){
		return state;
	}
	public void setstate(boolean state){
		this.state = state;
	}
	public int getid() {
		return this.id;
	}
	public boolean rejectbook(Request r,Session s) {
		if(r.getid() == id) {
			if(s.cancelSeat(r.getticket())) {
				 return true;
			}
			
		}
		return false;
	}
}
