
public class Change {
	private int id;
	private int cinema;
	private String time;
	private int ticket;
	private boolean state;
	public Change(int id,int cinema,String time, int ticket,boolean state) {
		this.id = id;
		this.cinema = cinema;
		this.time = time;
		this.ticket = ticket;
		this.state = state;
		
	}
	public void setstate(boolean state) {
		 this.state = state;
	}
	public boolean getstate() {
		return this.state;
	}
	public int getid() {
		return this.id;
	}
	public int getcinema() {
		return this.cinema;
	}
	public String gettime() {
		return this.time;
	}
	public int getticket() {
		return this.ticket;
	}
	public Request responR() {
		Request r = new Request(id,cinema,time,ticket,state);
		return r;
	}
	public boolean responC(Request r,Session s) {
	Cancel c = new Cancel(this.id,this.state);
	
		if(c.rejectbook(r, s)) {
			return true;
		}
		
		return false;
	}
}
