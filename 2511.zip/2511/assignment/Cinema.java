
public class Cinema {
	private String row;
	private int cinema;
	private int seat;
	private int useticket;
     public Cinema(int cinema, String row ,int seat,int useticket) {
    	     this.cinema = cinema;
    	     this.row = row;
    	     this.seat = seat;
    	     this.useticket = useticket;
     }
     public int getCinema() {
    	 	return this.cinema;
     }
     public String getRow() {
    	     return this.row;
     }
     public int getSeat() {
    	 	return this.seat;
     }
    
     public int getUseticket() {
    	 	return this.useticket;
     }
     
     public boolean bookSeat(int ticket) {
    	    if((seat-useticket)<ticket||ticket<0) {
    		  return false;
    	    }
    	    
    	 	useticket = useticket +ticket;
    	 	return true;
    	 	
     }
     
     public boolean cancelSeat(int ticket) {
    	 	if(useticket<0) {
    	 		return false;
    	 	}
    	 	
    	 	useticket = useticket-ticket;
    	 	return true;
     }
     
}
