import java.util.*;
import java.io.*;
//cinema booking sysytem have four part
//eg, booking change cancel and print
//start form input.txt and print in outfut.txt

public class CinemaBookingSystem {
	
	public static void main(String args[]) {
		ArrayList<ArrayList<String>> list = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listRequest = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> clonelist = new ArrayList<ArrayList<String>>();
		Scanner sc = null;
		String str1;
		String comb = "";
		int start,end,length;
		int i,j, k,m;
		try {
		    //start scanf from input
		    //make a variable sc with scanf
			sc = new Scanner(new File(args[0]));
			
			
			while(sc.hasNextLine()) {
			//use scanner to read each line
				str1 = sc.nextLine();
				String[] c = str1.split(" ");
				//spilt each string with string array
				for(String ch : c) {
				//add cinema into double arraylist 
					if(ch.equals("Cinema")) {
						ArrayList<String> sublist = new ArrayList<String>();
						for(i=1;i<c.length;i++) {
							sublist.add(c[i]);
							
						}
						list.add(sublist);
						
					}
				    //add session into arraylist
					else if(ch.equals("Session")) {
						
						for(j=0;j<list.size();j++) {
							if(c[1].equals((list.get(j).get(0)))) {
								if(list.get(j).size() <=3) {
									
									list.get(j).add(c[2]);
								
									if(c.length>4) {
										
										comb = "";
										for(i=3;i<c.length;i++) {
											
											comb = comb +c[i]+" ";
											
										}
										list.get(j).add(comb);
									}
									else {
										list.get(j).add(c[3]);
									}
									list.get(j).add("0");
									
							    }
								else {
									ArrayList<String> clone = new ArrayList<String>();
									clone.addAll(list.get(j));
									
									clone.set(3, c[2]);
									
									if(c.length>4) {
										
										comb = "";
										for(i=3;i<c.length;i++) {
											
											comb = comb +c[i]+" ";
											
										}
										
										clone.set(4,comb);
									}
									else {
										clone.set(4,c[3]);
									}
									
									clonelist.add(clone);
								}
						    }
						}
						
					}
					
				}
				
			}
			list.addAll(clonelist);
			
			//finish session and cinema arraylist
			//next to do the booking cancel change print
			
			sc = new Scanner(new File(args[0]));
			//re-read the input file again
			while(sc.hasNextLine()) {
				str1 = sc.nextLine();
				String[] c1 = str1.split(" ");
				
				for(String ch : c1) {
				    //get the request and do 
				    if(ch.equals("Request")) {
							ArrayList<String> sublist = new ArrayList<String>();
							for(i=1;i<c1.length;i++) {
								sublist.add(c1[i]);
								
							}
							sublist.add("true");
							
							Request r = new Request(Integer.parseInt(sublist.get(0)),
						               				Integer.parseInt(sublist.get(1)),
						               				sublist.get(2),
						               				Integer.parseInt(sublist.get(3)),
						               				Boolean.parseBoolean(sublist.get(4)));
				
							for(i=0;i<list.size()&&r.getstate();i++) {
					
								Session s = new Session(Integer.parseInt(list.get(i).get(0)),
							                				list.get(i).get(1),
							                				Integer.parseInt(list.get(i).get(2)),
							                				list.get(i).get(3),
							                				list.get(i).get(4),
							                				Integer.parseInt(list.get(i).get(5)));
					
								if(r.book(s)) {
								    start = s.getUseticket()-r.getticket()+1;
									end = s.getUseticket();
									System.out.println("Booking "+ r.getid()+" "
												+s.getRow()+start +"-"//start row
												+s.getRow()+end);//end row
								   sublist.add(s.getRow());
								   sublist.add(String.format("%d",start));
								   sublist.add(String.format("%d",end));
									
									list.get(i).set(5, String.format ("%d", s.getUseticket()));//update useticket
									
									r.setstate(false);
								}
					
							}
				
							if(r.getstate()) {
								System.out.println("Booking rejected");
								
							}
							sublist.set(4, Boolean.toString(r.getstate()));
							listRequest.add(sublist);
					}
					
				    else if(ch.equals("Change")) {
				    //get id and change the request
						ArrayList<String> sublist = new ArrayList<String>();
						for(i=1;i<c1.length;i++) {
							sublist.add(c1[i]);
							
						}
						sublist.add("true");
						
						Change change = new Change(Integer.parseInt(sublist.get(0)),
								             Integer.parseInt(sublist.get(1)),
					               			 sublist.get(2),
					               			 Integer.parseInt(sublist.get(3)),
					               			 Boolean.parseBoolean(sublist.get(4)));
						
						for(j=0;j<listRequest.size()&&change.getstate();j++) {
							//find the older cancel request 
							Request r = new Request(Integer.parseInt(listRequest.get(j).get(0)),
						               Integer.parseInt(listRequest.get(j).get(1)),
						               listRequest.get(j).get(2),
						               Integer.parseInt(listRequest.get(j).get(3)),
						               Boolean.parseBoolean(listRequest.get(j).get(4)));
							
							for(k=0;k<list.size();k++) {
								
								Session s = new Session(Integer.parseInt(list.get(k).get(0)),
						                list.get(k).get(1),
						                Integer.parseInt(list.get(k).get(2)),
						                list.get(k).get(3),
						                list.get(k).get(4),
						                Integer.parseInt(list.get(k).get(5)));
								
								if(s.getCinema()==r.getcinema()&&s.getTime().equals(r.gettime())
									&&!r.getstate()&&listRequest.get(j).size()>5&&change.getstate()) {
									
									//cancel old request index id
									if(s.getRow().equals(listRequest.get(j).get(5))){
										if(change.responC(r, s)) {
											
										    //replace new request 
											Request newRequest = change.responR();
											ArrayList<String> newlist = new ArrayList<String>();
											newlist.add(String.format("%d", newRequest.getid()));
											newlist.add(String.format("%d", newRequest.getcinema()));
											newlist.add(newRequest.gettime());
											newlist.add(String.format("%d", newRequest.getticket()));
											newlist.add(Boolean.toString(r.getstate()));
											
											for(m=0;m<list.size();m++) {
												Session s1 = new Session(Integer.parseInt(list.get(m).get(0)),
										                list.get(m).get(1),
										                Integer.parseInt(list.get(k).get(2)),
										                list.get(m).get(3),
										                list.get(m).get(4),
										                Integer.parseInt(list.get(m).get(5)));
												if(s1.getCinema()==newRequest.getcinema()
														&&s1.getTime().equals(newRequest.gettime())&&change.getstate()) {
													
													if(newRequest.book(s1)) {
														
														start = s1.getUseticket()-newRequest.getticket()+1;
														end = s1.getUseticket();
														System.out.println("Change "+change.getid()+ " "+
														                      s1.getRow()+start+"-"//start row
																             +s1.getRow()+end);//end row
														
														list.get(m).set(5, String.format ("%d", s1.getUseticket()));//update request useticket
														listRequest.set(j, newlist);//update request
														list.get(k).set(5,  String.format ("%d", s.getUseticket()));//update canceled useticket
														
														newlist.add(s1.getRow());
														newlist.add(String.format ("%d",start));
														newlist.add(String.format ("%d",end));
														change.setstate(false);
														
													}
													
												}
											}
										}
									}	
							    }
								
							}
							
						}
						sublist.set(4, Boolean.toString(change.getstate()));//update sublist
						if(change.getstate()) {
							//re-book the ticket and refresh state
							System.out.println("Change rejected");
							
							change.setstate(false);
							
						}
						
					}
					
					else if(ch.equals("Cancel")) {
					//Cancel the request with Cancel id
						ArrayList<String> sublist = new ArrayList<String>();
						for(i=1;i<c1.length;i++) {
							sublist.add(c1[i]);
							
						}
						sublist.add("true");
						
						Cancel cancel = new Cancel(Integer.parseInt(sublist.get(0)),
					             Boolean.parseBoolean(sublist.get(1)));
			
						for(j=0;j<listRequest.size();j++) {
							
							Request r = new Request(Integer.parseInt(listRequest.get(j).get(0)),
									               Integer.parseInt(listRequest.get(j).get(1)),
									               listRequest.get(j).get(2),
									               Integer.parseInt(listRequest.get(j).get(3)),
									               Boolean.parseBoolean(listRequest.get(j).get(4)));
							
			               for(k=0;k<list.size();k++) {
								
								Session s = new Session(Integer.parseInt(list.get(k).get(0)),
						                                list.get(k).get(1),
						                                Integer.parseInt(list.get(k).get(2)),
						                                list.get(k).get(3),
						                                list.get(k).get(4),
						                                Integer.parseInt(list.get(k).get(5)));
								if(listRequest.get(j).size()>5&&listRequest.get(j).get(5).equals(s.getRow())) {
								if(s.getCinema()==r.getcinema()&&s.getTime().equals(r.gettime())) {
									if(cancel.rejectbook(r, s)&&cancel.getstate()&&!r.getstate()) {
										list.get(k).set(5, String.format ("%d", s.getUseticket()));
										r.setstate(true);
										listRequest.get(j).set(4, Boolean.toString(r.getstate()));
										System.out.println("Cancel "+cancel.getid());
										cancel.setstate(false);
										
									}
								}
								}
			               }
						}
						if(cancel.getstate()) {
							System.out.println("Cancel rejected");
							cancel.setstate(false);
						}
						sublist.set(1, Boolean.toString(cancel.getstate()));		
				}
				else if(ch.equals("Print")) {
					//print cinema and movie_name and seat
					ArrayList<String> sublist = new ArrayList<String>();
					for(i=1;i<c1.length;i++) {
						sublist.add(c1[i]);
						
					}
					
					Print p = new Print(Integer.parseInt(sublist.get(0)),
							           sublist.get(1));
                    String Name = null;
                    StringBuilder value = new StringBuilder();
                    for(k=0;k<list.size();k++) {
                     
                        Session s = new Session(Integer.parseInt(list.get(k).get(0)),
                                                list.get(k).get(1),
                                                Integer.parseInt(list.get(k).get(2)),
                                                list.get(k).get(3),
                                                list.get(k).get(4),
                                                Integer.parseInt(list.get(k).get(5)));

                        if(p.getcinema()==s.getCinema()&&p.gettime().equals(s.getTime())) {

	                        Name = s.getMovieName();
	                        value.append(s.getRow());
	                        value.append(":");
	                        value.append(" ");
	
	                        for(j=0;j<listRequest.size();j++) {
		
		                        Request r = new Request(Integer.parseInt(listRequest.get(j).get(0)),
				                                       Integer.parseInt(listRequest.get(j).get(1)),
				                                       listRequest.get(j).get(2),
				                                       Integer.parseInt(listRequest.get(j).get(3)),
				                                       Boolean.parseBoolean(listRequest.get(j).get(4)));
	                            if(!r.getstate()) {
	                            
			                        if(r.getcinema() == s.getCinema()&&r.gettime().equals(s.getTime())&&
					                        listRequest.get(j).get(5).equals(s.getRow())) {
				
				                        value.append(listRequest.get(j).get(6));
				                        value.append("-");
				                        value.append(listRequest.get(j).get(7));
				                        value.append(",");
			                        }
			
	                            }
	                            
	                        }
	                        if(Name!=null) {
		
		                        length = value.toString().length();
	                            
		                        value.setCharAt(length-1, '\n');
		
	                        }
                        }

                    }

                    if(Name!=null) {
                     StringBuilder repl = new StringBuilder();
                     String[] ary = value.toString().split("\n");
                     
                         for(i=0;i<ary.length;i++) {
                             if(ary[i].length()!=2) {
                                repl.append(ary[i]+"\n");
                             }
                        }
                         if(repl.length()!=0) {
                             repl.deleteCharAt(repl.length()-1);
                             System.out.println(Name+"\n"+repl.toString());
                             
                         }

                   }
				}
						
				}
			}
			
		}catch(IOException ex) {
			 System.out.println(ex.getMessage());
		}
		finally{
			if (sc != null) {
				
				sc.close();
			    
			}
			
		}
	}
}


