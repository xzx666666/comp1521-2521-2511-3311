
public class Print {
	private int cinema;
	private String time;
	
	public Print(int cinema, String time) {
		this.cinema = cinema;
		this.time = time;
		
	}
	
	public int getcinema() {
		return this.cinema;
	}
	public String gettime() {
		return this.time;
	}
	
	
}
