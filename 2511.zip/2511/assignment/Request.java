
public class Request {
	private int id;
	private int cinema;
	private String time;
	private int ticket;
	private boolean state;
	public Request(int id,int cinema,String time, int ticket,boolean state) {
		this.id = id;
		this.cinema = cinema;
		this.time = time;
		this.ticket = ticket;
		this.state = state;
	}
	public void setstate(boolean o) {
		state = o;
	}
	public boolean getstate() {
		return state;
	}
	public int getid() {
		return this.id;
	}
	public int getcinema() {
		return this.cinema;
	}
	public String gettime() {
		return this.time;
	}
	public int getticket() {
		return this.ticket;
	}
	public String toString() {
		return String.format("%d %d %s %d",id,cinema,time,ticket);
	}
	public boolean book(Session o) {
		
		if(this.cinema == o.getCinema()&&this.time.equals(o.getTime())) {
			
			if(o.bookSeat(ticket)) {
				return true;
			}
			
		}
		return false;
	}
	
	
}
