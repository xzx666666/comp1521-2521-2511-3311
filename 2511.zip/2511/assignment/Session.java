
public class Session extends Cinema{
	private String movie_name;
	private String time;
	
    public Session(int cinema,String row ,int seat,String time,String movie_name,int useticket) {
    		super(cinema,row,seat,useticket);
    		this.time = time;
    		this.movie_name = movie_name;
    }
   
    public String getTime() {
    	    return this.time;
    }
    public String getMovieName() {
    	    return this.movie_name;
    	    
    }
   
}
