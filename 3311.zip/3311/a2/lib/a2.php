<?php
// COMP3311 18s1 Assignment 2
// Functions for assignment Tasks A-E
// Written by <<YOUR NAME>> (<<YOUR ID>>), May 2018

// assumes that defs.php has already been included


// Task A: get members of an academic object group

// E.g. list($type,$codes) = membersOf($db, 111899)
// Inputs:
//  $db = open database handle
//  $groupID = acad_object_group.id value
// Outputs:
//  array(GroupType,array(Codes...))
//  GroupType = "subject"|"stream"|"program"
//  Codes = acad object codes in alphabetical order
//  e.g. array("subject",array("COMP2041","COMP2911"))

function membersOf($db,$groupID)
{
	$q = "select * from acad_object_groups where id = %d";
	
	$grp = dbOneTuple($db, mkSQL($q, $groupID));
	$table = $grp["gtype"]."s";
	$objectTable = $grp["gtype"]."_group_members";
	$a = array();
	$name = $grp["gtype"];
	if($grp["gdefby"] == enumerated){
	    //find the *_group_members table
	    $tq = "select $name,ao_group from $objectTable where ao_group = %d";
	    $r = dbQuery($db,mkSQL($tq,$groupID));
	    while($t = dbNext($r)){
	        //find the * GroupID = ao_group
	        $id = $t[$name];
	        //use the *_id to find the code
	        $findcode = "select code from $table where id = %d";
	        $r1 = dbOneValue($db,mkSQL($findcode,$id));
	        $code = $r1;
	        //add the * code into arrray
	        array_push($a,$code);
	    }
	    
	
	}
	else if($grp["gdefby"] == pattern){
        $defi = $grp["definition"];
        $defi = str_replace(';', ',', $defi);
        $defi = str_replace('{', '', $defi);
        $defi = str_replace('}', '', $defi);
        $defi = str_replace('|', ',', $defi);
        $arr = array();
        $codelist = split(',',$defi);
        if($defi[0]=='('){
            
            $len = strlen($defi);
            $subs = substr($defi,$len-4);
            
            foreach($codelist as $code){
                $code = str_replace('(', '', $code);
                $code = str_replace(')', '', $code);
                
                if(($len = strlen($code))==8) continue;
                
                $code = $code.$subs;
                array_push($arr,$code);
            }
            $codelist = $arr;
        }
        
        foreach($codelist as $code){
            
            if($code[7] == '['&& $code[10] == ']'){
                $new_code = substr($code,0,7).$code[8];
                array_push($a,$new_code);
                $new_code = substr($code,0,7).$code[9];
                array_push($a,$new_code);
            }
            else if($code[7] == '['&& $code[11] == ']'){
                for($i = $code[8]; $i<=$code[10] ;$i++){
                    $new_code = substr($code,0,7).$i;
                    array_push($a,$new_code);
                }
            
            }
            
            else{
                $str = substr($code,0,4);
                $str1 = substr($code,0,3);
                if($str == "GENG"||$str == "FREE"||$str == "####"||$str1 == "all"||$str1 == "ALL"){
                    array_push($a,$code);
                }
                
                else if($code[0] == '!'){
                    $code[0] = '';
                    $code = str_replace('#', '_', $code);
                    
                    $qcode  = "select code from $table where code not like %s";
                    $r = dbQuery($db,mkSql($qcode,$code));
                    while ($t = dbNext($r)){
                        $code = $t["code"];
                        array_push($a,$code);
                    }
                    
                }
                
                else{
                    
                    $code = str_replace('#', '_', $code);
                    
                    $qcode  = "select code from $table where code like %s";
                    $r = dbQuery($db,mkSql($qcode,$code));
                    while ($t = dbNext($r)){
                        $code = $t["code"];
                        array_push($a,$code);
                    }
                }
                 
            }
        }

    }
	//add the sub_ject into arraylist
	$q1 = "select * from acad_object_groups where parent = %d";
	$r2 = dbQuery($db,mkSQL($q1 ,$groupID));    
    while($t1 = dbNext($r2)){
        $p_id = $t1["id"];
        $tq = "select $name,ao_group from $objectTable where  ao_group = %d";
        $r1 = dbQuery($db,mkSQL($tq,$p_id));
        while($t2 = dbNext($r1)){
            $id = $t2[$name];
            $findcode = "select code from $table where id = %d";
            $r = dbOneValue($db,mkSQL($findcode,$id));
	        $code = $r;
	        array_push($a,$code);
        }
    }
	//sort the course_code
	
	sort($a);
	return array($name, $a); 
}


// Task B: check if given object is in a group

// E.g. if (inGroup($db, "COMP3311", 111938)) ...
// Inputs:
//  $db = open database handle
//  $code = code for acad object (program,stream,subject)
//  $groupID = acad_object_group.id value
// Outputs:
//  true/false

function inGroup($db, $code, $groupID)
{
    list($type,$course) = membersOf($db,$groupID);
    $type = $type.'s';
    foreach ($course as $co){
        $str = substr($co,0,4);
        $str1 = substr($co,0,3);
        if($code == $co){
            return true;
        
        }
        
        else if($str1 == "GEN"){
            
           //find facility in OrgUnits by unswid
            if($pos = strpos($co,"/F")){
                //check the facility of code and facility of co is or not equal
                if($co[$pos+3]=='!'){
                
                    $facility_co = substr($co,$pos+4);
                    
                    $q = "select offeredBy from $type where  code like %s";
                    $r = dbOneValue($db,mkSQL($q,$code));
                    $q1 = "select unswid from OrgUnits where  id = %d";
                    $r1 = dbOneValue($db,mkSQL($q1,$r));
                    $facility_co = strtoupper($facility_co);
                    
                    if($r1 != $facility_co){
                        return true;
                    
                    }
                } 
                else{
                    $facility_co = substr($co,$pos+3);
                    //find the faciity of code 
                    $q = "select offeredBy from $type where  code like %s";
                    $r = dbOneValue($db,mkSQL($q,$code));
                    $q1 = "select unswid from OrgUnits where  id = %d";
                    $r1 = dbOneValue($db,mkSQL($q1,$r));
                    $facility_co = strtoupper($facility_co);
                    if($r1 == $facility_co){
                        return true;
                    
                    }
                }
            }
            
            $co = str_replace('#', '', $co);
            if($str == "GENG"){
                $co[3] = '';
            
            }
            
            $tq = "select code from $type where  code like %p";
            $r = dbQuery($db,mkSQL($tq,$co));
            
            while($t = dbNext($r)){
                
                if($t["code"] == $code){
                    
                    return true;
                }
            
            }
        
        }
        else if($str == "####"){
            //find facility in OrgUnits by unswid
            if($pos = strpos($co,"/F")){
                //check the facility of code and facility of co is or not equal
                if($co[$pos+3]=='!'){
                
                    $facility_co = substr($co,$pos+4);
                    
                    $q = "select offeredBy from $type where  code like %s";
                    $r = dbOneValue($db,mkSQL($q,$code));
                    $q1 = "select unswid from OrgUnits where  id = %d";
                    $r1 = dbOneValue($db,mkSQL($q1,$r));
                    $facility_co = strtoupper($facility_co);
                    if($r1 != $facility_co){
                        return true;
                    
                    }
                } 
                else{
                    $facility_co = substr($co,$pos+3);
                    //find the faciity of code 
                    $q = "select offeredBy from $type where  code like %s";
                    $r = dbOneValue($db,mkSQL($q,$code));
                    $q1 = "select unswid from OrgUnits where  id = %d";
                    $r1 = dbOneValue($db,mkSQL($q1,$r));
                    $facility_co = strtoupper($facility_co);
                    if($r1 == $facility_co){
                        return true;
                    
                    }
                }
            }
            $co = str_replace('#', '_', $co);
        
            $tq = "select code from $type where  code like %s";
            $r = dbQuery($db,mkSQL($tq,$co));
            
            while($t = dbNext($r)){
                
                if($t["code"] == $code){
                    
                    return true;
                }
            
            }
            
        }
       
        else if($str1 == "all"||$str1 == "ALL"||$str == "FREE"){
            return true;
        }
    }
	return false; 
}


// Task C: can a subject be used to satisfy a rule

// E.g. if (canSatisfy($db, "COMP3311", 2449, $enr)) ...
// Inputs:
//  $db = open database handle
//  $code = code for acad object (program,stream,subject)
//  $ruleID = rules.id value
//  $enr = array(ProgramID,array(StreamIDs...))
// Outputs:

function canSatisfy($db, $code, $ruleID, $enrolment)
{
    $len = strlen ( $code );
    $name = "";
    //divide into subject and stream and programs
    if($len == 8){
    //subject
        $name = "subjects";
    }
    if($len == 6){
    //stream
        $name = "streams";
    }
    if($len == 4){
    //programs
        $name = "programs";
    }
    list($programID,$Stream) = $enrolment;
    $q1 = " select a.id,r.type,a.gdefby from
            acad_object_groups a 
            inner join rules r on (r.ao_group = a.id)
            where r.id = %d";
    $r = dbOneTuple($db,mkSql($q1,$ruleID)); 
    if(!inGroup($db, $code, $r["id"])){
        return false;
    
    }
    if(!preg_match("/(CC|PE|FE|GE|DS|RQ)/i",$r["type"])){
        return false;
    
    }
    //if under general education course
    if(preg_match("/GEN/i",$code)){
        //check the program facuity whether equal to $code faculity
        $q_code = "select facultyOf(o.offeredBy) from( select offeredBy from $name where  code like %s) as o";
        $q_program = "select facultyOf(o.offeredBy) from( select offeredBy from programs where id = %d) as o";
        $codeFacuity = dbOneValue($db,mkSql($q_code,$code));
        $progFacuity = dbOneValue($db,mkSql($q_program,$programID));
        
        if($codeFacuity == $progFacuity){
           
            return false;
        }
        //check the stream facuity whether equal to $code facuity
        $q_program = "select facultyOf(o.offeredBy) from( select offeredBy from streams where id = %d) as o";
        foreach($Stream as $s){
            
            $streamFacuity = dbOneValue($db,mkSql($q_program,$streamodeoffered));
            if($streamFacuity == $codeFacuity){
                return false;
            }
        }
    }
	return true; // stub
}


// Task D: determine student progress through a degree

// E.g. $vtrans = progress($db, 3012345, "05s1");
// Inputs:
//  $db = open database handle
//  $stuID = People.unswid value (i.e. unsw student id)
//  $semester = code for semester (e.g. "09s2")
// Outputs:
//  Virtual transcript array (see spec for details)

function progress($db, $stuID, $term)
{
    $x = array();
    $q1 = " select * from transcript(%d,%d)";
    $new = dbQuery($db,mkSql($q1,$stuID,$term));
    //Get Student streams/programs
    $ruleList = array("CC" =>array(),"PE" => array(), "FE" => array(), "GE" => array(), "LR" => array());
    $wam = array();
    while ($t = dbNext($new)){  
        if($t[2] == "No WAM available"){
            $t[2] = "Overall WAM";
        }
        $year = 2000+substr($t["term"],0,2);
        $term = strtoupper(substr($t["term"],2,2));
        
        $q = "select id from semesters where year = %d and term like %s";
        $semID = dbOneValue($db, mkSQL($q,$year,$term));
        $q = "select id,program from Program_enrolments where student= %d and semester = %d";
        $program = dbOneTuple($db, mkSQL($q,$stuID,$semID));
        
        $prog = $program["program"];
        $q = "select stream from Stream_enrolments where partof = %d";
        $r = dbQuery($db, mkSQL($q, $program["id"]));     
        $streams = array();  
        while ($t2 = dbNext($r)) {
        
         $streams[] = $t2[0];
        }        
        $enrolment = array($program["program"],$streams); 
        $req = null;        
        if($t["code"]){
        
            if(!$t["grade"]){
            
                 $t["uoc"] = null;
                 $req = "Incomplete. Does not yet count";
                 
            } 
            else if($t["grade"] == 'FL') {
                 $req = "Failed. Does not count";
            } 
               
            foreach($streams as $s){
                $q = "select rules.id,rules.min,rules.max,rules.type,rules,name from stream_rules inner join rules on (rules.id = stream_rules.rule) where stream_rules.stream = $s order by rules.id";
                $r = dbQuery($db, mkSQL($q));
                while($rule = dbNext($r)){
                    
                    if(!(isset($ruleList[$rule["type"]][$rule["id"]]))){                     
                        $ruleList[$rule["type"]][$rule["id"]] = array($rule["id"],$rule["min"],$rule["max"],0,$rule["type"],false,"Stream"); 
                    }            
                }
            }
            $q = "select rules.id,rules.min,rules.max,rules.type,rules.name from program_rules inner join rules on (rules.id = program_rules.rule) where program_rules.program = $prog order by rules.id";
            
            $r = dbQuery($db, mkSQL($q));
            while($rule = dbNext($r)){
                
                
                if(!(isset($ruleList[$rule["type"]][$rule["id"]]))){
                    
                    $ruleList[$rule["type"]][$rule["id"]] = array($rule["id"],$rule["min"],$rule["max"],0,$rule["type"],false,"Program"); 
                }
             }
            foreach($ruleList as &$rulesublist){
              
                foreach($rulesublist as &$rule){  
                    if(!$req){
                        if(canSatisfy($db,$t["code"],$rule[0],$enrolment)){ 
                      
                            if($rule[2]){
                                if($rule[3] < $rule[2]){
                                    $req = ruleName($db,$rule[0]);
                                    $rule[3] = ($rule[3] + $t["uoc"]);
                                    
                                } 
                            } else {
                                    $req = ruleName($db,$rule[0]);
                                    $rule[3] = ($rule[3] + $t["uoc"]);
                            }
                            if($rule[3] >= $rule[1])
                                $rule[5] = True;
                             
                        }
                    }
                }
                
            }
       
        if (!($req))
            $req = "Fits no requirement. Does not count";
        array_push($x,array($t["code"],$t["term"],$t["name"],$t["mark"],$t["grade"],$t["uoc"],$req));
        }    
    $wam = array($t[2],$t[3],$t[5]); 
    }  
    array_push($x,$wam);
    
    foreach($ruleList as $rulesublist){ 
     
        foreach($rulesublist as $rule){
        
            if(preg_match("/(CC|PE|FE|GE|LR)/i", $rule[4])){
                
                if(!$rule[5]){
                
                    $rem = ($rule[1] - $rule[3]);
                    $desc1 = $rule[3]." UOC so far; need ".$rem." UOC more";
                    $getruleName = ruleName($db,$rule[0]);
                    array_push($x,array($desc1,$getruleName));
                    array_push($x,array($rule[0], $rem[1],$rule[2],$rule[3],$rule[4],$rem[6]));
                }
            }
        }
        
    }
	return $x; // stub
}


// Task E:

// E.g. $advice = advice($db, 3012345, 162, 164)
// Inputs:
//  $db = open database handle
//  $studentID = People.unswid value (i.e. unsw student id)
//  $currTermID = code for current semester (e.g. "09s2")
//  $nextTermID = code for next semester (e.g. "10s1")
// Outputs:
//  Advice array (see spec for details)

function advice($db, $studentID, $currTermID, $nextTermID)
{
	return array(); // stub
}
?>
