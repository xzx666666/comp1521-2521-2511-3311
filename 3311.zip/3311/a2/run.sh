#!/bin/sh

let fail=0
let pass=0

mkdir result

while [[ "$1" != '' ]]; do
  if [[ "$1" > 0 ]] ; then
    if [[ "$1" < 10 ]]; then
      cp ./tests/0$1.sh ./
      sh 0$1.sh > ./result/0$1.txt
      DIFF=$(diff ./result/0$1.exp ./result/0$1.txt)
      rm 0$1.sh
    elif [[ "$1" > 47 ]]; then
      echo "Error: Type a number between 1 and 47"
      break
    else
      cp ./tests/$1.sh ./
      sh $1.sh > ./result/$1.txt
      DIFF=$(diff ./result/$1.exp ./result/$1.txt)
      rm $1.sh
    fi
  else
    echo "Error: Type a number between 1 and 47"
    break
  fi

  if [[ "$DIFF" != "" ]]; then
    echo "xxxxxxxxxxxxxxxxxxxx$1 Task Failedxxxxxxxxxxxxxxxxxxxx"
    echo "$DIFF"
    break
  else
    echo "-------------------- $1 Task Passed----------------------"
    break
  fi
done


if [[ "$1" == '' ]]; then
  cp ./tests/*.sh ./
  cp ./tests/*.exp ./result
  for i in 0{1..9} {10..47}; do
    sh $i.sh > ./result/$i.txt
  done

  for i in 0{1..9} {10..47}; do
    DIFF=$(diff ./result/$i.exp ./result/$i.txt)
    if [[ "$DIFF" != "" ]]; then
      echo "xxxxxxxxxxxxxxxxxxxx$i Task Failedxxxxxxxxxxxxxxxxxxxx"
      echo "$DIFF"
      fail=$(( $fail +1 ))
    else
      echo "--------------------$i Task Passed----------------------"
      pass=$(( $pass + 1))
    fi
  done

  for i in 0{1..9} {10..47}; do
    rm $i.sh
  done
  if [[ "$fail" == 0 ]]; then
    echo "-------------------------------------------------------"
    echo "Congratudations, You have passed all tests"
  elif [[ "$pass" == 0 ]]; then
    echo "-------------------------------------------------------"
    echo "Congratudations, You have failed all tests"
  else
    echo "-------------------------------------------------------"
    echo "You have passed $pass tasks and failed $fail tasks"
  fi

fi

