# Student 3363921 studied 3978, COMPA1 starting in 10s1
php advisor 3363921 09s2
