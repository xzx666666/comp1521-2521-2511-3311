-- COMP3311 18s1 Assignment 1
-- Written by YOUR_NAME (YOUR_STUDENT_ID), April 2018

-- Q1: ...

create or replace view Q1(unswid, name)
as
SELECT people.unswid, people.name
    FROM people , course_enrolments  
    WHERE people.id = course_enrolments.student 
    GROUP BY people.unswid, people.name 
    HAVING COUNT(course_enrolments.student) > 65
;

-- Q2: ...

create or replace view Q2(nstudents, nstaff, nboth)
as
SELECT
	(SELECT COUNT(*) 
	FROM students 
	LEFT JOIN staff ON staff.id = students.id
	WHERE staff.id IS NULL),
	
	(SELECT COUNT(*)
	FROM staff 
	LEFT JOIN students on students.id = staff.id
	WHERE students.id IS NULL),
	
	(SELECT COUNT(*)
	FROM students 
	INNER JOIN staff ON staff.id = students.id);

;

-- Q3: ...

create or replace view Q3(name, ncourses)
as
SELECT maxium.name, maxium.count
    FROM (
        SELECT inorder.name, inorder.count, row_number() 
        
        OVER (ORDER BY GREATEST(inorder.count) DESC) as des 
        from (
            SELECT convenor.name, COUNT(convenor.course)
            FROM (
                SELECT people.id, people.name, course_staff.course 
                FROM people 
                INNER JOIN course_staff on (people.id = course_staff.staff) 
                WHERE role='1870' ORDER BY people.id) AS convenor 
        GROUP BY convenor.name)AS inorder
        )AS maxium WHERE des = 1

;

-- Q4: ...

create or replace view Q4a(id)
as
SELECT p4.unswid AS id 
    FROM program_enrolments p1, semesters p2, programs p3, people p4 
    WHERE p1.semester = p2.id 
    AND p1.program = p3.id 
    AND p1.student = p4.id 
    AND p2.year = '2005' 
    AND p2.term = 'S2' 
    AND p3.name = 'Computer Science' 
    AND p3.code = '3978'
;

create or replace view Q4b(id)
as
SELECT p5.unswid AS id 
    FROM program_enrolments p1, semesters p2, streams p3, stream_enrolments p4, people p5 
    WHERE p1.semester = p2.id 
    AND p1.id = p4.partof 
    AND p1.student = p5.id 
    AND p2.year = '2005' 
    AND p2.term = 'S2' 
    AND p3.id = p4.stream 
    AND p3.code = 'SENGA1'
;

create or replace view Q4c(id)
as
SELECT p4.unswid AS id 
    FROM program_enrolments p1, semesters p2, programs p3, people p4 
    WHERE p1.semester = p2.id 
    AND p1.program = p3.id 
    AND p1.student = p4.id 
    AND p2.year = '2005' 
    AND p2.term = 'S2' 
    AND p3.offeredby = '89'


;

-- Q5: ...
create or replace view Counter(name, max)
as
SELECT answ.name, max(answ.count)
    FROM 
        (SELECT * FROM (
            SELECT * FROM (
                SELECT innertable.facultyof, COUNT(*) 
                FROM (
                    SELECT facultyOf(c1.id) 
                    FROM orgunits c1, orgunit_types c2 
                    WHERE c2.name = 'Committee' 
                    AND c1.utype = c2.id) AS innertable 
            WHERE innertable.facultyof IS NOT NULL 
            GROUP BY innertable.facultyof 
            ORDER BY innertable.count DESC) AS innertable1 
            
            INNER JOIN (
            SELECT orgunits.id, orgunits.name 
            FROM orgunits) AS org 
            
       ON (org.id = innertable1.facultyof)) AS answ1 
   ORDER BY answ1.count DESC) AS answ 
   GROUP BY answ.name 
   ORDER BY max DESC
;
create or replace view Q5(name)
as
SELECT name FROM Counter
WHERE max = (
SELECT max(max) from Counter)
;

-- Q6: ...

create or replace function Q6(integer) 
    returns text
as
$$
SELECT people.name FROM people WHERE people.id = $1 or people.unswid = $1;
$$ language sql
;

-- Q7: ...


create or replace function Q7(text)
	returns table (course text, year integer, term text, convenor text)
as $$
    SELECT cast(s2.code as text), s4.year, cast(s4.term as text), s6.name
    
    FROM staff_roles s1
    INNER JOIN course_staff s5 ON s1.id = s5.role
    INNER JOIN people s6 ON s6.id = s5.staff
    INNER JOIN courses s3 ON s3.id = s5.course
    INNER JOIN subjects s2 ON s2.id = s3.subject
    INNER JOIN semesters s4 ON s3.semester = s4.id 
    WHERE s1.name = 'Course Convenor' AND s2.code = $1;
$$ language sql
;

-- Q8: ...

create or replace function Q8(integer)

 RETURNS SETOF NewTranscriptRecord
 LANGUAGE plpgsql
AS $function$
declare
        rec NewTranscriptRecord;
        UOCtotal integer := 0;
        UOCpassed integer := 0;
        wsum integer := 0;
        wam integer := 0;
        x integer;
begin
        select s.id into x
        from   Students s join People p on (s.id = p.id)
        where  p.unswid = $1;
        if (not found) then
                raise EXCEPTION 'Invalid student %',$1;
        end if;
        for rec in
                select su.code as code,
                         substr(t.year::text,3,2)||lower(t.term),
                prog.code,
                         substr(su.name,1,20),
                         e.mark, e.grade, su.uoc
                from   People p
                       
                         join Students s on (p.id = s.id)
                         join Course_enrolments e on (e.student = s.id)
                         join Courses c on (c.id = e.course)
                         join Subjects su on (c.subject = su.id)
                         join Semesters t on (c.semester = t.id)
                         inner join program_enrolments pe on (pe.student = p.id)
                         inner join  programs prog on (prog.id = pe.program)
                where  p.unswid = $1 and t.id = pe.semester
                order  by t.starting, su.code
        loop
                if (rec.grade = 'SY') then
                        UOCpassed := UOCpassed + rec.uoc;
                elsif (rec.mark is not null) then
                        if (rec.grade in ('PT','PC','PS','CR','DN','HD','A','B','C')) then
                                -- only counts towards creditted UOC
                                -- if they passed the course
                                UOCpassed := UOCpassed + rec.uoc;
                        end if;
                        -- we count fails towards the WAM calculation
                        UOCtotal := UOCtotal + rec.uoc;
                        -- weighted sum based on mark and uoc for course
                        wsum := wsum + (rec.mark * rec.uoc);
                        -- don't give UOC if they failed
                        if (rec.grade not in ('PT','PC','PS','CR','DN','HD','A','B','C')) then
                                rec.uoc := 0;
                        end if;

                end if;
                return next rec;
        end loop;
        if (UOCtotal = 0) then
                rec := (null,null,null,'No WAM available',null,null,null);
        else
                wam := wsum / UOCtotal;
                rec := (null,null,null,'Overall WAM',wam,null,UOCpassed);
        end if;
        -- append the last record containing the WAM
        return next rec;
end;
$function$



-- Q9: ...

create or replace function Q9(integer)
	returns setof AcObjRecord
as $$
declare
	... PLpgSQL variable delcarations ...
begin
	... PLpgSQL code ...
end;
$$ language plpgsql
;








