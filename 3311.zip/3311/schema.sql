-- COMP3311 Prac 03 Exercise
-- Schema for simple company database

create table Employees (
	tfn         char(11) check (tfn LIKE '\d\d\d-\d\d\d-\d\d\d') PRIMARY KEY,
	givenName   varchar(30) NOT NULL,
	familyName  varchar(30),
	hoursPweek  float check (hoursPweek<168 and hoursPweek>0)
);

create table Departments (
	id          char(3) check(id LIKE '\d\d\d') PRIMARY KEY,
	name        varchar(100) unique,
	manager     char(11) unique
);

create table DeptMissions (
	department  char(3) REFERENCES Departments(id),
	keyword     varchar(20)NOT NULL
	
);

create table WorksFor (
	employee    char(11) REFERENCES Departments(manager),
	department  char(3)  REFERENCES Departments(id),
	percentage  float check(percentage>0 and percentage<100)
);
