//written by xiao zixin

#include<stdio.h>
#include"captcha.h"
void get_box(int height,int width,int pixels[height][width]){
	int box[height][width];
	int start_row, start_column, box_width, box_height, min_row, max_row, min_col, max_col;
	int x,y;
	get_bounding_box(height, width, pixels, &start_row, &start_column, &box_height, &box_width);
    
    min_col = start_column;
    min_row = start_row;
    
	for(x=box_height-1;x>=0;x--){
	for(y=0;y<box_width;y++){
		
            
            box[x][y]=pixels[x+min_row][y+min_col];
           
        
        
           }
       
	}
}
	

