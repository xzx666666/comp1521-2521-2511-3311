#include <stdio.h>
#include "captcha.h"

void copy_pixels(int height, int width, int pixels[height][width],
                 int start_row, int start_column, int copy_height, int copy_width,
                 int copy[copy_height][copy_width])
{   
                    int x,y,i,j;
                 
                  for(x=0;x<copy_height;x++){
                        for(y=0;y<copy_width;y++) {   
                            copy[x][y]=pixels[x+start_row][y+start_column];
                            }
                            
                        
                  }
}
