 //writen by xiaozixin
 #include <stdio.h>
#include "captcha.h"

int main(int argc, char *argv[]) {
    int height, width, start_row, start_column, box_width, box_height,center;
    double balance1,balance2,holes_density,density1,h_density,density,solution;
    int holes,holes2,left_holes;
    int picture_height,picture_width;
        
    
    
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <image-file>\n", argv[0]);
        return 1;
    }
    
    if (get_pbm_dimensions(argv[1], &height, &width) != 1) {
        return 1;
    }
    
    int pixels[height][width];
    if (read_pbm(argv[1], height, width, pixels)) {
        get_bounding_box(height, width, pixels, &start_row, &start_column, &box_height, &box_width);
        
        int box_pixels[box_height][box_width];
        copy_pixels(height, width, pixels, start_row, start_column, box_height, box_width, box_pixels);
        
        balance1 = get_horizontal_balance(box_height, box_width, box_pixels);
        balance2 = get_vertical_balance(box_height, box_width, box_pixels);
        
        holes2= get_line( box_height,box_width,box_pixels,&solution);
        left_holes= get_left_holes( box_height,box_width,box_pixels);
        
            
        holes=get_holes(box_height, box_width, box_pixels,&h_density,&density);
                holes_density=h_density;
                density1=density;
       
        get_box( box_height, box_width, box_pixels);
        
        
        /*printf("left_Holes %d\n",left_holes);
        printf("box_Holes %d\n",holes2);
        printf("holes %d\n", holes);
        printf("ratio %lf\n", (double)solution);*/
        
        
        picture_height= 70 * balance2;
        
        picture_width= 50 * balance1;
        
        center=pixels[picture_height][picture_width];

        

        if(holes==2){
            printf("8\n");}
        else if(holes==1){
            
            
            if(holes_density>=0.2){
                if (((balance1<=0.539)&&(balance1>=0.428))&&((balance2>=0.456)&&(balance2<=0.545))&&((density1<=0.695)&&(density1>=0.309)))
                    printf("0\n");
                
                
                else if(((balance2>=0.556)&&(balance2<=0.599))||((balance1<=0.515)&&(balance1>=0.477)))
                    printf("9\n");
                
                else
                    printf("6\n");
            }
            
            
            
            else if((holes_density<0.2)&&(holes_density>=0.15)){
                if(((balance2<=0.544)&&(balance2>=0.473))&&((balance1<=0.539)&&(balance1>=0.47))&&((density1<=0.646)&&(density1>=0.489)))
                    printf("0\n");
                else if((balance1<=0.508)&&(balance1>=0.418)){
                    if(((balance2>=0.515)&&(balance2<0.574))||((balance2>0.424)&&(balance2<=0.467)))
                        printf("6\n");
                    
                }
                
                else if((balance2<=0.574)&&(balance2>=0.467)){
                    if(((balance1>0.508)&&(balance1<=0.56))||((balance1>0.418)&&(balance1<=0.481)))
                        
                        printf("9\n");
                }
                else if((density1<0.414)&&(density1<=0.508))
                    
                    printf("9\n");
                else
                    printf("6\n");
                
            }
            else if(holes_density<=0.112){
                if((balance2<=0.545)&&(balance2>=0.413)&&(balance1>=0.449)&&(balance1<=0.632)){
                    if(holes_density<0.059)
                        printf("4\n");
                    else if(density1<=0.56&&density1>=0.319){
                        if(balance1>=0.577)
                            printf("4\n");
                        else if(balance1>balance2&&balance1>density1){
                            if(((balance1<=0.594)&&(balance1>0.574))||((density1>0.502)&&(density1<=0.512)))
                                printf("9\n");
                            else
                                printf("4\n");
                            
                        }
                        else
                            printf("6\n");
                        
                    }
                    else if   (balance1>0.495)
                        printf("9\n");
                    else
                        printf("6\n");
                    
                }
                
                else if(balance2>0.545)
                    printf("9\n");
                
                else
                    printf("6\n");
            }
            
            
            else if(holes_density>0.112&&holes_density<0.15){
                if(balance1>=0.49)
                        printf("9\n");
                
                else if((density1<=0.695)&&(density1>=0.591))
                        printf("0\n");
                else
                        printf("6\n");
            }
            
            if((density1<=0.3)||(balance1==0.555&&balance2==0.519&&density1==0.219)||(balance1==0.497&&balance2==0.551&&density1==0.313))
                printf("4\n");
        
    }
    else if(holes==0){
        if(holes2==0||holes2==1){
            if(center==1){
                if(((balance1>=0.4409)&&(balance1<=0.69904))&&((balance2>=0.52905)&&(balance2<=0.68304)))
                printf("7\n");
                else
                printf("1\n");
                
            }
            else if(center==0){
                if(((balance1>=0.4195)&&(balance1<=0.6975))&&((balance2>=0.51884)&&(balance2<=0.69504)))
                printf("7\n");
                else
                printf("1\n");
                
            
           }
     }
     else if(holes2-left_holes==2){
            printf("3\n");
            
    }
    
    else if(solution>0.5){
        printf("5\n");}
   
    else if(holes2-left_holes==2){
            printf("3\n");
            
    }
    else 
        printf("2\n");
        
    
    }
            }
    return 0;
        }


