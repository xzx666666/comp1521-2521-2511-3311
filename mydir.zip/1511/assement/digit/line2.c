 //writen by xiaozixin

#include<stdio.h>
#include"captcha.h"
int get_line2(int height,int width,int pixels[height][width]){
    int  start_row, start_column;
    int box_height, box_width,holes2=0;
    int holes_left,holes_right,left_holes=0;
    double h_density,density;
    double sum1=0,sum2=0,radio1=0,radio2=0,count=0;
    
    get_bounding_box(height, width, pixels, &start_row, &start_column, &box_height, &box_width);
   
    int left[box_height][box_width/2],right[box_height][box_width - (box_width/2)];
    int down[box_height];
    int x,y,box[box_height][box_width];
    
    get_box(height,width,pixels);
    
    for (x = box_height - 1;x >= 0;x--) {
        for (y = 0;y < box_width;y++) {
            box[x][y] = pixels[x][y];
            
        }
        
    }
    for(x=box_height-1;x>=0;x--){
        for(y=0;y<box_width;y++){
            if(y==x)
                box[x][y]=1;
               
        }
    }
    for(x=box_height-1;x>=0;x--){//left side
        for(y=(box_width/2)-1;y>=0;y--){
        left[x][y]=box[x][y];
        }
    }
   
    
    
   
    holes2 = get_holes(box_height,box_width,box,&h_density,&density);
    
    
    
         
        
        
  
        return holes3;
}

