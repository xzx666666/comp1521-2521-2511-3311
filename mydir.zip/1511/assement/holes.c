//written by xiao zixin
#include<stdio.h>
#include"captcha.h"

int get_holes(int height, int width, int pixels[height][width],double *h_density,double *density) {
    int holes[height][width], heig[height];
    int start_row, start_column, box_width, box_height, min_row, max_row, min_col, max_col;
    double all_pixel=0,pixel=0,num_pixel=0;
    int x, y, sum_holes;
    get_bounding_box(height, width, pixels, &start_row, &start_column, &box_height, &box_width);
    
    sum_holes = 0;
    
    
    for (x = height - 1;x >= 0;x--) {
        for (y = 0;y < width;y++) {
            holes[x][y] = pixels[x][y];
            if(holes[x][y]==0){
                holes[x][y]=-2;
                pixel++;
            }
            
            heig[x] =  3;
            all_pixel++;
            
        }
        

        
    }
   
    
    
    
    min_col = start_column;
    min_row = start_row;
    max_row = box_height + start_row - 1;
    max_col = box_width + start_column - 1;
    
    
    
        for(x=height-1;x>=0;x--)
    {
        for(y=0;y<width;y++){
            if ( (holes[x][y] == -2) && ( x == min_row))
                holes[x][y] = -1;

                if((holes[x][y] == -2) && (x == max_row))
                holes[x][y] = -1;

                if ((holes[x][y] == -2)&&(y == min_col))
                holes[x][y] = -1;

                if ((holes[x][y] == -2)&&(y == max_col)){
                holes[x][y] = -1;
            }
        }
    }
    
    
    for (x=height-1;x >= 0;x--) {
        for (y=0;y < width;y++) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
            
        }
    }
    for (x=height-1;x >= 0;x--) {
        for (y=width-1;y >=0;y--) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
            
        }
    }
    for (x=0;x <height;x++) {
        for (y=0;y <width;y++) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
        }
    }
    for (x=0;x <height;x++) {
        for (y=width-1;y >=0;y--) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
        }
    }
    for (y=0;y <width;y++) {
        for (x=height-1;x >=0;x--) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
            
        }
    }
    
    for (y=0;y <width;y++) {
        for (x=0;x <height;x++) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
        }
    }
    for (y=width-1;y>= 0;y--) {
        for (x=height-1;x >=0;x--) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
            
        }
    }
    for (y=width-1;y>= 0;y--) {
        for (x=0;x < height;x++) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }

        }
    }//1st
    
    
    for (x=height-1;x >= 0;x--) {
        for (y=0;y < width;y++) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }

            
        }
    }
    for (x=height-1;x >= 0;x--) {
        for (y=width-1;y >=0;y--) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
            
        }
    }
    for (x=0;x <height;x++) {
        for (y=0;y <width;y++) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
            
        }
    }
    for (x=0;x <height;x++) {
        for (y=width-1;y >=0;y--) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
        }
    }
    for (y=0;y <width;y++) {
        for (x=height-1;x >=0;x--) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
            
        }
    }
    
    for (y=0;y <width;y++) {
        for (x=0;x <height;x++) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }

            
        }
    }
    for (y=width-1;y>= 0;y--) {
        for (x=height-1;x >=0;x--) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
            
        }
    }
    for (y=width-1;y>= 0;y--) {
        for (x=0;x < height;x++) {
            if ((holes[x][y] == -2) && (holes[x + 1][y] == -1))
                holes[x][y] = -1;
            if((holes[x][y] == -2) && (holes[x - 1][y] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y - 1] == -1))
                holes[x][y] = -1;
            if ((holes[x][y] == -2) && (holes[x][y + 1] == -1)) {
                holes[x][y] = -1;
            }
            
        }
    }

    
    for ( x = height - 1;x >= 0;x--) {
        for (y = 0;y < width;y++) {
            if (holes[x][y] == -2) {
                heig[x] = 4;
                num_pixel++;
            }
                    
                             }
       
    }
                             
    x = height - 1;
    
    while (x >= 0) {
        if ((heig[x] == 4) && (heig[x + 1]==3)) {
            sum_holes++;
            }
                    x--;
    }
    *density=(all_pixel-pixel)/all_pixel;
    *h_density=num_pixel/all_pixel;
    
    
    return sum_holes;
}



