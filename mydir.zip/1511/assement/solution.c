#include<stdio.h>
#include"captcha.h"
int get_solution(int height,int width,int pixels[height][width] ){
    int  start_row, start_column;
    int box_height, box_width,holes2=0;
    int holes_left,holes_right,left_holes=0;
    double h_density,density;
    double sum1=0,sum2=0,radio1=0,radio2=0,solution,count=0;
    
    get_bounding_box(height, width, pixels, &start_row, &start_column, &box_height, &box_width);
   
    int left[box_height][box_width/2],right[box_height][box_width - (box_width/2)];
    int down[box_height];
    int x,y,box[box_height][box_width];
    
    get_box(height,width,pixels);
    
    for (x = box_height - 1;x >= 0;x--) {
        for (y = 0;y < box_width;y++) {
            box[x][y] = pixels[x][y];
            
        }
        
    }
    for(x=box_height-1;x>=0;x--){
        for(y=0;y<box_width;y++){
            if(y==box_width/2)
                box[x][y]=1;
               
        }
    }
    for(x=box_height-1;x>=0;x--){//left side
        for(y=(box_width/2)-1;y>=0;y--){
        left[x][y]=box[x][y];
        }
    }
   
    
    //int temp=right[52][16];
    //printf("%d %d\n %d %d",box_width,box_height,box_width/2,box_width - (box_width/2));
    /*for(x=box_height-1;x>0;x--){//right side
        for(y=box_width/2;y<box_width;y++){
        right[x][y - (box_width/2)-1]=box[x][y];
        }
    }
    
     print_image(box_height, box_width/2, right);
     
    for(x=(box_height/2)-1;x>=0;x--)
    {
        down[x]=3;
        }*/
   
    holes2 = get_holes(box_height,box_width,box,&h_density,&density);
    
    for(x=(box_height/2)-1;x>=0;x--)
    {
        down[x]=3;
        }
    
    for(x=box_height-1;x>=0;x--){
        
        for(y=(box_width/2)-1;y>=0;y--){
        if(left[x][y]==0){
            down[x]=-3;
            
            }
            
        }
        
     }
     
     for(x=box_height-1;x>=0;x--){
        if(down[x]==-3)
            sum1++;
            
      }
            x=0;  
        while(x < (box_height / 2)){
         if(down[x] == -3){
          count++;
          }
         x++;
            
        }

       solution= (double)count / (double)(box_height/2);
       printf("solution%lf,%lf,%f\n",(double)solution ,(double)count,(double)box_height/2);
        
     x=box_height-1;
         while (x >= 0) {
            if ((down[x] == 3) && (down[x + 1]==-3)) {
            left_holes++;
            
            }
                    x--;
    } 
        // printf("sum holes %d %lf\n",left_holes,sum1);
         
         
         radio1=(double)sum1/(2 * (double)box_height);
         //printf("ratio %lf",radio1);
            
        
   /* holes_right=get_holes(box_height,box_width/2,right,&h_density,&density);
    
    for(x=(box_height/2)-1;x>=0;x--)
    {
        down[x]=3;
        }
    for(x=box_height-1;x>=0;x--){
        for(y=box_width/2;y<box_width;y++){
        if(right[x][y]==-2){
            down[x]=-3;
            sum2++;
            }
        }
     }
     radio1=sum2/(2*box_width);*/
     
        return solution;
}

