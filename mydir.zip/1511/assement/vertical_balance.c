//wirtten by xiao zixin
//date 25/04/2017
#include <stdio.h>
#include "captcha.h"

double get_vertical_balance(int height, int width, int pixels[height][width]){
    int x,y;
    double vertical_balance,row_sum,n_black_pixels;
    row_sum = n_black_pixels = 0;
   
    for(x=0;x<height;x++)
    {
        for(y=0;y<width;y++)
        {
            if(pixels[x][y]==1){
                n_black_pixels++;//cululate n_black_pixels
                 row_sum=row_sum+x;//cululate column_sum
                
                }
                
        }
               
     }
            vertical_balance = ( (row_sum/n_black_pixels) + 0.5)/height;
            
           
    return vertical_balance;
}
    
