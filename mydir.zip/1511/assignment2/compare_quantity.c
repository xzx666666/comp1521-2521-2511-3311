//Writen by XIAO ZIXIN
//The date finish the assignment is 03/06/2017
#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include<string.h>

int compare_quantity(int num ,int num2){
    //compare two number
    if(num==0&&num2!=0){
    return num2;
    }
    else if(num2==0&&num!=0){
    return num;
    }
    else if(fuel_direction(num)*num<fuel_direction(num2)*num2){
        return num;
    } 
     else
        return num2;
     
}
