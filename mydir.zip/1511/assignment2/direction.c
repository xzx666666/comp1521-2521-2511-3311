//Writen by XIAO ZIXIN
//The date finish the assignment is 03/06/2017
#include <stdio.h>
#include "trader_bot.h"
#include "other.h"

int fuel_direction(int num){
    //find the direction
    
    if(num<0){
        return -1;
    }
    else
        return 1;
    
}

