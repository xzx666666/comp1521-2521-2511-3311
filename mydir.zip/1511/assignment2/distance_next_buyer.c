//Writen by XIAO ZIXIN
//The date finish the assignment is 03/06/2017


#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>

int distance_next_buyer(struct bot *b){
    //find the nearest buyer which is same name with cargo's coomdity in the next word.
    int i=0;
    int j=0;
    for(struct location *l=b->location;l!=NULL;l=l->next){
        if(l->quantity!=0&&l->type==LOCATION_BUYER&&j==0&&i!=0){
            if(strcmp(b->cargo->commodity->name,l->commodity->name)==0){
            return i;
            j++;
            }
            
        }
       
       if(i==5*b->maximum_move){//the item
            return 0;
            }
       i++;
     }
     return 0;
}
