#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>

int distance_next_seller(struct bot *b){
int i=0;
    for(struct location *l=b->location;l!=NULL;l=l->next){
        if(l->type==LOCATION_SELLER&&i!=0){
        
            return i;
           
        }
        i++;
        
     }
     return 0;
}
