//Writen by XIAO ZIXIN
//The date finish the assignment is 03/06/2017
#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
int distance_seller(struct bot *b){
    int petrol_length=0;
    int petrol_previous=0;
    for(struct location *l=b->location;l->type!=LOCATION_SELLER ;l=l->next){
        petrol_length++;
    }
    for(struct location *l=b->location;l->type!=LOCATION_SELLER ;l=l->previous){
        petrol_previous++;
    }

    if(petrol_length<=petrol_previous){
        return petrol_length;
    }
    else{
        petrol_previous=-1*petrol_previous;
        return petrol_previous;
    }
}

