//Writen by XIAO ZIXIN
//The date finish the assignment is 03/06/2017
#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include<string.h>

int nearest_buyer_pre_quantity(struct bot *b){
//find the quantity of nearest buyer which is same coomodity with current location in the previous
    int i=0;
    for(struct location *l=b->location;l!=NULL ;l=l->previous){
       if(l->type==LOCATION_BUYER&&i<=b->maximum_move){
           if(strcmp(b->location->commodity->name,l->commodity->name)==0) {
                return l->quantity;
            }
        }
       if(i>2*b->maximum_move){
            return 0;
       }
       i++;  
    }
    return 0;
}
