//Writen by XIAO ZIXIN
//The date finish the assignment is 03/06/2017

#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int next_petrol(struct bot *b){
//in the petrol station find the pervious petrol ststion
   
    int i=0;
    for(struct location *l=b->location;l!=NULL;l=l->next){
        if(l->type==LOCATION_PETROL_STATION&&i!=0){
            return i;
        }
        i++;
        
     }
     return 0;

}
