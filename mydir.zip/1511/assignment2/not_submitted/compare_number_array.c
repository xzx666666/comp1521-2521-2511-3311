#include <stdio.h>
#include "trader_bot.h"
#include "other.h"

int compare_nember_array(int length,double array[length]){
 	int x, y, count=0;
 	
 	for(x=0;x<length;x++){
    	for(y=0;y<length;y++){
        	if(array[x]<=array[y]){
            	count++;
        	}
    	}
    	if(count == length){
        	return array[x];
    	}
	}

 }
