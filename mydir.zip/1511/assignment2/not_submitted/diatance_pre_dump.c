#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>

int distance_next_dump(struct bot *b){
int i=0;

    for(struct location *l=b->location;l!=NULL;l=l->next){
        i++;
        if(l->quantity!=0&&l->type==LOCATION_BUYER&&i>=3*b->maximum_move){
            return 0;
            }
            
     }
     return 0;
}
