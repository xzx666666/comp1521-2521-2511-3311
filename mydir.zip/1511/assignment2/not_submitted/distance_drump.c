#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int distance_dump(struct bot *b ){
int petrol_length=0;
    
    for(struct location *l=b->location;l!=NULL;l=l->next){
        if(l->type!=LOCATION_BUYER&&l->type!=LOCATION_SELLER&&petrol_length!=0){
          return petrol_length;  
        }
        petrol_length++;
        if(petrol_length>=300){
            return 1;
        }
    }
    return 0;
    
}

        
