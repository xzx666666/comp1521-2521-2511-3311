#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>

int distance_pre_seller(struct bot *b){
int i=1;
    for(struct location *l=b->location;l!=NULL;l=l->previous){
        if(l->type==LOCATION_SELLER&&i!=0){
            return -i;
        }
        i++;
        
     }
     return 0;
     
}
