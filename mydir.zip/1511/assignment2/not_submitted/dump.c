#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int distance_dump_other(struct bot *b ){
int petrol_length=0;
    int petrol_previous=0;
    for(struct location *l=b->location;l->type!=LOCATION_BUYER&&l->type!=LOCATION_SELLER;l=l->next){
        petrol_length++;
    }
     for(struct location *l=b->location;l->type!=LOCATION_BUYER&&l->type!=LOCATION_SELLER;l=l->previous){
        petrol_previous++;
    }
    
        return petrol_length;
    
}

