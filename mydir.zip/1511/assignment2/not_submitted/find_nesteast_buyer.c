#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int find_nesteast_buyer(struct location *l,char *name, int *price1, int *quantity1 ){
	int j=0;
	
	for(struct location *location=l;location!=NULL;location=location->next){
        
		if(location->type==LOCATION_BUYER ){
			if(strcmp(&name, location->commodity->name) == 0)
			
			*price1=location->price;
			*quantity1=location->quantity;
			return j;
		}
		j++;
   	}
    		
}
