#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int find_nesteast_buyer_p(struct location *l,char *name, int *price2, int *quantity2 ){
	int j=0;
	
	for(struct location *location=l;location!=NULL;location=location->previous){

		if(location->type==LOCATION_BUYER ){
			if(strcmp(&name, location->commodity->name) == 0)
			
			*price1=location->price;
			*quantity1=location->quantity;
			return j;
		}
		j++;
   	}
    		
}
