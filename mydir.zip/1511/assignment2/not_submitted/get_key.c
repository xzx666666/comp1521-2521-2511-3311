#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int get_key(struct bot *b){
int i=0;

    for(struct location *l=b->location;l!=NULL;l=l->next){//find the same name seller in the next max move 
        if(l->type==LOCATION_BUYER&&i<b->maximum_move){
            if (strcmp(b->commodity->name, l->commodity->name) == 0) 
                
                return 1;
     
             }
            else
                return 0;
        }
        i++;
        return 0;
}
