char get_name(struct bot *b){
    if(bot->location->type==LOCATION_SELLER)
        return b->location->commdity;

}


