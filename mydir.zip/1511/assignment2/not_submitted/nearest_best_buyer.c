#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include<string.h>

int nearest_best_buyer(struct bot *b){ //in the two*maxium move to find best seller and the commdity name
    int diatance=0; 
    int i=0;
    int array[2*maximum_move];
    for(struct location *l=b->location;l!=NULL;l=l->next){//next
        if((l->type==LOCATION_SELLER)&&(i<=b->maximum_move)){
            array[i]=diatance;
            i++;
            struct *m=l;
            for(struct location *location=m;l!=NULL;location=location->next){
                
            }
        }
        distance++;
     }
     distance=0;
    for(struct location *l=b->location;l!=NULL;l=l->previous){//next
        if((l->type==LOCATION_SELLER)&&(i<=b->maximum_move)){
            array[i]=-diatance;
            i++;
        }
        distance++;
     }
    
