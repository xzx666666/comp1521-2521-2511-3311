
#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include<string.h>

int nearest_buyer_quantity(struct bot *b){//in the two*maxium move to find best seller and the commdity name
    
    if(distanse_buyer(b)>0){
        for(struct location *l=b->location;l!=NULL;l=l->next){
               if(l->type==LOCATION_BUYER) {
                    return l->quantity;
                }
            
        }
    }
    else{
    
        for(struct location *l=b->location;l!=NULL ;l=l->previous){
           if(l->type==LOCATION_BUYER) {
                    return l->quantity;
                }
            
        }
    }
}
