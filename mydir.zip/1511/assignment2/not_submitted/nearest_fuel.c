#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>

int nearest_fuel(struct bot *b){
    int petrol_length=0;
    int petrol_previous=0;
    for(struct location *l=b->location;l->type!=3;l=l->next){
        petrol_length++;
    }
    for(struct location *l=b->location;l->type!=3;l=l->previous){
        petrol_previous++;
    }
    
    if(petrol_length<=petrol_previous){
        return petrol_length;
    }
    else{
        petrol_previous=-1*petrol_previous;
        return petrol_previous;
    }
}

