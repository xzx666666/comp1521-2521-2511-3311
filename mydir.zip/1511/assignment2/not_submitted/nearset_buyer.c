#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int nearest_buyer(struct bot *b ){
    
}
