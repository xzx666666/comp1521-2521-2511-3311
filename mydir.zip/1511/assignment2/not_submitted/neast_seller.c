#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int nearest_seller(struct bot *b ){//in the two*maxium move to find best seller and the commdity name
    int seller_length[2*b->maximum_move]={0};
    int max;
    double ratio_profile1,ratio_profile2;
    int i=0,j=0;
    double compare_benefit[2*b->maximum_move]={0.0};
    int price1,quantity1;
    int price2,quantity2;
    int distance;
    double max_array;
   

    for(struct location *l=b->location;l!=NULL;l=l->next){//next
        
        if((l->type==LOCATION_SELLER)&&(i<=b->maximum_move)){

			struct location *m=l;
			
			distance_next_buyer_next=find_nesteast_buyer(m,l->commdity->name,&price1,&quantity1);//nearesr distance of next buyer
			
			distance_next_buyer_p= find_nesteast_buyer_p(m, l->commdity->name,&price2,&quantity2 );//nearesr distance of previous buyer
			
			if(quantity1>l->quantity){//compare the quantuty i can sell
				quantity1=l->quantity;
			}

			
			if(quantity2>l->quantity){//compare the quantuty i can sell
				quantity2=l->quantity;
			}

		    ratio_profile1=((double)(price1*quantity1)-(double)(l->price*l->quantity1)-((double)(i+distance_next_buyer)*200.0))/(double)(quantity1*(l->commodity->weight));//every kg i can earn in next
		    
		    ratio_profile2=((double)(price2*quantity2)-(double)(l->price*l->quantity2)-((double)(i+distance_next_buyer_p)*200.0))/(double)(quantity2) * (double)(l->commodity->weight);//every kg i can earn in previous
		    if(ratio_profile1>=ratio_profile2)
			    compare_benefit[j]=ratio_profile1;
			else{
			    compare_benefit[j]=ratio_profile2;
			    }
			    seller_length[j]=i;
			j++;
        	
		}
		i++;

	}

	i=0;
	

    /*for(struct location *l=b->location;l!=NULL;l=l->next){//next
        
        if((l->type==LOCATION_SELLER)&&(i<=b->maximum_move)){

			struct location *m=l;
			
			distance_next_buyer_next=find_nesteast_buyer(m,l->commodity->name,&price1,&quantity1);//nearesr distance of next buyer
			
			distance_next_buyer_p= find_nesteast_buyer_p(m, l->commodity->name,&price2,&quantity2 );//nearesr distance of previous buyer
			
			if(quantity1>l->quantity){//compare the quantuty i can sell
				quantity1=l->quantity;
			}
			if(quantity2>l->quantity){//compare the quantuty i can sell
				quantity2=l->quantity;
			}

		    ratio_profile1=((double)(price1*quantity1)-(double)(l->price*l->quantity1)-(double)((i+distance_next_buyer)*200.0))/(double)(quantity1*(l->commodity->weight));//potential every kg i can earn in next
		    
		    ratio_profile2=((double)(price2*quantity2)-(double)(l->price*l->quantity2)-(double)((i+distance_next_buyer_p)*200.0))/(double)(quantity2*(l->commodity->weight));//potential every kg i can earn in previous
		    
		     if(ratio_profile1>=ratio_profile2)
			    compare_benefit[j]=ratio_profile1;
			else{
			    compare_benefit[j]=ratio_profile2;
			    }
			
			seller_length[j]=-i;
			j++;
        	
		}
		i++;

	}*/

		if(j==0){//the situation when the seller is not in the maxiumn move
		
		    distance=fuel_direction(distanse_seller(bot))*b->maximum_move;
		    return distance;
		}
	    
	    else{    //find the stuation of max ratio_porile
	        max=compare_nember(compare_benefit[j],j);
	        max_array=compare_nember_array(compare_benefit[j],j);
	        if(max_array<0){ //
	        
	            distance=fuel_direction(distanse_seller(bot))*b->maximum_move;
	            return distance; 
	        }
	        else //return length of the suation
	            return seller_length[max];
	        }

}
