#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include<string.h>

int best_price_next(struct bot *b){
int i=0;
double profile;
 for(struct location *l=b->location;l!=NULL;l=l->next){
    if(l->type==LOCATION_BUYER&&i<=b->maximum_move){
         if(strcmp(b->location->commodity->name,l->commodity->name)==0){
            profile=(double)(l->price-b->location->price-i*200)*((double)b->maximum_cargo_weight/(double)b->location->commodity->weight);
            
            if(profile<5000)
                return 0;
             else
                return i;
          }
      }
      
      
       if(i>2*b->maximum_move){
        return 0;
      
      }
   
      i++;
 }
 return 0;
}
         
