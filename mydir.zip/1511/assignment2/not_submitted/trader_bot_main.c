#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>

char *get_bot_name(void){
    return "xiao_zixin1221";
}

void get_action(struct bot *bot, int *action, int *n){
   
    int nearest_distance= nearest_fuel(bot);
    int num=fuel_direction(nearest_distance);
    
    
    
    
    if(bot->fuel<=4*bot->maximum_move){  //it can make enought fuel to catch cargo
        if(bot->location->type!=LOCATION_PETROL_STATION){
            *action=ACTION_MOVE;
            
            if(num*nearest_distance>=bot->maximum_move){
                
                *n= num*bot->maximum_move;
            }
            
            else
                *n=nearest_distance;
            
        }
        else if((bot->location->type==LOCATION_PETROL_STATION)&&(bot->location->quantity==0)){
            
            *action=ACTION_MOVE;
            
            if((fuel_direction(next_petrol(bot))*next_petrol(bot))<=(fuel_direction(previous_petrol(bot))*previous_petrol(bot))){
                if(fuel_direction(next_petrol(bot))<bot->maximum_move)
                    *n=next_petrol(bot);
                else
                    *n=bot->maximum_move;
            }
            else{
                if(fuel_direction(previous_petrol(bot))<bot->maximum_move)
                  *n=previous_petrol(bot);
                else
                  *n=-bot->maximum_move;
                
           } 

            
        }
        else if ((bot->location->type==LOCATION_PETROL_STATION )&&(bot->fuel)<(bot->fuel_tank_capacity)){
            *action=ACTION_BUY;
            
            *n=bot->fuel_tank_capacity - bot->fuel;
        }
        
        
    }
    //buy and sell something
    
    
    else if(bot->location->type==LOCATION_SELLER){
        
        struct location *l=bot->location;
        if(l->quantity==0){
        //if(cargo!=NULL&&no thing in the word)
            *action=ACTION_MOVE;
            
            if(fuel_direction(distance_next_seller(bot))*distance_next_seller(bot)<bot->maximum_move||fuel_direction(distance_pre_seller(bot))*distance_pre_seller(bot)<bot->maximum_move){
                if((fuel_direction(distance_next_seller(bot))*distance_next_seller(bot))>(fuel_direction(distance_pre_seller(bot))*distance_pre_seller(bot)))
                    *n=distance_pre_seller(bot);//next seller
                else
                    
                    *n=distance_next_seller(bot);
                
            }
            
            else{
                if(fuel_direction(distance_next_seller(bot))*distance_next_seller(bot)>fuel_direction(distance_pre_seller(bot))*distance_pre_seller(bot))
                    *n=-bot->maximum_move;
                else
                    *n=bot->maximum_move;
            }
            
        }
        else if(bot->cargo==NULL&&l->quantity!=0){
            *action=ACTION_BUY;
            
            if((bot->maximum_cargo_weight/l->commodity->weight+1)*l->price<=(bot->cash-200*(bot->fuel_tank_capacity - bot->fuel)))
            *n=bot->maximum_cargo_weight/l->commodity->weight+1;
            else
            *n=(bot->cash-200*(bot->fuel_tank_capacity - bot->fuel))/l->price;
        }
        else{
            
                *action=ACTION_MOVE;
                //if nothing in the word go to dump
                if(distance_next_buyer(bot)==0&&distance_pre_buyer(bot)==0)
                     *n=distance_drump(bot);
                else if(distance_next_buyer(bot)!=0&&distance_pre_buyer(bot)!=0){
                     if(fuel_direction(distance_next_buyer(bot))*distance_next_buyer(bot)<bot->maximum_move||fuel_direction(distance_pre_buyer(bot))*distance_pre_buyer(bot)<bot->maximum_move){
                        if((fuel_direction(distance_next_buyer(bot))*distance_next_buyer(bot))>(fuel_direction(distance_pre_buyer(bot))*distance_pre_buyer(bot)))
                            *n=distance_pre_buyer(bot);//next seller
                        else
                            *n=distance_next_buyer(bot);
                        
                    }
                    else{
                        if((fuel_direction(distance_next_buyer(bot))*distance_next_buyer(bot))>(fuel_direction(distance_pre_buyer(bot))*distance_pre_buyer(bot)))
                            *n=-bot->maximum_move;
                        else
                            *n=bot->maximum_move;
                    }
                    
                }
                
                else{ 
                     if(distance_next_buyer(bot)==0&&distance_pre_buyer(bot)!=0)
                            *n=distance_pre_buyer(bot);
                     else if(distance_pre_buyer(bot)==0&&distance_next_buyer(bot)!=0)
                            *n=distance_next_buyer(bot);
                        
                    }
               
            }
         
    }
    
    
    else if(bot->location->type==LOCATION_BUYER){//buyer
        struct location *l=bot->location;
        if(bot->cargo!=NULL&&l->quantity!=0){
            if(strcmp(bot->cargo->commodity->name,l->commodity->name)==0){
                *action=ACTION_SELL;
                
                *n=bot->cargo->quantity;
                
            }
            else {
                *action=ACTION_MOVE;
                //if nothing in the word go to dump
                if(distance_next_buyer(bot)==0&&distance_pre_buyer(bot)==0)
                *n=distance_drump(bot);
                else if(distance_next_buyer(bot)!=0&&distance_pre_buyer(bot)!=0){
                     if(fuel_direction(distance_next_buyer(bot))*distance_next_buyer(bot)<bot->maximum_move||fuel_direction(distance_pre_buyer(bot))*distance_pre_buyer(bot)<bot->maximum_move){
                        if((fuel_direction(distance_next_buyer(bot))*distance_next_buyer(bot))>(fuel_direction(distance_pre_buyer(bot))*distance_pre_buyer(bot)))
                            *n=distance_pre_buyer(bot);//next seller
                        else
                            *n=distance_next_buyer(bot);
                        
                    }
                    if((fuel_direction(distance_next_buyer(bot))*distance_next_buyer(bot))>(fuel_direction(distance_pre_buyer(bot))*distance_pre_buyer(bot)))
                        *n=-bot->maximum_move;
                    else
                        *n=bot->maximum_move;
                    
                    
                } 
                
                else{
                    if(distance_next_buyer(bot)==0&&distance_pre_buyer(bot)!=0)
                    *n=distance_pre_buyer(bot);
                     else if(distance_next_buyer(bot)!=0&&distance_pre_buyer(bot)==0)
                    *n=distance_next_buyer(bot);
                    
                    
                }
                
            }
        }
        else{
            *action=ACTION_MOVE;
            if(distance_seller(bot)<bot->maximum_move)
                *n=distance_seller( bot);//neastest_seller_distance;
            else
                *n=bot->maximum_move;
        }
        
        
    }
    
    
    else{
        if(bot->cargo==NULL){
            *action=ACTION_MOVE;
            if((fuel_direction(distance_seller(bot))*distance_seller(bot))<bot->maximum_move)
                *n=distance_seller(bot);//neastest_seller_distance;
            else
                *n=fuel_direction(distance_seller(bot))*bot->maximum_move;
        }
        else{
            
            //if(location_drump && no thing in the word)
            if(bot->location->type==LOCATION_DUMP&&distance_next_buyer(bot)==0&&distance_pre_buyer(bot)==0){
            *action=ACTION_DUMP;
            
            }
            *action=ACTION_MOVE;
            if((fuel_direction(distance_buyer(bot))*distance_buyer(bot))<bot->maximum_move)
                *n=distance_buyer(bot);//neastest_seller_distance;
            else
                *n=fuel_direction(distance_buyer(bot))*bot->maximum_move;
        }
        
    }
}


