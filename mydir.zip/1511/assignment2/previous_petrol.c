//Writen by XIAO ZIXIN
//The date finish the assignment is 03/06/2017
#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int previous_petrol(struct bot *b){
//in the petrol station find the next petrol ststion
    int i=0;
    for(struct location *l=b->location;l!=NULL;l=l->previous){
        if(l->type==LOCATION_PETROL_STATION&&i!=0){
            return -i;
        }
        i++;
        
     }
     return 0;

}
