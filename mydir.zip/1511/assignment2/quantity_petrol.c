//Writen by XIAO ZIXIN
//The date finish the assignment is 03/06/2017
#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
int quantity_petrol(struct bot *b){
//find quantity in the nearest next petrol
    for(struct location *l=b->location;l!=NULL;l=l->next){
        if(l->type==LOCATION_PETROL_STATION){
            return l->quantity;
        }
       
     }
     return 0;

}
