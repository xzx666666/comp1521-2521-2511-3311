//Writen by XIAO ZIXIN
//The date finish the assignment is 03/06/2017
//This code is aim to get *action and *n 
//I divide the three part for this code. one is ensure the bot have enought fule the move . one is the situation of the bot's cargo is full and not full. 

#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
char *get_bot_name(void){
    return "xiao_zixin1221";
}
void get_action(struct bot *bot, int *action, int *n){
   int quantity1;
    int nearest_distance= nearest_fuel(bot);
    int num=fuel_direction(nearest_distance);
    struct location *l=bot->location;
    
    if(bot->fuel<=3*bot->maximum_move){ 
    //Make sure the fuel can meet the bot walk for 3 times max work .
            
            if(bot->location->type!=LOCATION_PETROL_STATION){
            //1.the bot not in the potrol sation and bot have to move to neastest petrol station.and the bot have check quantity of fuel is enought in the nearest petrol station. 
                
                if(bot->cargo!=NULL&&bot->location->type==LOCATION_BUYER&&bot->location!=0){
                    
                    *action=ACTION_SELL;
                    *n=bot->cargo->quantity;
                }
                
                
                if( quantity_petrol(bot)!=0){
                //this code is to make sure the the nearest fuel station have enought fuel to buy
                    *action=ACTION_MOVE;
                    if(num*nearest_distance>=bot->maximum_move){
                        
                        *n= num*bot->maximum_move;
                    }
                    
                    else
                        *n=nearest_distance;
                }
                else{
                //the situation that the nearest petrol station no fuel. move to another fuel station 
                    *action=ACTION_MOVE;
                    nearest_distance=compare_quantity(next_petrol(bot),previous_petrol(bot));
                
                    if(fuel_direction(nearest_distance)<bot->maximum_move)
                        *n=nearest_distance;
                    else if(nearest_distance<0)
                      
                      *n=-bot->maximum_move;
                    else
                      *n=bot->maximum_move;
                
                }
            }
            else if((bot->location->type==LOCATION_PETROL_STATION)&&(bot->location->quantity==0)){
            //2.when teh bot in a petrol station and no fuel. the bot have to move another petrol station. 
                
                *action=ACTION_MOVE;
                nearest_distance=compare_quantity(next_petrol(bot),previous_petrol(bot));
                
                if(fuel_direction(nearest_distance)<bot->maximum_move)
                    *n=nearest_distance;
                else if(nearest_distance<0)
                  
                  *n=-bot->maximum_move;
                else
                  *n=bot->maximum_move;
                    
               } 

                
            
            else if ((bot->location->type==LOCATION_PETROL_STATION )&&(bot->fuel)<(bot->fuel_tank_capacity)){
            //3. there are enought fuel in this location , just buy fuel.
                *action=ACTION_BUY;
                
                *n=bot->fuel_tank_capacity - bot->fuel;
            }
            
          } 
        
    else if(bot->cargo!=NULL){
    //the cargo  have something and the bot have to find the the same commodity buyer and seller the item.
        if(bot->location->type==LOCATION_SELLER){
            
            *action=ACTION_MOVE;
            int distance_buyer_move;
            
            distance_buyer_move=compare_quantity(distance_next_buyer(bot),distance_pre_buyer(bot));
          
            if(fuel_direction(distance_buyer_move)*distance_buyer_move<bot->maximum_move)
                *n=distance_buyer_move;//next seller
              
            
            else{
                if(distance_buyer_move<0)
                    *n=-bot->maximum_move;
                else
                    *n=bot->maximum_move;
            }

    
    }
        else if(bot->location->type==LOCATION_BUYER){
           
            
            if(bot->location->quantity>=(bot->maximum_cargo_weight)/(l->commodity->weight-10)){
            
                if(strcmp(bot->cargo->commodity->name,l->commodity->name)==0){
                       
                    *action=ACTION_SELL;
                
                    *n=bot->cargo->quantity;
                }
                
                
                else {
                    *action=ACTION_MOVE;
                    int distance_buyer_move;
                    
                    distance_buyer_move=compare_quantity(distance_next_buyer(bot),distance_pre_buyer(bot));
                  
                if(fuel_direction(distance_buyer_move)*distance_buyer_move<bot->maximum_move)
                    *n=distance_buyer_move;//next seller
                  
                
                else{
                    if(distance_buyer_move<0)
                        *n=-bot->maximum_move;
                    else
                        *n=bot->maximum_move;
                }
             }
         }
        else {
            *action=ACTION_MOVE;
            int distance_buyer_move;
            
            distance_buyer_move=compare_quantity(distance_next_buyer(bot),distance_pre_buyer(bot));
  
            if(fuel_direction(distance_buyer_move)*distance_buyer_move<bot->maximum_move)
                *n=distance_buyer_move;
              
            
            else{
                if(distance_buyer_move<0)
                    *n=-bot->maximum_move;
                else
                    *n=bot->maximum_move;
            }
                
         }
        
     }
        else if(bot->location->type==LOCATION_DUMP){
            int distance_buyer_move;
            
            distance_buyer_move=compare_quantity(distance_next_buyer(bot),distance_pre_buyer(bot));
          
            *action=ACTION_MOVE;
            if(fuel_direction(distance_buyer_move)*distance_buyer_move<bot->maximum_move)
                *n=distance_buyer_move;
              
            
            else{
                if(distance_buyer_move<0)
                    *n=-bot->maximum_move;
                else
                    *n=bot->maximum_move;
            }
        
        }
        else{   
            *action=ACTION_MOVE;
            int distance_buyer_move;
            
            distance_buyer_move=compare_quantity(distance_next_buyer(bot),distance_pre_buyer(bot));
          
            if(fuel_direction(distance_buyer_move)*distance_buyer_move<bot->maximum_move)
                *n=distance_buyer_move;//next seller
              
            
            else{
                if(distance_buyer_move<0)
                    *n=-bot->maximum_move;
                else
                    *n=bot->maximum_move;
            }
        
        }
    
    }
    else if(bot->cargo==NULL){
    //the bot's cargo do not have any thing find the seller and buy the item.
       
        if(bot->location->type==LOCATION_SELLER){
            int profile;
            
            profile=compare_quantity(best_price_pre(bot),best_price_next(bot));
            
            quantity1=compare_quantity(nearest_buyer_next_quantity(bot),nearest_buyer_pre_quantity(bot));
            
            if(bot->location->quantity>=(bot->maximum_cargo_weight)/(l->commodity->weight-10)&&quantity1>=(bot->maximum_cargo_weight)/(l->commodity->weight-10)&&profile!=0){//buy the commodity except the seller which is not have any item and not any buyer and will sell this item
               
                *action=ACTION_BUY;
                *n=quantity1;
               
            }
            else{
                *action=ACTION_MOVE;
                *n=distance_next_seller(bot);
            }
        }
       
        else{
            *action=ACTION_MOVE;
           
            *n=distance_seller(bot);
        }
    
    }
}
    
    
    
    
    
    
    
    
    
    
    
