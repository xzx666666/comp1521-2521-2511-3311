#include <stdio.h>
#include "trader_bot.h"
#include "other.h"
#include <string.h>
char *get_bot_name(void){
    return "xiao_zixin1221";
}
void get_action(struct bot *bot, int *action, int *n){
   int quantity;
    int nearest_distance= nearest_fuel(bot);
    int num=fuel_direction(nearest_distance);
    if(bot->fuel<=3*bot->maximum_move){  //it can make enought fuel to catch cargo
            if(bot->location->type!=LOCATION_PETROL_STATION){
                *action=ACTION_MOVE;
                if( quantity_petrol(bot)!=0){//the nearest potrol location!=0
                    if(num*nearest_distance>=bot->maximum_move){
                        
                        *n= num*bot->maximum_move;
                    }
                    
                    else
                        *n=nearest_distance;
                }
                else{
                    *action=ACTION_MOVE;
                    nearest_distance=compare_quantity(next_petrol(bot),previous_petrol(bot));
                
                    if(fuel_direction(nearest_distance)<bot->maximum_move)
                        *n=nearest_distance;
                    else if(nearest_distance<0)
                      
                      *n=-bot->maximum_move;
                    else
                      *n=bot->maximum_move;
                
                }
            }
            else if((bot->location->type==LOCATION_PETROL_STATION)&&(bot->location->quantity==0)){
                
                *action=ACTION_MOVE;
                    nearest_distance=compare_quantity(next_petrol(bot),previous_petrol(bot));
                
                    if(fuel_direction(nearest_distance)<bot->maximum_move)
                        *n=nearest_distance;
                    else if(nearest_distance<0)
                      
                      *n=-bot->maximum_move;
                    else
                      *n=bot->maximum_move;
                    
               } 

                
            
            else if ((bot->location->type==LOCATION_PETROL_STATION )&&(bot->fuel)<(bot->fuel_tank_capacity)){
                *action=ACTION_BUY;
                
                *n=bot->fuel_tank_capacity - bot->fuel;
            }
            
          } 
        
    else if(bot->cargo!=NULL){
        if(bot->location==LOCATION_SELLER){//buy or find another seller or another buyer
        
        *action=ACTION_MOVE;
        int distance_buyer_move;
        distance_buyer_move=compare_quantity(distance_next_buyer(bot),distance_pre_buyer(bot));
          
            if(fuel_direction(distance_buyer_move)<bot->maximum_move)
                *n=distance_buyer_move;//next seller
              
            
            else{
                if(distance_buyer_move<0)
                    *n=-bot->maximum_move;
                else
                    *n=bot->maximum_move;
            }

    
    }
        if(bot->location==LOCATION_BUYER){//find the same name buyer
            if(bot->location->quantity!=0){
                if(strcmp(bot->cargo->commodity->name,l->commodity->name)==0){
                    *action=ACTION_SELL;
                    
                    *n=bot->cargo->quantity;
                }
                else {
                *action=ACTION_MOVE;
        int distance_buyer_move;
        distance_buyer_move=compare_quantity(distance_next_buyer(bot),distance_pre_buyer(bot));
          
            if(fuel_direction(distance_buyer_move)<bot->maximum_move)
                *n=distance_buyer_move;//next seller
              
            
            else{
                if(distance_buyer_move<0)
                    *n=-bot->maximum_move;
                else
                    *n=bot->maximum_move;
            }
                
         }
        }
        else if(bot->location==LOCATION_DUMP){//nothing can be find in the word.
        *action=ACTION_MOVE;
        int distance_buyer_move;
        distance_buyer_move=compare_quantity(distance_next_buyer(bot),distance_pre_buyer(bot));
          
            if(fuel_direction(distance_buyer_move)<bot->maximum_move)
                *n=distance_buyer_move;//next seller
              
            
            else{
                if(distance_buyer_move<0)
                    *n=-bot->maximum_move;
                else
                    *n=bot->maximum_move;
            }
        
        }
        else{   //move to drump , move to buyer ,
            *action=ACTION_MOVE;
        int distance_buyer_move;
        distance_buyer_move=compare_quantity(distance_next_buyer(bot),distance_pre_buyer(bot));
          
            if(fuel_direction(distance_buyer_move)<bot->maximum_move)
                *n=distance_buyer_move;//next seller
              
            
            else{
                if(distance_buyer_move<0)
                    *n=-bot->maximum_move;
                else
                    *n=bot->maximum_move;
            }
        
        }
    
    }
    else if(bot->cargo==NULL){
    if(bot->location==LOCATION_SELLER){
            if(bot->location->quantity!=0){
                *action=ACTION_BUY;
                *n=bot->location->quantity;
            }
            else{
                *action=ACTION_MOVE;
                *n=distance_seller(bot);
            }
        }
        if(bot->location==LOCATION_BUYER){
            *action=ACTION_MOVE;
            *n=distance_seller(bot);
        
        }
        
        else{
            *action=ACTION_MOVE;
            *n=distance_seller(bot);
        
        }
    
    
    
    }
    
    
    
    
    
    
    
    
    
    
    
