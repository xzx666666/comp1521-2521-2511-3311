#include<stdio.h>
int main (void)
{
	int x,y,z;
	printf ("Enter your age : ");
	scanf("%d",&x);
	y=x/2+7;
	z=2*(x-y)+x;
	if(z<y) {
	printf("You are too young to be dating.\n");}
	else {
	printf("Your dating range is %d to %d years old.\n",y,z);}
	return 0;
}
	
	
