#include<stdio.h>
int main (void)
{
    int x,y,z,Volume,Area, Length;
    printf("Please enter prism length: ");
    scanf("%d",&x);
    printf("please enter prism width: ");
    scanf("%d",&y);
    printf("please enter prism height: ");
    scanf("%d",&z);
    Volume=x*y*z;
    Area=2*(x*y+z*y+x*z);
    Length=4*(x+y+z);
    printf("the volum of prism is %d\n",Volume);
    printf("the area of prism is %d\n",Area);
    printf ("the length of prism is %d\n",Length);
    return 0;
}

