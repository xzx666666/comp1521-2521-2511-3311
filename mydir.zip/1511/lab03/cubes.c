#include <stdio.h>

int main(void)
{
    int num,x;
    printf("Enter how many cubes: ");
    scanf("%d",&num);
    x=1;
    while(x<=num)
        {
        printf("%d^3 = %d\n",x,x*x*x);
        x=x+1;
        }
    return 0;
}
    
