#include<stdio.h>
int main(void)
{
    int x,y,i;
    printf("Enter start year: ");
    scanf("%d",&x);
    printf("Enter finish year: ");
    scanf("%d" , &y);
    printf("The leap years between %d and %d are:",x,y);
        i=x;
        while(i<=y)
        {
            if (i%4!=0){
                ;
            }
            else if (i%100!=0){
                printf("%d ",i);
            }
            else if (i%400!=0)
            {
            ;
            }
            else
            {
                printf("%d ",i);
            }
            i=i+1;
        }
     printf("\n");
     return 0;
}

