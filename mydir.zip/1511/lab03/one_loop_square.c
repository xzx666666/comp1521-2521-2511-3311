#include<stdio.h>
int main(void)
{   
    int size,i;
    printf("Square size: ");
    scanf("%d",&size);
    i=1;
    
    while(i<=size*size)
    {   
        printf("*");
       
        if (i%size==0)
        {
            printf("\n");
            
        }
        
        i=i+1;
     
     }
      
    return 0;
}  
