#include<stdio.h>
int main(void)
{
    int x,y,z;
    printf("Enter integer: ");
    scanf("%d"&x);
    printf("Enter integer: ");
    scanf("%d"&y);
    printf("Enter integer: ");
    scanf("%d"&z);
    
