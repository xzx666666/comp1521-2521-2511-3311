#include<stdio.h>
int main(void)
{
    int a,b,c,x;
    printf("Enter integer: ",a);
    scanf("%d",&a);
    printf("Enter integer: ",b);
    scanf("%d",&b);
    printf("Enter integer: ",c);
    scanf("%d",&c);
    x=a*(a>b&&a>c)||b*(b>c&&b>a)||c*(c>a&&c>b);
    printf("%d\n",x);//a*(a>b&&a>c)||b*(b>c&&b>a)||c*(c>a&&c>b));
    
    printf("",a,b,c,a*(a>b&&a>c)||b*(b>c&&b>a)||c*(c>a&&c>b),a*(a<b&&a<c)||b*(b<a&&b<c)||c*(c<a&&c<b));
    
    printf("%d\n",a*(a<b&&a<c)||b*(b<a&&b<c)||c*(c<a&&c<b));
    return 0;
}