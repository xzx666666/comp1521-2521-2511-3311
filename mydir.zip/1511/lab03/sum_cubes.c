#include <stdio.h>

int main(void)
{
    int num,x,y;
    printf("Sum how many cubes? ");
    scanf("%d",&num);
    x=1,y=1;
    printf("%d^3",x); 
    while(x<num)
        {   
            x=x+1;
            printf(" + ");
            printf("%d^3",x); 
            
            y=y+x*x*x;
            }
        printf(" = %d\n",y);
    return 0;
}
    
