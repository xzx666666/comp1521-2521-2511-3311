#include<stdio.h>
int main(void)
{
    int x,i,j,sum,m;
    printf("Enter number: ");
    scanf("%d",&x);
    i=2;
    j=0;
    m=2;
    sum=x;
        
        while(m<sum)
        {
           if(x%m==0)
           {    
                printf("The prime factorization of %d is:\n",x);
                m=x;
           }
            m++;
        
        }
        while(i<sum)
        {
            if(sum%i==0){
                printf("%d",i);
                printf(" * ");
                sum=sum/i;
                j=j+1;
            }
            else{
                i=i+1;
            }
            }
        
        if(j!=0)
            printf("%d = %d\n",i,x);
        else
            printf("%d is prime\n",x); 
    return 0;
}      
        
        
        
    
