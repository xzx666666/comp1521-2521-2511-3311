#include<stdio.h>
int main(void)
{
    int x,i;
    printf("Enter number: ");
    scanf("%d",&x);
    i=1;
    while (x>i)
    {
    
        if (i%3==0||i%5==0)
        printf("%d\n",i);
    i++;
    }
    return 0;
}


