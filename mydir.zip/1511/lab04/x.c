#include<stdio.h>
int main(void)
{   
    int x,i,j;
    printf("Enter size: ");
    scanf("%d",&x);
    for(i=1;i<=x;i++)
    {   
        for(j=1;j<=x;j++)
        {
            if(i==j||j+i==x+1)
            printf("*");
            else
            printf("-");
            if (j==x)
            printf("\n");
        }
     }
      
    return 0;
}  

