/*
XIAO ZIXIN write on 02/04/2017
A program that returns the number the arkles
which is the same number at different positions for two arrays
*/

#include <stdio.h>
#include "farnarkle.h"

int count_arkles(int sequence1[N_TILES], int sequence2[N_TILES]) {

    int hidden_sequence[N_TILES];
    int guess[N_TILES];

    
    int i = 0;
    int j = 0;
    int arkles = 0;
    int count1 = 0;
    int count2 = 0;
    int farnarkles = 0;

    while (i <= MAX_TILE) {

        // counting the amount of numbers in each array
        while (j < N_TILES) {
            if (sequence1[j] == i) {
                count1 = count1 + 1;
            }
            if (sequence2[j] == i) {
                count2 = count2 + 1;
            }
            j = j + 1;
        }

        // when there is none, do nothing
        if ((count1 == 0) || (count2 == 0)) {
        }
        // when the second array has more of the number than the first
        // add the amount of first to the total
        else if (count1 <= count2) {
            arkles = arkles + count1;
        }
        else {
            arkles = arkles + count2;
        }

        // reinitialise counts and positions
        j = 0;
        i = i + 1;
        count1 = 0;
        count2 = 0;
        
    }


    i = 0;

    // counting farnarkles
    while (i < N_TILES) {

        if (sequence1[i] == sequence2[i]) {
            farnarkles++;
        }
        else {
        }

        i++ ;
    }

    // subtract arkles from farnarkles to get the actual number of arkles
    arkles = arkles - farnarkles;

    return arkles;
}
