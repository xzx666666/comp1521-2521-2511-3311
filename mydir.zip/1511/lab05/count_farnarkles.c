//XIAO ZIXIN
//This program is write on 01/04/2017
//this program is arm to count farnarkles


#include <stdio.h>
#include "farnarkle.h"



    // return number of farnarkles
int count_farnarkles(int sequence1[N_TILES], int sequence2[N_TILES]) {

    int i=0;
    int farnarkle=0;
    //count number for farnarkle for each array
    while(i < N_TILES){
        if(sequence1[i]==sequence2[i]) {
            farnarkle=farnarkle+1;
        }
        i++;
    }  
    return farnarkle; // replace with your code
    
}
