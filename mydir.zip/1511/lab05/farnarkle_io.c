/*
XIAO ZIXIN
DATE 01/04/2017
*/

#include <stdio.h>
#include "farnarkle.h"


// read N_TILES tiles into array tiles
// return 1 if successful, 0 otherwise
int read_tiles(int tiles[N_TILES]) {

    // num is the input
    // i is the pointer of the array
    int num, i = 0;
    int count = 0;

    while (i < N_TILES){

        // when the input is successfull
        if ((scanf("%d", &num) != EOF) && (num > 0) && (num <= MAX_TILE) ) { 
            tiles[i] = num;
            i = i + 1;
            count = count + 1;
        }
        else {
            return 0;
        }

        num = 0;

    }
    // when there is correct amount of numbers input
    if (count == N_TILES) {
        return 1;
    }
    else {
        return 0;
    }
}



// print tiles on a single line
void print_tiles(int tiles[N_TILES]) {

    int i = 0;

    while (i < N_TILES) {
        printf("%d ", tiles[i]);
        i = i + 1;
    }

    printf("\n");

}
