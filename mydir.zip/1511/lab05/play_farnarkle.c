//write by XIAO ZI XIN
//Date 02/04/2017
//this code will play a game with radom hidden_sequence if type the guess whith 4 farnarkles,the game will win.


#include <stdio.h>
#include "farnarkle.h"

int main(void) {
    int hidden_sequence[N_TILES];
    int guess[N_TILES];
    int farnarkles=0;
    int i;
    create_random_tiles(hidden_sequence);
    
    for(i=1;farnarkles!=N_TILES;i++)
    {
        printf("Enter guess for turn %d :",i);
        
        if(read_tiles(guess) !=1){
        printf("Cound not read guess\n");
        return 1;
        //if do not type number
        }
        farnarkles=count_farnarkles(hidden_sequence,guess);//instead of farnakles with number to stop circle
        printf("%d farnarkles ",count_farnarkles(hidden_sequence,guess));
        printf("%d arkles\n",count_arkles(hidden_sequence,guess));//caulator arkles and farnarkles by using function before
    }
    printf("You win\n");
    return 0;
        
       
    
    


