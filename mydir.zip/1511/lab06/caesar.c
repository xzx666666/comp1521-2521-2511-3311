//writen bY XIAO ZIXIN
//DATE 07/04/2007
//all the letter add the number become to another letter
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char*argv[]){
    int c;
    int sh=atoi(argv[1]);//GET THE number in argv
    while ((c=getchar())!=EOF){
        if('A'<=c&&c<='Z'){  //the sustitution of uppercase which add the number  
            c=sh%26+c;         
            
            if(c<'A')
            c = 26 + c;
            
            else if(c>'Z')
            c=c-26;
            
            }
        else if ('a'<=c&&c<='z') {//the situation of downcase which add the number  
            c=sh%26+c;
            if(c<'a')
                c=26+c;
            
            else if(c>'z')// the case of other than letter
                c=c-26;
        }
        putchar(c);
     }
    return 0;
}
