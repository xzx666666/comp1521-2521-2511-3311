//writen by XIAO ZIXIN
//DATE 10/04/2017
//this code decode.c which decryts.text.entcrypted by sustitution.c
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char*argv[]){
    char c;
    int h=0,i=0;
    
       while ((c=getchar())!=EOF){
            /* find the char loaction and put the decoded char */
             if(c>='a'&&c<='z'){      //find the downcase decode code
                h=0; 
                while(h<27){
                    if(c==argv[1][h]){
                    printf("%c",h+97);  //print the code
                    }
                    h++;
                }
            }
            else if(c>='A'&&c<='Z')    //find the uppercase decode code
            {
                i=0;
                while(i<27)
                {
                    if(c==argv[1][i]-32){
                    printf("%c",65+i);      //print the code
                    }
                    i++;
                }
            }
            else{
           
                putchar(c);
                }
            }
            return 0;
}

    
