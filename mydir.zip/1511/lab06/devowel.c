//writen by XIAO ZIXIN
//date 05/04/2017
//cnacel all letter of aeiou 


#include<stdio.h>
int main(void){
    int ch;
    while((ch=getchar())!=EOF){
        if(ch!='a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u'){
        putchar(ch);}
        }
    return 0;
}

