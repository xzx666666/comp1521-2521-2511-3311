//Write by xiao zixin
//fri 07/04/2017
//this programming is aim to calculat the friquence of A-Z and a-z in a sentence

#include<stdio.h>
int main(void)
{
    int num[26]={0};
    int i=0, c,j;
    while((c=getchar())!=EOF){
        
        if((c<='Z')&&(c>='A')){
            num[c-'A']++;// reserve every number of captical from A-Z in array
            i++;    //reser the total number of the word
        }
        else if((c<='z')&&(c>='a'))
        {
            num[c-'a']++;//reserve number a-z and A-Z in array
            i++;    //reserve the total number the word
        }
    
    }
    for(j=0;j<26;j++)          {
        printf("'");
        printf("%c",j+97);//the letter of a-z 
        printf("' %f %d\n",(float)num[j]/(float)i,num[j]);
    }
return 0;
}

