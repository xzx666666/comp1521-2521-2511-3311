//writen by XIAO ZIXIN
//DATE 10/04/2017
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char*argv[]){
    char c;
    int h=0;
    
       while ((c=getchar())!=EOF){
        //GET THE key of downcase and store new letter position 
            
             if(c>='a'&&c<='z'){
                h=c-97;
                printf("%c",argv[1][h]);/* print the uppercase encryped char */
            }
            else if(c>='A'&&c<='Z')//GET THE key of uppercase and store new letter position 
            
            {
                h=c-65;
                printf("%c",argv[1][h]-32); /* print the uppercase encryped char */
            }
            else{        
           
                putchar(c);
                }
            }
            return 0;
}

    
