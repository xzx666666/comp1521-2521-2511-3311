#include <stdio.h>
#include "captcha.h"

double get_holes(int height, int width, int pixels[height][width]){
    int holes[height][width];
    int heig[height];
    int x,y,num_holes;
     for(x=0;x<height;x++){
    
        for(y=0;y<width;y++){
         holes[x][y]=pixels[x][y];
         heig[x]=3;
         }
     }
    
    for(x=0;x<height;x++){
        
        for(y=0;y<width;y++){
            if(holes[1][y]!=1)
            holes[1][y]=-1;
            if(holes[x][1]!=1)
            holes[x][1]=-1;
         }
     }
     for(x=0;x<height-1;x++){
        
        for(y=0;y<width-1;y++){
            if((holes[x][y]==0)&&((holes[x-1][y]==-1)||(holes[x+1][y]==-1)||(holes[x][y-1])||(holes[x][y+1])))
            holes[x][y]=-1;
          
            }
           
         }
     }
     
     for(x=height-i;x>0;i++){
        
        for(y=width-j;y>0;j++){
            if(holes[x][y]==0){
            
            if(holes[x-1][y]==-1)
            holes[x][y]=-1;
            if(holes[x+1][y]==-1)
            holes[x][y]=-1;
            if(holes[x][y-1])
            holes[x][y]=-1;
            if(holes[x][y+1])
            holes[x][y]=-1;
            printf("-1");
            }
            j=1;
           printf("\n"); 
         }
     }
       for(y=1;y<width;y++){
        
        for(x=1;x<height;x++){
           if(holes[x][y]==0){
            
            if(holes[x-1][y]==-1)
            holes[x][y]=-1;
            if(holes[x+1][y]==-1)
            holes[x][y]=-1;
            if(holes[x][y-1])
            holes[x][y]=-1;
            if(holes[x][y+1])
            holes[x][y]=-1;
            printf("-1");
            }
            printf("\n");
        }
    }
        i=1;
        j=1;
           for(y=width-i;y>0;i++){
        
        for(x=height-j;x>0;j++){
            if(holes[x][y]==0){
            
            if(holes[x-1][y]==-1)
            holes[x][y]=-1;
            if(holes[x+1][y]==-1)
            holes[x][y]=-1;
            if(holes[x][y-1])
            holes[x][y]=-1;
            if(holes[x][y+1])
            holes[x][y]=-1;
            printf("-1");
            }
            j=1;
            printf("\n");
         }
     } 
    for(x=0;x<height;x++){ //
            
            for(y=0;y<width;y++){
                if(holes[x][y]==0)
                printf("0");
                if(holes[x][y]==1)
                printf("1");
             }
             printf("\n");
    }
            
    
    for(x=0;x<height;x++){ 
            
        for(y=0;y<width;y++){
            if(holes[x][y]==-1)
            heig[x]=4;
        }
        if(heig[x+1]==heig[x])
        num_holes=num_holes+0;
        else
        num_holes++;
   }
            
    
return num_holes;  
    
   }
