#include <stdio.h>
#include "captcha.h"
    double get_density(int height, int width, int pixels[height][width]){
    int
