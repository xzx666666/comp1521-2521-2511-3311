#include<stdio.h>
#include"captcha.h"

int get_holes(int height, int width, int pixels[height][width]) {
	int holes[height][width], heig[height];
	int start_row, start_column, box_width, box_height, min_row, max_row, min_col, max_col;
	int x, y, sum_holes;
	
	sum_holes = 0;
	

	for (x = height - 1;x >= 0;x--) {
		for (y = 0;y < width;y++) {
			holes[x][y] = pixels[x][y];
			heig[x] =  3;
			
		}
		
	}

	get_bounding_box(height, width, pixels, &start_row, &start_column, &box_height, &box_width);
		
		min_row = start_row;
		max_row = box_height + start_row - 1;
		min_col = start_column;
		max_col = box_width + start_column - 1;
		
	
	
	//boundary
	for(x=height-1;x>=0;x--)
    {
        for(y=0;y<width;y++){
            if ( (holes[x][y] == 0) && ( (x == min_row) || (x == max_row) || (y == min_col) || (y == max_col) ) ) {
				holes[x][y] = -1;
			}
	    }
	}
	

	for (x=height-1;x >= 0;x--) {
		for (y=0;y < width;y++) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
		}
		

	} // left to right, down forward
	
	
	
	for (x = height - 1;x >= 0;x--) {
		for (y = width - 1;y >= 0;y--) {
			if ( (holes[x][y] == 0) && ( (holes[x +1][y] == -1) || (holes[x - 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
		}
		
		
	} // right to left, down forward
	
	
	for (y = 0;y < width;y++) {
		for (x=height-1;x >= 0;x--) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
		}
		

	} // up to down, right forward
	
	
	
	for (y = width - 1;y >= 0;y--) {
		for (x = height -1;x >= 0;x--) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
		}
		
		
		
	} // up to down, left forward
	
	for (x = 0;x < height;x++) {
		for (y = width - 1; y >= 0;y--) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
		}
		
	} // right to left, up forward
	
	
	
	for(x=0;x<height-1;x++){
        
        for(y=0;y<width-1;y++){
            if((holes[x][y]==0)&&((holes[x-1][y]==-1)||(holes[x+1][y]==-1)||(holes[x][y-1])||(holes[x][y+1])))
            holes[x][y]=-1;
          
            }
           
         }
     
     
	
	for (y = width - 1;y >= 0;y--) {
		for (x=0;x < height;x++) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
		}
		

	} // down to up, left forward
	
	
	for (y=0;y < width;y++) {
		for (x=0;x < height;x++) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
		
		}
		

	} // down to up, right forward
	 // 1st round
	
	

	for (x = height - 1;x >= 0;x--) {
		for(y = 0; y < width;y++) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
			
		}
		
	} // left to right, down forward
	
	
	
	for (x = height - 1;x >= 0;x--) {
		for (y = width - 1;y >= 0;y--) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
			
		}
		
		
	} // right to left, down forward
	
	
	for (y = 0;y < width;y++) {
		for (x = height -1;x >= 0;x--) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
		}
		

	} // up to down, right forward
	
	
	
	for (y = width - 1;y >= 0;y--) {
		for (x = height -1;x >= 0;x--) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
		}
		
		
	} // up to down, left forward
	
	

	for (x = 0;x < height;x++) {
		for (y = width - 1; y >= 0;y--) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
			
		}
		

	} // right to left, up forward
	
	
	for (x=0;x < height;x++) {
		for (y=0;y < width;y++) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
		}
		
	} // left to right, up forward
	
	
	
	for (y = width - 1;y >= 0;y--) {
		for (x=0;x < height;x++) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
			
		}
		
	} // down to up, left forward

	for (y=0;y < width;y++) {
		for (x=0;x < height;x++) {
			if ( (holes[x][y] == 0) && ( (holes[x - 1][y] == -1) || (holes[x + 1][y] == -1) || (holes[x][y - 1] == -1) || (holes[x][y + 1] == -1) ) ) {
				holes[x][y] = -1;
			}
			
			
		}
		
	} // down to up, right forward
	// 2nd round
	
	x = height - 1;
	y = 0;
	
	while (x >= 0) {
		while (y < width) {
			if (holes[x][y] == 0) {
			heig[x] = 4;
			}
			y++;
		}
		y = 0;
		x--;
	}
	
	x = height - 1;
	
	while (x > 0) {
		if (heig[x] == 3 && heig[x + 1] == 4) {
			sum_holes++;
		}
		x--;
	}
	

	
	return sum_holes;
}


