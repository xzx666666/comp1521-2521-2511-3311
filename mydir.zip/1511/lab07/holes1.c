#include<stdio.h>
#include"captcha.h"

int get_holes(int height, int width, int pixels[height][width]) {
	int re[height][width], lol[height];
	int start_row, start_column, box_width, box_height, min_r, max_r, min_col, max_col;
	int e, f, holes;
	
	holes = 0;
	e = height - 1;
	f = 0;

	while (e >= 0) {
		while (f < width) {
			re[e][f] = pixels[e][f];
			lol[e] = 6;
			f++;
		}
		f = 0;
		e--;
	}

	get_bounding_box(height, width, pixels, &start_row, &start_column, &box_height, &box_width);
		
		min_r = start_row;
		max_r = box_height + start_row - 1;
		min_col = start_column;
		max_col = box_width + start_column - 1;
		
	e = height - 1;
	f = 0;
	
	while (e >= 0) {
		while (f < width) {
			if ( (re[e][f] == 0) && ( (e == min_r) || (e == max_r) || (f == min_col) || (f == max_col) ) ) {
				re[e][f] = -2;
			}
			f++;
		}
		f = 0;
		e--;
	} //boundary

	e = height - 1;
	f = 0; 

	while (e >= 0) {
		while (f < width) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			f++;
		}
		f = 0;
		e--;

	} // left to right, down forward
	
	e = height - 1;
	f = width - 1;;
	
	while (e >= 0) {
		while (f >= 0) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			f--;
		}
		f = width - 1;
		e--;
		
	} // right to left, down forward
	
	e = height -1;
	f = 0;
	
	while (f < width) {
		while (e >= 0) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			e--;
		}
		e = height - 1;
		f++;

	} // up to down, right forward
	
	e = height -1;
	f = width - 1;
	
	while (f >= 0) {
		while (e >= 0) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			e--;
		}
		e = height - 1;
		f--;
		
	} // up to down, left forward
	
	e = 0;
	f = width - 1; 

	while (e < height) {
		while (f >= 0) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			f--;
		}
		f = width - 1;
		e++;

	} // right to left, up forward
	
	e = 0;
	f = 0;
	
	while (e < height) {
		while (f < width) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			f++;
		}
		f = 0;
		e++;

	} // left to right, up forward
	
	e = 0;
	f = width - 1;
	
	while (f >= 0) {
		while (e < height) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			e++;
		}
		e = 0;
		f--;

	} // down to up, left forward
	
	e = 0;
	f = 0;
	
	while (f < width) {
		while (e < height) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			e++;
		}
		e = 0;
		f++;

	} // down to up, right forward
	 // 1st round
	
	e = height - 1;
	f = 0; 

	while (e >= 0) {
		while (f < width) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			f++;
		}
		f = 0;
		e--;

	} // left to right, down forward
	
	e = height - 1;
	f = width - 1;;
	
	while (e >= 0) {
		while (f >= 0) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			f--;
		}
		f = width - 1;
		e--;
		
	} // right to left, down forward
	
	e = height -1;
	f = 0;
	
	while (f < width) {
		while (e >= 0) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			e--;
		}
		e = height - 1;
		f++;

	} // up to down, right forward
	
	e = height -1;
	f = width - 1;
	
	while (f >= 0) {
		while (e >= 0) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			e--;
		}
		e = height - 1;
		f--;
		
	} // up to down, left forward
	
	e = 0;
	f = width - 1; 

	while (e < height) {
		while (f >= 0) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			f--;
		}
		f = width - 1;
		e++;

	} // right to left, up forward
	
	e = 0;
	f = 0;
	
	while (e < height) {
		while (f < width) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			f++;
		}
		f = 0;
		e++;

	} // left to right, up forward
	
	e = 0;
	f = width - 1;
	
	while (f >= 0) {
		while (e < height) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			e++;
		}
		e = 0;
		f--;

	} // down to up, left forward
	
	e = 0;
	f = 0;
	
	while (f < width) {
		while (e < height) {
			if ( (re[e][f] == 0) && ( (re[e - 1][f] == -2) || (re[e + 1][f] == -2) || (re[e][f - 1] == -2) || (re[e][f + 1] == -2) ) ) {
				re[e][f] = -2;
			}
			e++;
		}
		e = 0;
		f++;

	} // down to up, right forward
	// 2nd round
	
	e = height - 1;
	f = 0;
	
	while (e >= 0) {
		while (f < width) {
			if (re[e][f] == 0) {
				lol[e] = 5;
			}
			f++;
		}
		f = 0;
		e--;
	}
	
	e = height - 1;
	
	while (e > 0) {
		if (lol[e] == 5 && lol[e + 1] == 6) {
			holes++;
		}
		e--;
	}
	return holes;
}


