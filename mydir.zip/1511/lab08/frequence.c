#include<stdio.h>
#define MAX 1000
int main(void){
	int i,x,d,count=0,num[MAX];
	int count_number=0, count_max[MAX];
	for(i=0;i<MAX;i++){
		d=scanf("%d",&num[i]);
		if(d==EOF)
			break;
			count++;
		
	}
	for(i=0;i<count;i++){
		for(x=0;x<count;x++){
			if(num[i]==num[x]){
				count_number++;
				
			}

		}
		count_max[i]=count_number;
		count_number=0;

	}
	/*for(i=0;i<count;i++){
	    printf("frequence is %d \n",count_max[i]);
	    }*/
	    printf("frequence is ");
	for(x=count-1;x>=0;x--){
		for(i=0;i<count;i++){
			if(count_max[i]>=x){
				printf("%d\n",num[i]);
				break;
			}
			
		}
		if(count_max[i]>=x){
				
				break;
				}
	}
	return 0;
}
