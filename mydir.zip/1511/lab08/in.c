#include<stdio.h>

# define MAX 1000
int main (void){
	int ch[MAX],count=0;
	int i=0,num1=0,num[MAX];
	int c,y,x[MAX],q;
	    for(i=0;i<MAX;i++){
	        c=scanf("%d",&num[i]);
	    if(c==EOF){
	        break;
	        }
        num1++;
        }
		
		


	
	printf("Indivisible number : ");
	for(i=0;i<num1;i++){
		ch[i]=num[i];
        
	}
	for(i=0;i<num1;i++){
	    for(y=0;y<num1;y++){
		    if(num[i]%ch[y]==0){
		    
		    if(num[i]==ch[y])
		    printf("");
		    
		    else {
		    
		    x[y]=ch[y];
		    count++;
		    
		    }
		    
			}
			
		}
	}
	
	 for(y=0;y<num1;y++){
	 if(x[y]!=0)
	printf(" %d",x[y]);
	}
	printf("\n");
	return 0;
}

