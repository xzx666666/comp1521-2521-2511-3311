#include<stdio.h>
#define MAX 1000
int main (void){
    int num[MAX];
    int s,i,count=0;
    for(i=0;i<MAX;i++){
        s=scanf("%d",&num[i]);
        
        if(s==EOF)
        break;
          count++;
        }
    for(i=0;i<count;i++){
        printf("%d ",num[i]);
        }
    return 0;
   }
   
