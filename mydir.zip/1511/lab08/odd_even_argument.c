#include<stdio.h>
#include<stdlib.h>
#define MAX 1000
int main(int argc,char *argv[]){
    int i ,num[argc],d,count=0;
    d = 0;
    while(d < argc){
       
            num[d]=atoi(argv[d]);
       
            count++;
        d++;
    }
    
    printf("Odd numbers were: ");
    for(i=0;i<argc;i++){
        if(num[i]%2!=0){
        printf("%d ",num[i]);
        }
     }
     printf("\n");
     printf("Even numbers were: ");
     for(i=1;i<argc;i++){
        if(num[i]%2==0){
        printf("%d ",num[i]);
        }
     }
     printf("\n");
        
    return 0;
}
    int function(int k, int num[count]){
    int i;
    
    return num[k];
    }
    
