#include<stdio.h>
#define MAX 100
int main(void){
    int i ,num[MAX],d,count=0;
    for(i=0;i<MAX;i++){
        d=scanf("%d",&num[i]);
        if(d==EOF){
        break;
        }
        count++;
        return num[i];
    }
    
    
    printf("Odd numbers were: ");
    for(i=0;i<count;i++){
        if(num[i]%2==1||num[i]%2==-1){
        printf("%d ",num[i]);
        }
     }
     printf("\n");
     printf("Even numbers were: ");
     for(i=0;i<count;i++){
        if(num[i]%2==0){
        printf("%d ",num[i]);
        }
     }
     printf("\n");
        
    return 0;
}
        
    int read_function(int num[],int i,int *count){
        int i ,num[MAX],d,count=0;
     for(i=0;i<MAX;i++){
        d=scanf("%d",&num[i]);
        if(d==EOF){
        break;}
        *count++;
        return num[i];
    }
    
    }
