#include<stdio.h>
#define MAX 1000
int main(void){
    int i,num[MAX],d,count=0,n=0;
    for(i=0;i<MAX;i++){
        d=scanf("%d",&num[i]);
        if(d==EOF){
        break;}
        count++;
    }
    
    for(i=0;i<count;i++){
        if(num[i]<0){
            n=i;
            break;
        }
    }
    printf("Odd numbers were: ");
   
    for(i=0;i<n;i++){
        if(num[i]%2==1){
        
        
        printf("%d ",num[i]);
        }
     }
     printf("\n");
     printf("Even numbers were: ");
     for(i=0;i<n;i++){
        
        if(num[i]%2==0){
        
        printf("%d ",num[i]);
        }
        
     }
     printf("\n");
        
    return 0;
}
    for(i=0;i<MAX;i++){
        d=scanf("%d",&num[i]);
        if(d==EOF){
            break;
        }
        count++;
    }    
    
