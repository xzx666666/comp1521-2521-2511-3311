#include<stdio.h>
#define MAX 1000
int main(void){
    int i,x,d,count=0,num[MAX];
	int count_number=0, count_max[MAX];
	for(i=0;i<MAX;i++){
		d=scanf("%d",&num[i]);
		if(d==EOF)
			break;
			count++;
		
	}
	for(i=0;i<count;i++){
	    count_max[i]=num[i];
	    }
	for(i=0;i<count;i++){
	    for(x=i;x<count;x++){
	        if((num[i]==count_max[x])&&(x!=i)){
	            count_max[x]=0;
	            }
	     }
	}
	
	printf("the repitition is ");
	for(i=0;i<count;i++){
	    if(count_max[i]==0)
	    printf("");
	    else
	    printf("%d ",count_max[i]);
	    }
	    printf("\n");
	return 0;
}
