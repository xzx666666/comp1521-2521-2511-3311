#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char const *argv[]) {
    
    FILE *f;
    int max_lines =10;

    if (argc == 2) {
        
        f=fopen(argv[1],"r");
    }
    else if (argc ==4 && strcmp(argv[1],"-n")== 0) { /* has a flag of n   */
                                                      // refresh the max_lines
         max_lines= atoi(argv[2]);
        
        f=fopen(argv[3],"r");//read in new argv
    }
    else {
        exit(1);
    }

    char this_char;
    int count_lines = 0;
   
    while ((this_char=getc(f))!=EOF) {
      
        putchar(this_char);//printf the char
        if (this_char == '\n') {
           
            count_lines++;
            if (count_lines ==max_lines) {
               
                return 0;//stop this if become 10 and more line
            }
        }


    }

    return 0;
}
