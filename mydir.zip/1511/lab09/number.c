#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[]) {
   
   
    int min =0, max = 0;
    
    char file_name[4096];
    
    min= atoi(argv[1]);
    max= atoi(argv[2]);
    
    FILE *f;
    f=fopen(argv[3],"w");
    for (int i = min; i <= max; i++) {  
        fprintf(f, "%d\n",i );
    }

    return 0;
}
