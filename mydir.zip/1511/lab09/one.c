#include<stdio.h>
#define MAX_LEN 1024
    int main (void){
        int c=0;
        char line[MAX_LEN];
        printf("Enter a string: ");
        
        if(fgets(line,MAX_LEN,stdin) !=NULL){
            for(c=0;line[c]!='\n'&&line[c]!='\0';c++){
                
              
                
                    putchar(line[c]);
                       
                        putchar('\n'); 
                       
                }
                
                }
            return 0;
            
        }
        
        

