#include<stdio.h>
#define MAX_LEN 1024
    int main (void){
        int c=0;
        char line[MAX_LEN];
        int x=0;
        int count=0;
        printf("Enter a string: ");
        
        
        while(fgets(line,MAX_LEN,stdin) !=NULL){
            for(c=0;line[c]!='\n'&&line[c]!='\0';c++){
            }
            c--;
            while(c>=0){
                if (line[x]==line[c]){
                    count++;
                }
                c--;
                x++;
            }

                      
                
                
                
            if(count==x)
             printf("String is a palindrome\n");
             else
             printf("String is not a palindrome\n");
            }
            return 0;
            
        }
        
        

