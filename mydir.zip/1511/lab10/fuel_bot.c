#include <stdio.h>
#include "trader_bot.h"

char *get_bot_name(void) {
    return "Fuel Bot";
}

void get_action(struct bot *b, int *action, int *n){
    
    if((b->fuel==b->fuel_tank_capacity)&&(b->location->type==3)){
    *action=ACTION_MOVE;
    *n=b->maximum_move;
    
    }
    else if (b->location->type!=3){
        *action=ACTION_MOVE;
        int nearest_distance= nearest_fuel(b);
    
        if(nearest_distance>=b->maximum_move){
            if(nearest_distance>0)
                 *n= b->maximum_move;
                
            else 
                *n= -b->maximum_move;
      
         }
            else
                *n=nearest_distance;
          
    }
    else if (b->location->type==3){
        *action=ACTION_BUY;
        
        *n=b->fuel_tank_capacity - b->fuel;
    }
}

