#include <stdio.h>
#include "trader_bot.h"
void print_location(struct location *l){
	if(l->type==0)
		printf("%s: start\n",l->name);
	 if(l->type==1)
		printf("%s: will sell %d units of %s for $%d\n",l->name, l->quantity,l->commodity->name,l->price);
	 if(l->type==4)
		printf("%s: dump\n",l->name);
	 if(l->type==5)
		printf("%s: other\n",l->name);
	 if(l->type==3)
		printf("%s: Petrol station %d units of available fuel for $%d\n", l->name, l->quantity,l->price);
	 if(l->type==2)
		printf("%s: will buy %d units of %s for $%d\n",l->name, l->quantity,l->commodity->name,l->price);
}
void print_world(struct bot *b){
	struct location *start_l;
		start_l=b->location;
	 print_location(start_l);
	 struct cargo *cargo=b->cargo;
	
	 for(struct location *l=start_l->next;
	 	l!=start_l;
	 	l=l->next){
	 	print_location(l);
	 	
	 	
	 }

}

