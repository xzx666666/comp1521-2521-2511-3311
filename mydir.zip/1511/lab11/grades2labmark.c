#include<stdio.h>

#include<stdlib.h>
#define WEEK 11
double grades2labmark(char grades[]);

int main(int argc,char *argv[]){
   
    double landmark;
   
    landmark=grades2labmark(argv[1]);
    printf("%.1lf\n",landmark);
    
}
    
double grades2labmark(char grades[]){
    
    int i;
    double landmark=0;
    
   
    for(i=0;grades[i]!='\0';i++){
    
        if((i!=(week*2+1))&&((grades[i]=='A')&&(grades[i+1]=='+'))){
            landmark=landmark+1.2;}
        else if(grades[i]=='A'){
            landmark=landmark+1.0;
            }
        else if(grades[i]=='B'){
            landmark=landmark+0.8;}
        else if(grades[i]=='C'){
            landmark=landmark+0.5;}
        else 
            landmark=landmark+0;
        
    }
    
    if(landmark>=10.0){
        landmark=10.0;
        
        }
        return landmark;
   } 
    
    
    
