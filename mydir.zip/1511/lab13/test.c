#include <stdio.h>

void sumProd(int len, int nums[len], int *sum, int *product);

int main(int argc, char *argv[]){
   int nums[] = {3,4,1,5,6,1};
   int prod;
   int sum;

   //Pass in the address of the sum and product variables
   
    sumProd(6, nums,&sum, &prod);
   printf("The sum is %d and prod is %d\n",sum,prod);
   return 0;
}


// Calculates the sum and product of the array nums.
// Actually modifies the  variables that *sum and *product are pointing to
void sumProd(int len, int nums[len], int *sum, int *product) {
    *sum=0;
    *product=1; 
    int i;
    for(i=0;i<len;i++){
        *sum=nums[i]+*sum;
        *product=*product*nums[i];
        
    }
}

