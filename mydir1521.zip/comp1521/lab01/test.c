#include<stdio.h>
#include"Queue.h"


void test(test){
   Queue q=makeQueue();
   enterQueue(q, 11, 1);
   showQueue(q);
   int dogs=leaveQueue( q);
	printf("dogs %d\n",dogs); 
   enterQueue(q, 11, 1);
   int next = nextDurationQueue(q);
       printf("next %d\n",next);
	enterQueue(q,12,3);
	freeQueue(q);
	showQueue(q);
  return;
}


int main() {
   test();
   return 0;
}
