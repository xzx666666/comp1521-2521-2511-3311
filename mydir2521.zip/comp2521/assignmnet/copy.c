#include <stdlib.h>
#include <string.h>
#include<assert.h>
#include <stdio.h>
#include "textbuffer.h"
char *SubChar(char *str,char *subs,int pos);
TB newTextBuffer();
int lengthChar(char*first,char*last);
int length(TB tb);
int size(TB tb, int from,int to);
void whiteBoxTest();

void checkNode(char *text,char *str);
typedef struct node *Node;
struct textbuffer{
    Node first;
    Node last;
    //char *record[10];
    
};
struct node{
    Node next;
    Node prev;
    char *texts;
    int length;
};

TB newTextBuffer(){
    TB new;
    //int i;
    if((new = malloc(sizeof(struct textbuffer)))==NULL){
            fprintf(stderr,"infullcent allocate");
        }
    new->first = NULL;
    new->last = NULL;
    
    /*for(i=0;i<10;i++){
        new->record[i] = malloc(100*sizeof(char));
    }*/
    return new;
}
TB newTB (char text[]){
    Node new = NULL;
    Node node = NULL;
    Node h = NULL;
    int i,count = 0;
    char *first = &text[0];
    TB new_rep = newTextBuffer();
    
    
    for(i=0;i<strlen(text);i++){
        if(text[i]=='\n'){
            
            if((new = malloc(sizeof(struct node)))==NULL){
                fprintf(stderr,"infullcent allocate");
            }
        
            if((new->texts = calloc(sizeof(char),(i-count+1)))==NULL){
                fprintf(stderr,"infullcent allocate");
            }
            
            strncpy(new->texts,first,i-count+1);
            first = &text[i+1];
            
            new->length = i-count+1;
            
            if(count == 0){
                h = new;
                h->prev = NULL;
                
                
            }
            else{
                node->next = new;
                new->prev = node;
                
            }
            count = i+1;
            node = new;
            
        }
       
    }
    new_rep->first = h;
    new_rep->last = new;
    new->next = NULL;
    
    return new_rep;
}


void releaseTB (TB tb){
    assert(tb!=NULL);
    //int i=0;
    Node curr = tb->first;
    while(curr!=NULL){
        Node de = curr->next;
        free(curr->texts);
        free(curr);
        curr = de;
        
    }
    /*for(i=0;i<10;i++)
    free(tb->record[i]);*/
    free(tb);
}


int length(TB tb){
    assert(tb!=NULL);
    Node curr = tb->first;
    int count=0;
    while(curr!=NULL){
        
        count = count +curr->length;
        
        curr = curr->next;
    }
    
    return count;
}
char *dumpTB (TB tb){
    
    char *value;
    
    value = calloc(sizeof(char),(length(tb)+1));
    
   
    if(value ==NULL){
        fprintf(stderr,"infullcent allocate");
    }
    
    Node curr = tb->first;
    
    while(curr!=NULL){
        //printf("curr %s %d\n",curr->texts,curr->length);
        strcat(value,curr->texts);
        //printf("value %s\n",value);
        curr = curr->next;
        
    }
    
    strcat(value,"\0");
    return value;
}
/* Return the number of lines of the given textbuffer.
 */
int linesTB (TB tb){
    int count = 0;
    Node curr = tb->first;
    while(curr!=NULL){
        count++;
        curr = curr->next;
    }
    return count;
}

void swapTB (TB tb, int pos1, int pos2){
    assert(tb!=NULL);
    char *exchange = NULL, *change = NULL;
    int i=0;
    Node curr = tb->first;
    Node ex1 = NULL,ex2 = NULL;
    if(pos1<0||pos2<0||pos1>(linesTB(tb)-1)||pos2>(linesTB(tb)-1)){
        fprintf(stderr,"out of range\n");
        abort();
        
    }
    else{
        for(curr=tb->first;curr!=NULL;curr = curr->next){
            
            
            if(i==pos1){
                exchange = calloc(sizeof(char),curr->length);
                ex1 = curr;
                strcpy(exchange,curr->texts);
            }
            if(i==pos2){
                change = calloc(sizeof(char),curr->length);
                ex2 = curr;
                strcpy(change,curr->texts);
            }
            i++;
        }
        if(ex1->length==ex2->length){
            ex1->texts = ex2->texts;
            ex2->texts = exchange;
            
        }
        else{
           
            free(ex1->texts);
            free(ex2->texts);
            ex1->texts = calloc(sizeof(char),ex2->length);
            int length = ex2->length;
            strcpy(ex2->texts,change);
            ex2->texts = calloc(sizeof(char),ex1->length);
            strcpy(ex2->texts,exchange);
            
            ex2->length = ex1->length;
            ex1->length = length;
            free(change);
            free(exchange);
        }
    }
}


void mergeTB (TB tb1, int pos, TB tb2){
    assert(tb1!=NULL);
    assert(tb2!=NULL);
    if(pos<0||pos>linesTB(tb1)) abort();
    char *str2 = dumpTB(tb2);
    TB new = newTB(str2);
    int i=0;
    Node curr;
    
    if(pos == 0){
        new->last->next = tb1->first;
        tb1->first->prev = new->last;
        tb1->first = new->first;
    
    }
    else{
        for(curr = tb1->first;curr!=NULL;curr = curr->next){
            if(i==pos-1)break;
            i++;
        }
        Node n = curr->next;
        curr->next = new->first;
        new->first->prev = curr;
        
        new->last->next = n;
        n->prev = new->last;
    }
    free(str2);
    free(new);
    releaseTB (tb2);
    
}

void pasteTB (TB tb1, int pos, TB tb2){
    assert(tb1!=NULL);
    assert(tb2!=NULL);
    if(pos<0||pos>linesTB(tb1)) abort();
    
    char *str2 = dumpTB(tb2);
    TB new = newTB(str2);
    
    int i=0;
    Node curr;
    if(pos<0||pos>linesTB(tb1)) abort();
    
    if(pos == 0){
        
        new->last->next = tb1->first;
        tb1->first->prev = new->last;
        tb1->first = new->first;
    
    }
    else{
        for(curr = tb1->first;curr!=NULL;curr = curr->next){
            if(i==pos-1)break;
            i++;
        }
        Node n = curr->next;
        curr->next = new->first;
        new->first->prev = curr;
        new->last->next = n;
        n->prev = new->last;
    }
    free(new);//remenber to free the record
    free(str2);
    
}

TB cutTB (TB tb, int from, int to){
    assert(tb!=NULL);
    char *text = calloc(sizeof(char),(size(tb,from,to)+1));
    TB new;
    char *dump=dumpTB(tb);;
    int i,j=0;
    char *cu;
    
    if(text == NULL) abort();
    
    if(from<0||to<0||from>linesTB(tb)||to>linesTB(tb)){
        abort();
    }
    if(from>to){
        return NULL;
    }
    
    for(i=0;i<strlen(dump);i++){
        if(j==from){
          cu = &dump[i];
          
          strncpy(text,cu,size(tb,from,to)); 
          deleteTB (tb,from,to);
          break;
       }
        if(dump[i]=='\n')j++;
        
    }
    strcat(text,"\0");
    
    new = newTB(text);
    free(text);
    free(dump);
    return new;
    
}


TB copyTB (TB tb, int from, int to){
    assert(tb!=NULL);
    char *text = calloc(sizeof(char),(size(tb,from,to)+1));
    TB new;
    char *dump=dumpTB(tb);;
    int i,j=0;
    char *cu;
    
    if(text == NULL) abort();
    
    if(from<0||to<0||from>linesTB(tb)||to>linesTB(tb)){
        abort();
    }
    if(from>to){
        return NULL;
    }
    
    for(i=0;i<strlen(dump);i++){
        if(j==from){
          cu = &dump[i];
          
          strncpy(text,cu,size(tb,from,to)); 
          
          break;
       }
        if(dump[i]=='\n')j++;
        
    }
    strcat(text,"\0");
    
    new = newTB(text);
    free(text);
    free(dump);
    return new;
    
    
}

void deleteTB (TB tb, int from, int to){
    assert(tb!=NULL);
    Node curr = tb->first;
    
    int i=0;
    if(from<0||to<0||from>linesTB(tb)||to>linesTB(tb)){
        abort();
    }
    if(from>to) return;
    else{
        while(curr!=NULL){
            if(i>=from&&i<=to){
                if(curr == tb->first){//delete head 
                    //printf("curr%s\n",curr->texts);
                    if(curr==tb->last){
                        tb->first = NULL;
                        tb->last = NULL;
                        
                        free(curr->texts);
                        free(curr);

                    }
                    else{
                        Node delete = curr;
                        curr = curr->next;
                        
                        curr->prev = NULL;
                        tb->first = curr;
                        free(delete->texts);
                        free(delete);
                    }
                    
                 }

                 else if(curr==tb->last&&curr!=tb->first){//delete median
                        Node delete = curr;
                        curr->prev->next = NULL;
                        tb->last = curr;
                        free(delete->texts);
                        free(delete);
                       
                        
                    
                    }
                 else{
                        Node delete = curr;
                        curr->prev->next = curr->next;
                        curr->next->prev = curr->prev;
                        curr = curr->next;
                        free(delete->texts);
                        free(delete);
                        
                 }
                
              
            }
                
            else{
                curr = curr->next;
            }
            i++;
            
        }
        
    
   } 
}

 
int size(TB tb, int from,int to){
    assert(tb!=NULL);
    int i=0,count=0;
    Node curr = tb->first;
    while(curr!=NULL){
        if(i>=from&&i<=to){
            
            count = count+curr->length;
        }
        i++;
        curr = curr->next;
    }
    return count;
}

void replaceText (TB tb, char* str1, char* str2) {
    assert(tb!=NULL);
    Node curr = tb->first;
    char *text;
    int pos;
    while(curr!=NULL){
       
        text = strstr(curr->texts,str1);
       
        if(text!=NULL){
            
            //malloc the head 
            char *head = calloc(sizeof(char),((curr->length)+strlen(str2)-strlen(str1)));
            if(head==NULL) fprintf(stderr,"error");
            //get the distance between str1 and curr->texts
            pos = lengthChar(curr->texts,str1);
            //get the pointer before the str1
            char *s = SubChar(curr->texts,str1,pos);
            //cut the pointer s and str2
            strcat(head,s);
            strcat(head,str2);
            //cat the remind string
        
            char *d = &text[strlen(str1)];
            strcat(head,d);
         
            //free the memory and copy the newstring
            free(curr->texts);
            curr->texts = calloc(sizeof(char),strlen(s));
            strcpy(curr->texts,head);
            free(s);
        }
          else{  
            curr = curr->next;
        }
    }
    
}
int lengthChar(char*first,char*last){
    int i = 0;
    int count = 0;
    for(i=0;i<strlen(first);i++){
        if(strncmp(&first[i],last,strlen(last))==0) {
            count = i;
            break;
        }
         
    }

    return count;
}
char *SubChar(char *str,char *subs,int pos){
    int i=0,j=0;
    char *res = calloc(sizeof(char),pos);
    for(i=0;i<strlen(str);i++){
        if(strncmp(&str[i],subs,strlen(subs))==0)   break;
          
        else{
            res[j] = str[i];
            j++; 
             
        }
    
    }
    
    res[j] = '\0';
    return res;

}

void whiteBoxTest(){
    printf("WhiteBox\n");
    printf("Test 1\n");
    char *ori1 = "1.1 abc\n1.2 abc\n1.3 abc\n1.4 abc\n";
    Node curr;
    TB tb1 = newTB(ori1);
    char *res[4];
    char *ressub[4];
    int i=0;
    char *s;
    int pos;
    res[0] = "1.1 abc\n";
    res[1] = "1.2 abc\n";
    res[2] = "1.3 abc\n";
    res[3] = "1.4 abc\n";
    
    ressub[0] = "1.1 a";
    ressub[1] = "1.2 a";
    ressub[2] = "1.3 a";
    ressub[3] = "1.4 a";
    int lengths =(int) strlen(ori1);
    int lenres = (int)strlen(res[0]);
    for(curr = tb1->first;curr!=NULL;curr=curr->next){
        
        assert(!strcmp(curr->texts,res[i]));
        //test each node strlen and curr->length
       
        assert(lenres==curr->length);
        //find subchar position
        pos = lengthChar(curr->texts,"bc");
        //test subChar function
        s = SubChar(curr->texts,"bc",pos);
        int lens = (int)strlen(s);
        assert(lens==pos);
        assert(!strcmp(s,ressub[i]));
        free(s);
        
        i++;
    }
    //test the max length and the original string
    assert(length(tb1)==lengths);
    
    //test the size funtion which return the num of char between from  to
    
    assert(size(tb1,1,2)==lenres);
    releaseTB (tb1);
    printf("Test1 Passed\n");
    
    
}

