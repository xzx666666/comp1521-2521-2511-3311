#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "textbuffer.h"

int main(int argc, char *argv[]) {
    char s[89] = "dhjs";
    strcat(s,"\0");
    printf("%s %d\n",s,strlen(s));

    return 0;
}

