#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "textbuffer.h"
void whiteBoxTest();
void check(TB tb,char *str);

int main(int argc, char *argv[]) {
    whiteBoxTest();
    printf("Blackbox \ntest1\n");
    char *ori1 = "1.1 abc\n1.2 abc\n1.3 abc\n1.4 abc\n";
    char *result1 = "1.1 abc\n1.2 abc\n1.3 abc\n1.4 abc\n";
    TB tb1 = newTB(ori1);
    check(tb1,result1);
    //test swape funtion
    swapTB (tb1, 0, 1);
    result1 = "1.2 abc\n1.1 abc\n1.3 abc\n1.4 abc\n";
    check(tb1,result1);

    swapTB (tb1, 0, 1);
    result1 = "1.1 abc\n1.2 abc\n1.3 abc\n1.4 abc\n";
    check(tb1,result1);

    swapTB (tb1, 1, 2);
    result1 = "1.1 abc\n1.3 abc\n1.2 abc\n1.4 abc\n";
    check(tb1,result1);

    swapTB (tb1, 1, 2);
    result1 = "1.1 abc\n1.2 abc\n1.3 abc\n1.4 abc\n";
    check(tb1,result1);

    swapTB (tb1, 2, 3);
    result1 = "1.1 abc\n1.2 abc\n1.4 abc\n1.3 abc\n";
    check(tb1,result1);

    swapTB (tb1, 3, 2);
    result1 = "1.1 abc\n1.2 abc\n1.3 abc\n1.4 abc\n";
    check(tb1,result1);

    // test delete funtion
    deleteTB (tb1, 0, 0);
    result1 = "1.2 abc\n1.3 abc\n1.4 abc\n";
    check(tb1,result1);

    deleteTB (tb1, 1, 1);
    result1 = "1.2 abc\n1.4 abc\n";
    check(tb1,result1);

    deleteTB (tb1, 1, 1);
    result1 = "1.2 abc\n";
    check(tb1,result1);
    releaseTB (tb1);
    printf("Passed test1\n");
    printf("Test2\n");
    
    //test merge function in the head
    char *ori2 = "2.1 abc\n3.1 abc\n4.1 abc\n5.1 abc\n";
    char *result2 = "2.1 abc\n3.1 abc\n4.1 abc\n5.1 abc\n";
    
    ori1 = "1.2 abc\n";
    tb1 = newTB(ori1);
    TB tb2 = newTB(ori2);
     
    check(tb2,result2);
    
    mergeTB (tb1, 0,  tb2);
    result1 = "2.1 abc\n3.1 abc\n4.1 abc\n5.1 abc\n1.2 abc\n";
    check(tb1,result1);
    releaseTB (tb1);
    
    printf("Passed Test3\n");
    
    printf("Test4\n");
    ori1 = "2.1 abc\n3.1 abc\n4.1 abc\n5.1 abc\n1.2 abc\n";
    tb1 = newTB(ori1);
    //test cut function
    TB t4 = cutTB (tb1, 0, 1);
    result2 = "2.1 abc\n3.1 abc\n";
    result1 = "4.1 abc\n5.1 abc\n1.2 abc\n";
    check(tb1,result1);
    check(t4,result2);
    releaseTB (tb1);
    releaseTB (t4);
    printf("Passed Test4\n");
    
    printf("Test5\n");
    
    ori1 = "3.1 abc\n4.1 abc\n5.1 abc\n";
    tb1 = newTB(ori1);
    
    replaceText (tb1,"ab","efg" ) ;
    result1 = "3.1 efgc\n4.1 efgc\n5.1 efgc\n";
    check(tb1,result1);
    
    replaceText (tb1, "3", "t") ; 
    result1 = "t.1 efgc\n4.1 efgc\n5.1 efgc\n";
    
    check(tb1,result1);
    
    releaseTB (tb1);
    printf("Passed Test5\n");
    //replace finish
    printf("Test6\n ");
    
    ori1 = "1.1 abc\n1.2 abcd\n1.3 abcde\n1.4 abcdef\n";
    result1 = "1.1 abc\n1.2 abcd\n1.3 abcde\n1.4 abcdef\n";
    
    tb1 = newTB(ori1);
    
    swapTB (tb1, 0, 1);
    result1 = "1.2 abcd\n1.1 abc\n1.3 abcde\n1.4 abcdef\n";
    check(tb1,result1);

    swapTB (tb1, 0, 1);
    result1 = "1.1 abc\n1.2 abcd\n1.3 abcde\n1.4 abcdef\n";
    check(tb1,result1);

    swapTB (tb1, 1, 2);
    result1 = "1.1 abc\n1.3 abcde\n1.2 abcd\n1.4 abcdef\n";
    check(tb1,result1);

    swapTB (tb1, 1, 2);
    result1 = "1.1 abc\n1.2 abcd\n1.3 abcde\n1.4 abcdef\n";
    check(tb1,result1);

    swapTB (tb1, 2, 3);
    result1 = "1.1 abc\n1.2 abcd\n1.4 abcdef\n1.3 abcde\n";
    check(tb1,result1);

    swapTB (tb1, 3, 2);
    result1 = "1.1 abc\n1.2 abcd\n1.3 abcde\n1.4 abcdef\n";
    check(tb1,result1);
    releaseTB (tb1);
    // finish the swape test
    printf("Passed Test6\n");
    
    printf("Test7\n");
    
    ori1 = "1.1 d\n1.3 d\n1.4 d\n";
    
    ori2 = "2.1 d\n";
    
    tb1 = newTB(ori1);
    tb2 = newTB(ori2);
    
    pasteTB (tb1, 1, tb2);
    result1 = "1.1 d\n2.1 d\n1.3 d\n1.4 d\n";
    check(tb1,result1);
    releaseTB (tb1);
    releaseTB (tb2);
    //finish the pastesTB
    printf("Passed Test7\n");
    
    printf("Test8\n");
    ori1 = "1.1 adc\n1.2 abcd\n1.3 abcde\n1.4 abcdef\n";
    tb1 = newTB(ori1);
    t4 = copyTB (tb1, 1, 2);
    result1 = "1.1 adc\n1.2 abcd\n1.3 abcde\n1.4 abcdef\n";
    check(tb1,result1);
    result2 = "1.2 abcd\n1.3 abcde\n";
    check(t4,result2);
    //finish the copy and cut funtion test
    
    releaseTB (tb1);
    releaseTB (t4);
    
    printf("Test8 passed\n");
    return EXIT_SUCCESS;
}
void check(TB tb,char *str){
    char *str1 = dumpTB (tb);
    
    assert(!strcmp(str1,str));
    free(str1);
}






