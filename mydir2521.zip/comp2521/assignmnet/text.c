#include <stdlib.h>
#include <string.h>
#include<assert.h>
#include <stdio.h>

#include "textbuffer.h"
int length(TB tb);

struct textbuffer{
    TB next;
    char *texts;
    
};


/* Allocate a new textbuffer whose contents is initialised with the text given
 * in the array.
 */

TB newTB (char text[]){
    TB new,node;
    TB h;
    int i,count = 0;
    char *first = &text[0];
    
    for(i=0;i<strlen(text);i++){
        if(text[i]=='\n'){
            if((new = malloc(sizeof(struct textbuffer)))==NULL){
                fprintf(stderr,"infullcent allocate");
            }
        
            if((new->texts = malloc((i-count+1)*sizeof(char)))==NULL){
                fprintf(stderr,"infullcent allocate");
            }
            
            strncpy(new->texts,first,i-count+1);
            first = &text[i+1];
            
            if(count == 0){
                h = new;
                
                
            }
            else{
                node->next = new;
                
                
            }
            count = i+1;
            node = new;
            
        }
       
    }
    
    new->next = NULL;
    return h;
}

/* Free the memory occupied by the given textbuffer.  It is an error to access
 * the buffer afterwards.
 */
void releaseTB (TB tb){
    assert(tb!=NULL);
    
    TB curr = tb;
    while(curr!=NULL){
        TB de = curr->next;
        free(curr->texts);
        free(curr);
        curr = de;
        
        
    }
}

/* Allocate and return an array containing the text in the given textbuffer.
 */
int length(TB tb){
    
    TB curr = tb;
    int i=0,count=0;
    while(curr!=NULL){
        
        for(i=0;curr->texts[i]!='\n';i++);
        
        count = count +i+1;
        
        curr = curr->next;
    }
    
    return count;
}
char *dumpTB (TB tb){
    assert(tb!=NULL);
    
    char *value;
    if((value = malloc((length(tb)+1)*sizeof(char)))==NULL){
        fprintf(stderr,"infullcent allocate");
    }
    
    TB curr = tb;
    
    while(curr!=NULL){
        
        strcat(value,curr->texts);
        curr = curr->next;
    }
    
    strcat(value,"\0");
    return value;
}
/* Return the number of lines of the given textbuffer.
 */
int linesTB (TB tb){
    int count = 0;
    TB curr = tb;
    while(curr!=NULL){
        count++;
        curr = curr->next;
    }
    return count;
}

/* Swap the two given lines in the textbuffer.
 *
 * - The program is to abort() with an error message if line 'pos1' or line
 *   'pos2' is out of range.  The first line of a textbuffer is at position 0.
 */
void swapTB (TB tb, int pos1, int pos2){
    char *exchange;
    int i=0;
    TB curr,ex1,ex2;
    if(pos1<0||pos2<0||pos1>(linesTB(tb)-1)||pos2>(linesTB(tb)-1)){
        fprintf(stderr,"out of range\n");
        abort();
        
    }
    else{
        for(curr=tb;curr!=NULL;curr = curr->next){
            if(i==pos1){
                ex1 = curr;
                exchange = curr->texts;
            }
            if(i==pos2){
                ex2 = curr;
            }
            i++;
        }
        ex1->texts = ex2->texts;
        ex2->texts = exchange;
        
    }
}

/* Merge 'tb2' into 'tb1' at line 'pos'.
 * 
 * - Afterwards line 0 of 'tb2' will be line 'pos' of 'tb1'.
 * - The old line 'pos' of 'tb1' will follow after the last line of 'tb2'.
 * - After this operation 'tb2' can not be used anymore (as if we had used
 *   releaseTB() on it).
 * - The program is to abort() with an error message if 'pos' is out of range.
 */
void mergeTB (TB tb1, int pos, TB tb2){
    TB curr1 = tb1;
    
    TB curr2 = tb2;
    int i=0;
    if(pos<0||pos>linesTB(tb1)) abort();
    while(curr1!=NULL){
        if(i==pos) break;
        curr1 = curr1->next;
        i++;
    }
    
    if(i==0){
        while(curr2->next!=NULL){
            curr2 = curr2->next;
        }
        //printf("curr2%s\n curr1 %s\n",curr2->texts,curr1->texts);
        
        curr2->next = curr1;
        tb1->texts = tb2->texts;
        tb1 = tb2;
        tb1->next = tb2->next;
        
    }
    else{
        i=0;
        for(curr1 = tb1;curr1!=NULL&&i==pos-1;curr1 = curr1->next) i++; 
        TB re = curr1->next; 
        curr1 ->next = tb2;
        for(curr2 = tb2;curr2->next!=NULL;curr2 = curr2->next);
        curr2-> next = re;
    }
    //releaseTB (tb2);
    
}

/* Copy 'tb2' into 'tb1' at line 'pos'.
 * 
 * - Afterwards line 0 of 'tb2' will be line 'pos' of 'tb1'.
 * - The old line 'pos' of 'tb1' will follow after the last line of 'tb2'.
 * - After this operation 'tb2' is unmodified and remains usable independent
 *   of 'tb1'. 
 * - The program is to abort() with an error message if 'pos' is out of range.
 */
void pasteTB (TB tb1, int pos, TB tb2){
    TB curr1 = tb1;
    
    TB curr2 = tb2;
    int i=0;
    if(pos<0||pos>linesTB(tb1)) abort();
    while(curr1!=NULL){
        if(i==pos) break;
        curr1 = curr1->next;
        i++;
    }
    
    if(i==0){
        while(curr2->next!=NULL){
            curr2 = curr2->next;
        }
        
        
        curr2->next = curr1;
        tb1->texts = tb2->texts;
        
        tb1->next = tb2->next;
        
    }
    else{
        i=0;
        for(curr1 = tb1;curr1!=NULL&&i==pos-1;curr1 = curr1->next) i++; 
        TB re = curr1->next; 
        curr1 ->next = tb2;
        for(curr2 = tb2;curr2->next!=NULL;curr2 = curr2->next);
        curr2-> next = re;
    }
    
}

/* Cut the lines between and including 'from' and 'to' out of the textbuffer
 * 'tb'.
 *
 * - The result is a new textbuffer (much as one created with newTB()).
 * - The cut lines will be deleted from 'tb'.
 * - The program is to abort() with an error message if 'from' or 'to' is out
 *   of range. 
 */
TB cutTB (TB tb, int from, int to){

   if(from<0||to<0||from>linesTB(tb)||to>linesTB(tb)){
        abort();
    }
    if(from>to){
        return NULL;
    }
    
}

/* Copy the lines between and including 'from' and 'to' of the textbuffer
 * 'tb'.
 *
 * - The result is a new textbuffer (much as one created with newTB()).
 * - The textbuffer 'tb' will remain unmodified.
 * - The program is to abort() with an error message if 'from' or 'to' is out
 *   of range. 
 */
TB copyTB (TB tb, int from, int to){
    if(from<0||to<0||from>linesTB(tb)||to>linesTB(tb)){
        abort();
    }
    if(from>to){
        return NULL;
    }
    char *str;
    
}

/* Remove the lines between and including 'from' and 'to' from the textbuffer
 * 'tb'.
 *
 * - The program is to abort() with an error message if 'from' or 'to' is out
 *   of range. 
 */
void deleteTB (TB tb, int from, int to){
    TB curr = tb;
    
    int i=0;
    if(from<0||to<0||from>to||from>linesTB(tb)||to>linesTB(tb)){
        abort();
    }
    else{
        
        
        while(curr!=NULL){
            if(i>=from&&i<=to){
                if(from==0){
                    TB next = curr->next;
                    
                    printf("release tb %s\n",curr->texts);
                    free(curr);
                    curr = next;
                    
                }
                
            
            }
            else{
                curr = curr->next;
            }   
            
            i++;
        }
    
   } 
}


/* Search every line of tb for each occurrence of str1 and replaces them 
 * with str2
 */
void replaceText (TB tb, char* str1, char* str2) {

}
char* diffTB (TB tb1, TB tb2) {
    return NULL;
}

void undoTB (TB tb) {
    

}

void redoTB (TB tb) {
    
}

