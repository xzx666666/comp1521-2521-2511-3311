#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "lists.h"

void printList (link list) {
    link curr = list;
    while (curr != NULL) {
        printf ("[%d]->", curr->item);
        curr = curr->next;
    }
    printf ("[X]\n");
}

// Create a new node, initialised with the item provided. Return
// pointer to node (link)
link newNode(Item item){
    link n = malloc(sizeof(*n));
    if(n==NULL) printf("Insufficient memory");
    n->item = item;
    n->next = NULL;
    return n;
}

// Insert a new node into a given non-empty list
// The node is inserted directly after the head of the list ls
void insertNext(link ls, link node){
    assert(ls != NULL);
    assert(node != NULL);
    node->next = ls->next;
    ls->next = node;
}

// return the sum of all items in list
int sumListItems (link ls) {
    
    int count = 0;
    for(link curr = ls ; curr != NULL ; curr  = curr->next ){
        count++;
    
    }
    return count;
}

//frees all memory used in the list
void freeList(link list){
    
    link curr = list ; 
    if(list == NULL) return ;
    
    /*while(curr!= NULL ){
    
        if(curr == curr->next||curr->next == NULL){
            curr = NULL;
            free(curr);
        
        }
        
        else{
            link d = curr->next->next;
        
            free(curr->next);
            curr->next = d;
        }*/
    
    //circle link list mark the first node at first
    while(curr->next!=NULL&&curr->next != list){
        
        link delete = curr->next;
        
        free(curr);
        curr = delete;

    }
    free(curr);
}
    
    


// create a circular list with the number of nodes specified with
// each link storing data from 1 to the number of nodes specified
link createCircularList (int numNodes){
    int i;
    
    if(numNodes<1){
        return NULL;
    }
    
    link first = newNode(1);
    
    link curr = first;
    
    for(i=2;i<=numNodes;i++){
        link new = newNode(i);
        curr->next = new;
        curr = curr->next;
        
    }
    
    curr->next = first;
    return first;
}

// print the data in a circular fashion starting from any node
void printCircularList(link list){
    
    link curr = list;
        while (curr ->next != list) {
            printf ("[%d]->", curr->item);
            curr = curr->next;
        }
        printf ("[%d]\n",curr->item);

    
}

// create a double-linked list which has contains the same elements,
// in the same order as 'list'
dlink doublify (link list) {
    assert(list!=NULL);
    
    dlink new = newDNode(list->item);
    
    for(link curr = list->next; curr!=NULL;curr = curr->next){
        
        dlink b = newDNode(curr->item);
        appendDNode(new,b);

    }
    return new;
}
void printdlist(dlink list){
    dlink curr = list;
    while (curr != NULL) {
        printf ("[%d]->", curr->item);
        curr = curr->next;
    }
    printf ("[X]\n");


}

// frees all the memory used in the double-linked list
void freeDList(dlink list){
    assert(list!=NULL);
    dlink curr = list;
    while(curr != NULL ){
        dlink d = curr;
        curr = curr->next;
        free(d);
    
    }
}
dlink appendDNode(dlink list,dlink newnode){
    dlink curr = list;
    while(curr->next!=NULL){
    curr = curr->next;
    
    }
    curr->next = newnode;
    newnode->prev = curr;
    return  list;
    
}
dlink newDNode(Item item){
    dlink n = malloc(sizeof(*n));
    if(n==NULL) printf("Insufficient memory");
    n->item = item;
    n->next = NULL;
    n->prev = NULL;
    return n;
}
