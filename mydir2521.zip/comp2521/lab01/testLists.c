#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "lists.h"

// insert proper tests here
int main (int argc, const char * argv[]) {
    link list = NULL; 
    
    //test the length of list and insert the list after the head of list
    /*
    printf("     ***insert 3 node in the list ***\n");
    
    list = newNode(1);
    link list2 = NULL; 
    list2 = newNode(2);
    insertNext(list, list2);
    list2 = newNode(3);
    insertNext(list, list2);
    printList(list);
    int num;
    num  = sumListItems (list);
    printf("sum of the list is %d\n",num);
    printf("     ***test the function free list***\n");
    
    printf("show the list behind free\n ");
    printList(list);
    
    freeList(list);
    
    printf("show the free list\n");
    */
    /*
    printf("     ***test the circle link lists\n");
    
    printf("creat circle by 0 element\n");
    link list1 = createCircularList (0);
    //printCircularList(list1);
    
    printf("creat circle by 1 element\n");
    link list2 = createCircularList (1);
    //printCircularList(list2);
    
    printf("creat circle by 9 element\n");
    link list3 = createCircularList (9);
    printCircularList(list3);
    freeList(list3);
    freeList(list2);
    freeList(list1);
    */
    
    printf("test the link to dlink\n");
    list = newNode(1);
    link list3 = NULL; 
    list3 = newNode(2);
    insertNext(list, list3);
    list3 = newNode(3);
    insertNext(list, list3);
    printList(list);
    
    dlink dl = doublify (list);
    printdlist(dl);
    freeDList(dl);
    freeList(list);
    
    return 0;
}
