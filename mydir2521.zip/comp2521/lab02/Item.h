typedef int Item;
#define eq(A, B)  (A == B)
