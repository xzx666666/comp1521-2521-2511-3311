#include <stdlib.h>
#include <stdio.h>
#include "Item.h"
#include "Queue.h"
#include <assert.h>

#define DEFAULT_SIZE 10
void queueCycle(Queue q,int num);

struct queueImp{
    Item *items;
    int size;
    int maxSize;
};

//O(1)
Queue createQueue(){
    Queue q = malloc(sizeof(struct queueImp));
    q->items = malloc(DEFAULT_SIZE * sizeof(Item));
    q->size =0;
    q->maxSize = DEFAULT_SIZE;
    return q;
}

void destroyQueue(Queue q){
    assert(q != NULL);
    free(q->items);
    free(q);
}

//O(1)
int queueSize(Queue q){
    assert(q != NULL);
    return (q->size);
}

//O(1);
void putQueue(Queue q, Item i){
    assert(q != NULL);
    assert(q->size < q->maxSize);
    
    q->items[(q->size++)%DEFAULT_SIZE]  = i;
}

//O(n)
Item getQueue(Queue q){
    
    assert(q != NULL);
    if(q->size > 0){
        Item item = q->items[DEFAULT_SIZE-q->size];
        q->size--;
        return item;
    } else {
        fprintf(stderr,"queue underflow\n");
        abort();
    }
}

void queueWhiteBoxTests(void){
    printf("white box test queue\n");
    Queue q = createQueue();
    assert(q->size==0);
    printf("passed test1\n");
    queueCycle( q,10);
    
    destroyQueue(q);
    
}
void queueCycle(Queue q,int num){
    int i;
    printf("put %d elements\n",num);
    for(i=0;i<num;i++){
        putQueue(q, i);
        assert(q->size==i+1);
        assert(q->items[i]==i);

    }
    printf("Passed\n");
    printf("get %d elements\n",num);
    
    for(i=0;i<num;i++){
        //printf("get %d\n",getQueue (q));
        assert(getQueue (q)== i);
        assert(q->size == num-i-1);
    
    }
    printf("Passed\n");




}
