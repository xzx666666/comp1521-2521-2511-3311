//A linked list implementation of a queue

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "Item.h"
#include "Queue.h"
void CheckQueueListValue(Queue q,int i);
void testQueueCycle(Queue q,int num);

typedef struct queueNode * link;

struct queueNode { 
    Item item; 
    link next; 
};

struct queueImp { 
    link head; 
    link tail;
    int size; 
};

static link createNode(Item item){ 
    link n = malloc (sizeof(*n));
    assert(n != NULL);
    n->item = item; 
    n->next = NULL;     
    return n;                         
}

// Creates an empty Queue
Queue createQueue (void){ 
    Queue q = malloc (sizeof (*q));
    assert(q != NULL); 
    q->head = NULL; 
    q->tail = NULL;
    q->size = 0; 
    return q;
}

void destroyQueue(Queue queue){
    link curr;
    link next;
    assert(queue != NULL);
    curr = queue->head;
    while(curr!=NULL){
        next = curr->next;
        free(curr);
        curr = next;
    }
    free(queue);

}

int queueSize (Queue q){ 
    assert(q != NULL);
    return q->size; 
}


void putQueue (Queue q, Item item){ 
    assert(q != NULL); 
    link n = createNode(item);
    if(q->head == NULL){
        q->head = n;
        q->tail = n;
    }
    else{
        
        q->tail->next = n;
        q->tail = n;
        
    }
    
    q->size++;

}

Item getQueue (Queue q){ 
    assert(q != NULL);
    Item item = q->head->item;
    link delNode = q->head;
    q->head = q->head->next;      
    free(delNode);
    q->size--;
    return item;
    


}

void queueWhiteBoxTests(void){
    printf("White box tests: \n");
    
    Queue q = createQueue ();
    assert(q->size==0);
    printf("Passed\n");
    testQueueCycle(q,10);
    
    
    destroyQueue(q);
}


void CheckQueueListValue(Queue q,int i){

    link curr = q->tail;
     
     assert(curr->item==i);
     
}

void testQueueCycle(Queue q,int num){
    int i;
    printf("put %d elements\n",num);
    for(i=0;i<num;i++){
        putQueue (q,i);
        assert(q->size ==i+1);
        CheckQueueListValue(q,i);
    
    }
    printf("Passed\n");
    printf("get %d elements\n",num);
    for(i=0;i<num;i++){
        assert(getQueue (q)==i);
        assert(q->size == num-i-1);
    
    }
    printf("Passed\n");
}


