#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "Item.h"
#include "Queue.h"

void queueWhiteBoxTests(void);
void QueueCycle(Queue q,int num);

int main (int argc, char *argv[]){
    //Run white box tests
    queueWhiteBoxTests();

    //Run black box tests
    printf("Black Box tests:\n");
    Queue q = createQueue();
    assert(queueSize(q)==0);
    
    printf("Passed\n");
    QueueCycle(q,10);
    
    
    destroyQueue(q);
    return 0;
}       
void QueueCycle(Queue q,int num){
    int i;
    printf("put %d elements\n",num);
    for(i=0;i<num;i++) {
    
        putQueue(q, i);
        assert(queueSize (q) == i+1);
    }
    printf("Passed\n");
    printf("get %d elements\n",num);
    for(i=0;i<num;i++) {
        assert(getQueue(q)==i);
        assert(queueSize(q)==num-i-1);
    }
    printf("Passed\n");

}
