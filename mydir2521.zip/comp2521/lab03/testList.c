// testList.c - testing DLList data type
// Written by Zixin Xiao, March 2013

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "DLList.h"

int main(int argc, char *argv[])
{
	DLList myList;
	myList = getDLList(stdin);
	putDLList(stdout,myList);
	assert(validDLList(myList));
	
	printf("now start the test\n");
	
	//the first test insert three nodes before list
	
	printf("\ninsert 3 node before the orignal first node\n");
	int i;
	for( i=0;i<3;i++){
	    char string[2];
	    sprintf(string,"%d",i);
	    DLListBefore(myList, string);
	}
	showValue(myList);
	printf("now the list is\n");
	putDLList(stdout,myList);
	assert(validDLList(myList));
	
	//the second test is move in the list;
	printf("\nmove the curr before the position of curr\n");
	DLListMove(myList, 2);
	showValue(myList);
	printf("move the curr after the position of curr\n");
	DLListMove(myList, -2);
	showValue(myList);
	printf("move the curr outside of list\n");
	DLListMove(myList, -2999);
	showValue(myList);
	
	printf("\nnow the list is\n");
	putDLList(stdout,myList);
	assert(validDLList(myList));
	
	//the tired test is insert four node after the curr
	printf("\ninsert four node after the 2rd \n");
	DLListMoveTo(myList, 2);
	for(i=8;i<28;i+=5){
	    char string[5];
	    sprintf(string,"%d",i);
	    DLListAfter(myList, string);
	}
	showValue(myList);
	printf("\nnow the list is\n");
	putDLList(stdout,myList);
	assert(validDLList(myList));
	//the fourth test is delete 10 items 
	printf("test the delete ten items\n");
	for(i=0;i<10;i++){
	     DLListDelete(myList);
	     showValue(myList);
	
	}
	printf("\nthe list now is\n");
	putDLList(stdout,myList);
	assert(validDLList(myList));
	printf("end of test\n");
	return 0;
}

void showValue(DLList L){
    if(validDLList(L)){
        if(DLListLength(L)){
            printf("there are %d items\n",DLListLength(L));
            
            printf("this is L->first %s\n",DLListFirst(L));
            
            printf("this is L->curr %s\n",DLListCurrent(L));
            
            printf("this is L->last %s\n",DLListLast(L));
        
        }
    
    
    }


}
