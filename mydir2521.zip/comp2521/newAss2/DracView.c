////////////////////////////////////////////////////////////////////////
// COMP2521 18x1 ... the Fury of Dracula
// DracView.c: the DracView ADT implementation
//
// 2014-07-01   v1.0    Team Dracula <cs2521@cse.unsw.edu.au>
// 2017-12-01   v1.1    Team Dracula <cs2521@cse.unsw.edu.au>

#include <assert.h>
#include <err.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sysexits.h>
#include <string.h>
#include <stdio.h>

#include "DracView.h"
#include "Game.h"
#include "GameView.h"
#include "Globals.h"
#include "updateDrac.h"
#include "Map.h"// ... if you decide to use the Map ADT

// Creates a new DracView to summarise the current state of the game
DracView
newDracView (char *pastPlays, PlayerMessage messages[])
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    DracView new = malloc (sizeof (struct dracView));
    if (new == NULL) err (EX_OSERR, "couldn't allocate DracView)");
    
    playerAlloc_Drac(new);

    init_Drac(new);
    init_DracTraps();
    init_LastMove();
    //finished initialization
    int i = 0,length = strlen(pastPlays), currPlayer = 0;
    char loc[3], *start = pastPlays; loc[2] = '\0';
    for(i = 0; i < length; i++){
        switch (i % STR_LENGTH){
            case DRA_LOCATION:{
                updatePlayerLocation_Drac(new,PLAYER_DRACULA,loc,start);
                seaAction_Drac(new,loc,start);
                updateDracTrap(new,loc,start);
                if(strToId(loc) == CASTLE_DRACULA && new->players[PLAYER_DRACULA]->health > 0)
                    new->players[PLAYER_DRACULA] += 10;
                if(abbrevToID(loc) != UNKNOWN_LOCATION)
                    updateLastMove(PLAYER_DRACULA,abbrevToID(loc));
                else{
                    updateLastMove(PLAYER_DRACULA,strToId(loc));
                }
                new->score -= 1;
                break;
            }
            case LOR_LOCATION:
            case DR_LOCATION:
            case VAN_LOCATION:
            case MINA_LOCATION:{
                currPlayer = ((i % STR_LENGTH) - 1)/UNIT_LENGTH;
                updatePlayerLocation_Drac(new,currPlayer,loc,start);
                updateLastMove(currPlayer,abbrevToID(loc));
                break;
            }
            case LOR_TRAP:
            case DR_TRAP:
            case VAN_TRAP:
            case MINA_TRAP:{
                hunterTrap_Drac(new,start,currPlayer);
                break;
            }
            case DRAC_VAMPIRE:{ //vampire mature
                if(*start == 'V') new->score -= 13;
                break;
            }
        }
        start++;
    }
    new->round = length/(STR_LENGTH-1);
    return new;
}

// Frees all memory previously allocated for the DracView toBeDeleted
void
disposeDracView (DracView toBeDeleted)
{
    // COMPLETE THIS IMPLEMENTATION
    for(int i = 0; i < MAX_PLAYERS; i++){
        free(toBeDeleted->players[i]);
        free(playersLastMove[i]);
    }
    for(int i = 0; i < NUM_MAP_LOCATIONS; i++)
        free(all_traps[i]);
    free (toBeDeleted);
}
//// Functions to return simple information about the current state of the game

// Get the current round
Round
giveMeTheRound (DracView dv)
{
    return dv->round;
}

// Get the current score
int
giveMeTheScore (DracView dv)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    return dv->score;
}

// Get the current health points for a given player
int
howHealthyIs (DracView dv, PlayerID player)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    return dv->players[player]->health;
}

// Get the current location id of a given player
LocationID
whereIs (DracView dv, PlayerID player)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    return dv->players[player]->location;
}

// Get the most recent move of a given player
void
lastMove (DracView dv, PlayerID player,
    LocationID *start, LocationID *end)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    *start = playersLastMove[player]->start;
    *end = playersLastMove[player]->end;
}

// Find out what minions are placed at the specified location
void
whatsThere (DracView dv, LocationID where,
    int *numTraps, int *numVamps)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    *numTraps = all_traps[where]->numTraps;
    *numVamps = all_traps[where]->numVamps;
}

//// Functions that return information about the history of the game

// Fills the trail array with the location ids of the last 6 turns
void
giveMeTheTrail (DracView dv, PlayerID player,
    LocationID trail[TRAIL_SIZE])
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    int i = 0;
    for(i = 0; i < MAX_HISTORY; i++){
        trail[i] = dv->players[player]->loc_history[i];
    }
}

//// Functions that query the map to find information about connectivity

// What are my (Dracula's) possible next moves (locations)
LocationID *
whereCanIgo (DracView dv, int *numLocations, bool road, bool sea)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    int from = dv->players[PLAYER_DRACULA]->location;
    int size = 0, count = 0, player = PLAYER_DRACULA;
    int arr[NUM_MAP_LOCATIONS];
    
    LocationID *loc = Connections(player, 0, from, road, false, sea, &size);
    for(int i = 0; i < size; i++){
        if(!isBeenThere(dv->players[player]->loc_history,loc[i],MAX_HISTORY-1,from)){
            arr[count] = loc[i];
            count++;
        }
    }
    dv->players[PLAYER_DRACULA]->availableLoc = malloc(count*sizeof(int));
    memcpy(dv->players[PLAYER_DRACULA]->availableLoc,arr,count*sizeof(int));
    *numLocations = count;
    return dv->players[player]->availableLoc;
}

// What are the specified player's next possible moves
LocationID *
whereCanTheyGo (DracView dv, int *numLocations, PlayerID player,
    bool road, bool rail, bool sea)
{
    int from = dv->players[player]->location;
    int round = dv->round;
    
    dv->players[player]->availableLoc = Connections(player, round, from, road, rail, sea, numLocations);
    return dv->players[player]->availableLoc;
}


