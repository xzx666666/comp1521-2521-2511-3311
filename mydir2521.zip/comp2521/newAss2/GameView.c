////////////////////////////////////////////////////////////////////////
// COMP2521 18x1 ... the Fury of Dracula
// GameView.c: GameView ADT implementation
//
// 2014-07-01   v1.0    Team Dracula <cs2521@cse.unsw.edu.au>
// 2017-12-01   v1.1    Team Dracula <cs2521@cse.unsw.edu.au>

#include <assert.h>
#include <err.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sysexits.h>
#include <string.h>
#include <stdio.h>

#include "Game.h"
#include "GameView.h"
#include "Globals.h"
#include "Map.h" //... if you decide to use the Map ADT

//#include "update.h"
#include "updateGame.h"

// Creates a new GameView to summarise the current state of the game
GameView
newGameView (char *pastPlays, PlayerMessage messages[])
{
    GameView new = malloc (sizeof (struct gameView));
    if (new == NULL) err (EX_OSERR, "couldn't allocate GameView");
    playerAlloc(new);
    init(new);
    //finished initialization
    int i = 0,length = strlen(pastPlays), currPlayer = 0;
    char loc[3], *start = pastPlays; loc[2] = '\0';
    for(i = 0; i < length; i++){
        switch (i % STR_LENGTH){
            case DRA_LOCATION:{
                updatePlayerLocation(new,PLAYER_DRACULA,loc,start);
                seaAction(new,loc,start);
                if(strToId(loc) == CASTLE_DRACULA && new->players[PLAYER_DRACULA]->health > 0)
                    new->players[PLAYER_DRACULA] += 10;
                new->score -= 1;
                break;
            }
            case LOR_LOCATION:
            case DR_LOCATION:
            case VAN_LOCATION:
            case MINA_LOCATION:{
                currPlayer = ((i % STR_LENGTH) - 1)/UNIT_LENGTH;
                updatePlayerLocation(new,currPlayer,loc,start);
                if(new->players[currPlayer]->health <= 0 && strToId(loc) == ST_JOSEPH_AND_ST_MARYS){
                    new->players[currPlayer]->health = 9;
                    new->score -= 6;
                }
                break;
            }
            case LOR_TRAP:
            case DR_TRAP:
            case VAN_TRAP:
            case MINA_TRAP:{
                hunterTrap(new,start,currPlayer);
                break;
            }

            case DRAC_VAMPIRE:{ //vampire mature
                if(*start == 'V') new->score -= 13;
                break;
            }
        }
        start++;
    }
    new->round = length/(STR_LENGTH-1);
    return new;
}

// Frees all memory previously allocated for the GameView toBeDeleted
void
disposeGameView (GameView toBeDeleted)
{
    int i = 0;
    for(i = 0; i < MAX_PLAYERS; i++){
        free(toBeDeleted->players[i]);
    }
    free (toBeDeleted);
}

//// Functions to return simple information about the current state of the game

// Get the current round
Round
getRound (GameView gv)
{
    return gv->round;
}

// Get the id of current player - ie whose turn is it?
PlayerID
getCurrentPlayer (GameView gv)
{
    return gv->currentPl;
}

// Get the current score
int
getScore (GameView gv)
{
    return gv->score;
}

// Get the current health points for a given player
int
getHealth (GameView gv, PlayerID player)
{
    return gv->players[player]->health;
}

// Get the current location id of a given player
LocationID
getLocation (GameView gv, PlayerID player)
{
    return gv->players[player]->location;
}

//// Functions that return information about the history of the game

// Fills the trail array with the location ids of the last 6 turns
void
getHistory (GameView gv, PlayerID player, LocationID trail[TRAIL_SIZE])
{
    int i = 0;
    for(i = 0; i < MAX_HISTORY; i++){
        trail[i] = gv->players[player]->loc_history[i];
    }
}

void dracConnections(GameView gv, int *numLocations, int from, bool road, bool sea){
    int size = 0,count = 0,player = PLAYER_DRACULA;
    int arr[100];
    LocationID *loc = Connections(player, 0, from, road, false, sea, &size);
    for(int i = 0; i < size; i++){
        if(!isBeenThere(gv->players[player]->loc_history,loc[i],MAX_HISTORY-1,from)){
            arr[count] = loc[i];
            count++;
        }
    }
    gv->players[PLAYER_DRACULA]->availableLoc = malloc(sizeof(int)*count);
    memcpy(gv->players[PLAYER_DRACULA]->availableLoc,arr,count*sizeof(int));
    *numLocations = count; 
}

//// Functions that query the map to find information about connectivity

// Returns an array of LocationIDs for all directly connected locations

LocationID *connectedLocations (GameView gv, int *numLocations,
    LocationID from, PlayerID player, Round round,
    bool road, bool rail, bool sea)
{
    if(player != PLAYER_DRACULA)
        gv->players[player]->availableLoc = Connections(player, round, from, road, rail, sea, numLocations);
    else{
        if(gv->players[player]->location > NUM_MAP_LOCATIONS){
            *numLocations = 0;
            return NULL;
        }
        else
            dracConnections(gv, numLocations, from, road, sea);
    }
    return gv->players[player]->availableLoc;
}

