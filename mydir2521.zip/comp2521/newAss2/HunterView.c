////////////////////////////////////////////////////////////////////////
// COMP2521 18x1 ... the Fury of Dracula
// HunterView.c: the HunterView ADT implementation
//
// 2014-07-01   v1.0    Team Dracula <cs2521@cse.unsw.edu.au>
// 2017-12-01   v1.1    Team Dracula <cs2521@cse.unsw.edu.au>

#include <assert.h>
#include <err.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sysexits.h>
#include <string.h>
#include <stdio.h>

#include "HunterView.h"
#include "Game.h"
#include "GameView.h"
#include "Globals.h"
#include "Map.h" //... if you decide to use the Map ADT

#include "updateHunt.h"

void playerAlloc_Hunt(HunterView new){
    int i = 0;
    for(i = 0; i < MAX_PLAYERS; i++)
        new->players[i] = malloc(sizeof(struct _playerView));
}

void init_Hunt(HunterView n){
    n->score = 366;
    n->round = 0;
    n->currentPl = PLAYER_LORD_GODALMING;
    
    int i = 0, j = 0;
    for(i = 0; i < MAX_PLAYERS; i++){
        n->players[i]->health = 9;
        n->players[i]->location = UNKNOWN_LOCATION;
        for(j = 0; j < MAX_HISTORY; j++){
            n->players[i]->loc_history[j] = -1;
        }
    }
    n->players[MAX_PLAYERS-1]->health = 40;
}

// Creates a new HunterView to summarise the current state of the game
HunterView
newHunterView (char *pastPlays, PlayerMessage messages[])
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    HunterView new = malloc (sizeof(struct hunterView));
    if (new == NULL) err (EX_OSERR, "couldn't allocate HunterView");
    playerAlloc_Hunt(new);
    init_Hunt(new);
    GameView gv = newGameView(pastPlays, messages);
    new->score = getScore(gv);
    new->round = getRound(gv);
    new->currentPl = getCurrentPlayer(gv);
    for(int i = 0; i < MAX_PLAYERS; i++){
        new->players[i]->health = getHealth(gv,i);
        new->players[i]->location = getLocation(gv,i);
        getHistory (gv, i, new->players[i]->loc_history);
    }
    disposeGameView(gv);
    return new;
}

// Frees all memory previously allocated for the HunterView toBeDeleted
void
disposeHunterView (HunterView toBeDeleted)
{
    // COMPLETE THIS IMPLEMENTATION
    for(int i = 0; i < MAX_PLAYERS; i++){
        //free(toBeDeleted->players[i]->avai)
        free(toBeDeleted->players[i]);
    }
    free (toBeDeleted);
}

//// Functions to return simple information about the current state of the game

// Get the current round
Round
giveMeTheRound (HunterView hv)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    return hv->round;
}

// Get the id of current player
PlayerID
whoAmI (HunterView hv)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    if(hv->currentPl == PLAYER_DRACULA){
        return PLAYER_LORD_GODALMING;
    }
    else{
        return hv->currentPl;
    }
    return 0;
}

// Get the current score
int
giveMeTheScore (HunterView hv)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    return hv->score;
}

// Get the current health points for a given player
int
howHealthyIs (HunterView hv, PlayerID player)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    if(hv->players[player]->health < 0){
        hv->players[player]->health = 0;
    }
    return hv->players[player]->health;
}

// Get the current location id of a given player
int backOrHide(int location){
    if(location == HIDE) return 1;
    if(location >= DOUBLE_BACK_1 && location <= DOUBLE_BACK_5){
        return location - HIDE;
    }
    else return 0;
}

LocationID
whereIs (HunterView hv, PlayerID player)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    if(player != PLAYER_DRACULA)
        return hv->players[player]->location;
    else{
        int i = 0, loc = 0, history;
        if(hv->players[player]->location == TELEPORT){
            return CASTLE_DRACULA;
        }
        while((i = backOrHide(hv->players[PLAYER_DRACULA]->loc_history[loc])) != 0){
            loc = loc + i;
        }
        history = hv->players[PLAYER_DRACULA]->loc_history[loc];
        if(history > NUM_MAP_LOCATIONS){
            if(hv->players[player]->location == HIDE){
                return hv->players[PLAYER_DRACULA]->loc_history[1];
            }
            else{
                return hv->players[PLAYER_DRACULA]->loc_history[0];
            }
        }
        return hv->players[PLAYER_DRACULA]->loc_history[loc];
    }
    return -1;
}

//// Functions that return information about the history of the game

// Fills the trail array with the location ids of the last 6 turns
void
giveMeTheTrail (HunterView hv, PlayerID player,
    LocationID trail[TRAIL_SIZE])
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    for(int i = 0; i < MAX_HISTORY; i++)
        trail[i] = hv->players[player]->loc_history[i];
}


//// Functions that query the map to find information about connectivity

// What are my possible next moves (locations)
LocationID *
whereCanIgo (HunterView hv, int *numLocations,
    bool road, bool rail, bool sea)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    int player = whoAmI(hv);
    int from = hv->players[player]->location;
    int round = hv->round;
    hv->players[player]->availableLoc = Connections(player, round, from, road, rail, sea, numLocations);
    return hv->players[player]->availableLoc;
}

void dracConnections_Hunt(HunterView hv, int *numLocations, int from, bool road, bool sea){
    int size = 0,count = 0,player = PLAYER_DRACULA;
    int arr[NUM_MAP_LOCATIONS];
    LocationID *loc = Connections(player, 0, from, road, false, sea, &size);
    for(int i = 0; i < size; i++){
        if(!isBeenThere(hv->players[player]->loc_history,loc[i],MAX_HISTORY-1,from)){
            arr[count] = loc[i];
            count++;
        }
    }
    hv->players[PLAYER_DRACULA]->availableLoc = malloc(sizeof(int)*count);
    memcpy(hv->players[PLAYER_DRACULA]->availableLoc,arr,count*sizeof(int));
    *numLocations = count; 
}

// What are the specified player's next possible moves
LocationID *
whereCanTheyGo (HunterView hv, int *numLocations, PlayerID player,
    bool road, bool rail, bool sea)
{
    // REPLACE THIS WITH YOUR OWN IMPLEMENTATION
    if(player != PLAYER_DRACULA){
        int from = hv->players[player]->location;
        int round = hv->round;
        hv->players[player]->availableLoc = Connections(player, round, from, road, rail, sea, numLocations);
    }
    else{
        int from = hv->players[player]->location;
        if(from > NUM_MAP_LOCATIONS){
            *numLocations = 0;
            return NULL;
        }
        else
            dracConnections_Hunt(hv, numLocations, from, road, sea);
    }
    return hv->players[player]->availableLoc;
}


