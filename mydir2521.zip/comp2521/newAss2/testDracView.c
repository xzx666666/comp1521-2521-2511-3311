////////////////////////////////////////////////////////////////////////
// COMP2521 18x1 ... the Fury of Dracula
// testDracView.c: test the DracView ADT
//
// As supplied, these are very simple tests.  You should write more!
// Don't forget to be rigorous and thorough while writing tests.
//
// 2014-07-01   v1.0    Team Dracula <cs2521@cse.unsw.edu.au>
// 2017-12-02   v1.1    Team Dracula <cs2521@cse.unsw.edu.au>

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "DracView.h"


void testDracAction();
int
main (int argc, char *arcv[])
{
    testDracAction();
    return EXIT_SUCCESS;
}

void testDracAction(){
    PlayerMessage messages[] = { "Hello", "Rubbish", "Stuff", "", "Mwahahah"};
    printf("test Dracula action\n");
    
    do{
       printf("test Dracula Hide action\n"); 
       char *trail = "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                     "GBO.... SNU.... HZA.... MNP.... DHI.... ";
       
       DracView dv = newDracView (trail, messages);
       assert(whereIs (dv, PLAYER_LORD_GODALMING)==BO);
       assert(whereIs (dv, PLAYER_DR_SEWARD)==NU);
       assert(whereIs (dv, PLAYER_DRACULA)==ZA);
       assert(whereIs (dv, PLAYER_VAN_HELSING)==NP);
       assert(whereIs (dv, PLAYER_DRACULA)==SJ);
       disposeDracView (dv);
    }while(0);
    do{
        printf("test Dracula Dn action\n");
        do{
            printf("test double back1\n");
            char *trail = "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                          "GBO.... SNU.... HZA.... MNP.... DBE.... "
                          "GBO.... SNU.... HZA.... MNP.... DD1.... ";
                
       
            DracView dv = newDracView (trail, messages);
            assert(whereIs (dv, PLAYER_LORD_GODALMING)==BO);
            assert(whereIs (dv, PLAYER_DR_SEWARD)==NU);
            assert(whereIs (dv, PLAYER_DRACULA)==ZA);
            assert(whereIs (dv, PLAYER_VAN_HELSING)==NP);
            assert(whereIs (dv, PLAYER_DRACULA)==BE);
            disposeDracView (dv);
       }while(0);
       do{
            printf("test double back2\n");
            
            char *trail = "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                          "GBO.... SNU.... HZA.... MNP.... DBE.... "
                          "GBO.... SNU.... HZA.... MNP.... DD2.... ";
                
       
            DracView dv = newDracView (trail, messages);
            assert(whereIs (dv, PLAYER_LORD_GODALMING)==BO);
            assert(whereIs (dv, PLAYER_DR_SEWARD)==NU);
            assert(whereIs (dv, PLAYER_DRACULA)==ZA);
            assert(whereIs (dv, PLAYER_VAN_HELSING)==NP);
            assert(whereIs (dv, PLAYER_DRACULA)==BE);
            disposeDracView (dv);
       }while(0);
       do{
            printf("test double back3\n");
            char *trail = "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                          "GBO.... SNU.... HZA.... MNP.... DBE.... "
                          "GBO.... SNU.... HZA.... MNP.... DSZ.... "
                          "GBO.... SNU.... HZA.... MNP.... DD3.... ";
                
       
            DracView dv = newDracView (trail, messages);
            assert(whereIs (dv, PLAYER_LORD_GODALMING)==BO);
            assert(whereIs (dv, PLAYER_DR_SEWARD)==NU);
            assert(whereIs (dv, PLAYER_DRACULA)==ZA);
            assert(whereIs (dv, PLAYER_VAN_HELSING)==NP);
            assert(whereIs (dv, PLAYER_DRACULA)==BE);
            disposeDracView (dv);
       }while(0);
       do{
            printf("test double back4\n");
            char *trail = "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                          "GBO.... SNU.... HZA.... MNP.... DBE.... "
                          "GBO.... SNU.... HZA.... MNP.... DSZ.... "
                          "GBO.... SNU.... HZA.... MNP.... DD4.... ";
                
       
            DracView dv = newDracView (trail, messages);
            assert(whereIs (dv, PLAYER_LORD_GODALMING)==BO);
            assert(whereIs (dv, PLAYER_DR_SEWARD)==NU);
            assert(whereIs (dv, PLAYER_DRACULA)==ZA);
            assert(whereIs (dv, PLAYER_VAN_HELSING)==NP);
            assert(whereIs (dv, PLAYER_DRACULA)==SJ);
            disposeDracView (dv);
       }while(0);
       do{
            printf("test double back5\n");
            char *trail = "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                          "GBO.... SNU.... HZA.... MNP.... DBE.... "
                          "GBO.... SNU.... HZA.... MNP.... DSZ.... "
                          "GBO.... SNU.... HZA.... MNP.... DKL.... "
                          "GBO.... SNU.... HZA.... MNP.... DD5.... ";
       
            DracView dv = newDracView (trail, messages);
            assert(whereIs (dv, PLAYER_LORD_GODALMING)==BO);
            assert(whereIs (dv, PLAYER_DR_SEWARD)==NU);
            assert(whereIs (dv, PLAYER_DRACULA)==ZA);
            assert(whereIs (dv, PLAYER_VAN_HELSING)==NP);
            assert(whereIs (dv, PLAYER_DRACULA)==SJ);
            disposeDracView (dv);
       }while(0);
       
    }while(0);
    do{
        printf("test Dracula TP action\n");
        char *trail = "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                      "GNA.... SNU.... HZA.... MNP.... DBE.... "
                      "GLE.... SPR.... HMU.... MSZ.... DSJ.... "
                      "GLE.... SPR.... HMU.... MSZ.... DTP.... ";
       
            DracView dv = newDracView (trail, messages);
            assert(whereIs (dv, PLAYER_LORD_GODALMING)==LE);
            assert(whereIs (dv, PLAYER_DR_SEWARD)==PR);
            assert(whereIs (dv, PLAYER_DRACULA)==MU);
            assert(whereIs (dv, PLAYER_VAN_HELSING)==SZ);
            assert(whereIs (dv, PLAYER_DRACULA)==CD);
            disposeDracView (dv);
    }while(0);
    do{
        printf("test Dracula Vampire and trap action\n");
        do{
            int numV,numT;
            printf("test Dracula Vampire and trap action placed\n");
            char *trail = "GGE.... SGE.... HGE.... MGE.... DBD.V.. "
                       "GCF.... SST.... HZU.... MCA.... DZAT... ";
       
            DracView dv = newDracView (trail, messages);
            whatsThere (dv, BD, &numT, &numV);
            assert(numT == 1);
            assert(numV == 1);
            disposeDracView (dv);
        }while(0);
        do{
            printf("test Dracula Vampire and trap action left\n");
            do{
                printf("test vampire fund by hunter");
                char *trail =  "GGE.... SGE.... HGE.... MGE.... DBD.V.. "
                               "GCF.... SST.... HZU.... MCA.... DZA.... "
                               "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                               "GBO.... SNU.... HZA.... MNP.... DHI.... "
                               "GNA.... SPR.... HSZ.... MBI.... DBE.... "
                               "GNA.... SPR.... HBDV... MAS.... DBE.... ";
                             
                GameView gv1 = newGameView (trail, messages);
                whatsThere (dv, BD, &numT, &numV);
                assert(numT == 0);
                assert(numV == 0);
            }while(0);
            do{
                printf("test Vampire mature and left")
                char *trail =  "GGE.... SGE.... HGE.... MGE.... DBD.V.. "
                               "GCF.... SST.... HZU.... MCA.... DZA.... "
                               "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                               "GBO.... SNU.... HZA.... MNP.... DHI.... "
                               "GNA.... SPR.... HSZ.... MBI.... DBE.... "
                               "GLE.... SVI.... HJM.... MAS.... DBC..V. ";
                               
                             
                GameView gv1 = newGameView (trail, messages);
                whatsThere (dv, BD, &numT, &numV);
                assert(numT == 0);
                assert(numV == 0);
            
            
            }while(0);
        }while(0); 
        
    }while(0);
    
    
    printf("pass all action test\n");

}
