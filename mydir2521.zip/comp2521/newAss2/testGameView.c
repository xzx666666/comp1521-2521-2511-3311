////////////////////////////////////////////////////////////////////////
// COMP2521 18x1 ... the Fury of Dracula
// testGameView.c: test the GameView ADT
//
// As supplied, these are very simple tests.  You should write more!
// Don't forget to be rigorous and thorough while writing tests.
//
// 2014-07-01   v1.0    Team Dracula <cs2521@cse.unsw.edu.au>
// 2017-12-01   v1.1    Team Dracula <cs2521@cse.unsw.edu.au>

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "GameView.h"

void test(int arr[], int max){
    for(int tmp = 0; tmp < max; tmp++) printf("%s\n",idToName(arr[tmp]));
}
void testConnection();
void basicTests();
void someOther();
void testScore();
void testHealth();
//void testHu
int main (int argc, char *argv[])
{
        //basicTests();
        //testConnection();
        //someOther();
        testScore();
        testHealth();
        puts("passed all");

    return EXIT_SUCCESS;
}
/*
void someOther(){
    
    char *trail =
			"GLS.... SMR.... HCD.... MAM.... DSNV... "
			"GMA.... SCF.... HGA.... MCO.... DSRT... "
			"GSNT... SMR.... HCD.... MAM.... DMAT... "
			"GSRT... SCF.... HGA.... MBU.... DHIT... "
			"GMATTD. SCF.... HGA.... MBU....";

		PlayerMessage messages[24] = {"Going somewhere",""};
		GameView gv = newGameView (trail, messages);
        printf("%s\n",idToName(getLocation(gv, PLAYER_LORD_GODALMING)));
    
    
    char *trail =
			"GLS.... SMR.... HCD.... MAM.... DSNV... "
			"GMA.... SCF.... HGA.... MCO.... DSRT... "
			"GSNT... SMR.... HCD.... MAM.... DMAT... "
			"GSRT... SCF.... HGA.... MBU.... DHIT... "
			"GMATTD. SCF.... HGA.... MBU....";

		PlayerMessage messages[24] = {"Going somewhere",""};
		GameView gv = newGameView (trail, messages);
        printf("%s\n",idToName(getLocation(gv, PLAYER_DRACULA)));
    
    char *trail =
			"GLS.... SMR.... HCD.... MAM.... DSNV... "
			"GMA.... SCF.... HGA.... MCO.... DSRT... "
			"GSNT... SMR.... HCD.... MAM.... DMAT... "
			"GSRT... SCF.... HGA.... MBU.... DHIT... "
			"GMATTD. SCF.... HGA.... MBU.... DD1T... "
			"GZA.... SCF.... HGA....";

		PlayerMessage messages[28] = {"Going somewhere",""};
		GameView gv = newGameView (trail, messages);
        LocationID history[TRAIL_SIZE];
        getHistory(gv,PLAYER_LORD_GODALMING,history);
        for(int tmp = 0; tmp < TRAIL_SIZE; tmp++)
            printf("%s\n",idToName(history[tmp]));
            //printf("%d\n",history[tmp]);
            
        //printf("%s\n".idToName())
    disposeGameView(gv);
}
*/

void testConnection(){
    char *trail = "";
    PlayerMessage messages[] = {};
    GameView gv = newGameView (trail, messages);
    do {//test other connections
            puts ("Checking hamburg rail connections");
            int size, *edges = connectedLocations (gv, &size,
                HAMBURG, PLAYER_VAN_HELSING, 0,
                false, true, false);
            assert (size == 4);
            
            assert (edges[0] == HAMBURG);
            assert (edges[1] == BERLIN);
            assert (edges[2] == LEIPZIG || edges[2] == PRAGUE);
            assert (edges[3] == LEIPZIG || edges[3] == PRAGUE);
            puts("passed");
            free (edges);
        } while (0);


        do {//test other connections
            puts ("Checking salonica rail connections");
            int size, *edges = connectedLocations (gv, &size,
                SALONICA, PLAYER_MINA_HARKER, 4,
                true , true, false);
            assert (size == 6);
            assert (edges[0] == SALONICA);
            assert (edges[1] == VALONA);
            assert (edges[2] == SOFIA);
            assert (edges[3] == VARNA);
            assert (edges[4] == BELGRADE);
            assert (edges[5] == SZEGED);
            puts("passed");
            free (edges);
        } while (0);

        do {//test other connections
            puts ("Checking salonica rail connections");
            puts ("Check if there is any same location appended on the list");
            int size, *edges = connectedLocations (gv, &size,
                LISBON, PLAYER_MINA_HARKER, 4,
                true , true, true);
            assert(size == 9);
            assert (edges[0] == LISBON);
            assert (edges[1] == ATLANTIC_OCEAN);
            assert (edges[2] == SANTANDER);
            assert (edges[3] == MADRID);
            assert (edges[4] == CADIZ);
            assert (edges[5] == SARAGOSSA);
            assert (edges[6] == ALICANTE);
            assert (edges[7] == BORDEAUX);
            assert (edges[8] == BARCELONA);
            puts("passed");
            free (edges);
        } while (0);

        do {//test other connections
            puts ("Checking Dracula connection");
            int size, *edges = connectedLocations (gv, &size,
                LISBON, PLAYER_DRACULA, 4,
                true , true, true);
            assert (size == 5);
            assert (edges[0] == LISBON);
            assert (edges[1] == ATLANTIC_OCEAN);
            assert (edges[2] == SANTANDER);
            assert (edges[3] == MADRID);
            assert (edges[4] == CADIZ);
            puts("passed");
            free (edges);
        } while (0);
    disposeGameView(gv);
}


/*void basicTests(){
    do {////////////////////////////////////////////////////////////////
        puts ("Test basic empty initialisation");

        char *trail = "";
        PlayerMessage messages[] = {};
        GameView gv = newGameView (trail, messages);

        assert (getCurrentPlayer (gv) == PLAYER_LORD_GODALMING);
        assert (getRound (gv) == 0);
        assert (getHealth (gv, PLAYER_DR_SEWARD) ==
                GAME_START_HUNTER_LIFE_POINTS);
        assert (getHealth (gv, PLAYER_DRACULA) ==
                GAME_START_BLOOD_POINTS);
        assert (getScore (gv) == GAME_START_SCORE);
        assert (getLocation (gv, PLAYER_LORD_GODALMING) ==
                UNKNOWN_LOCATION);

        puts ("passed");
        disposeGameView (gv);
    } while (0);



    do {////////////////////////////////////////////////////////////////
        puts ("Test for Dracula trail and basic functions");

        char *trail =
            "GST.... SAO.... HZU.... MBB.... DC?....";
        PlayerMessage messages[] = {
            "Hello", "Rubbish", "Stuff", "", "Mwahahah"};
        GameView gv = newGameView (trail, messages);
        assert (getCurrentPlayer (gv) == PLAYER_LORD_GODALMING);
        assert (getRound (gv) == 1);
        assert (getLocation (gv, PLAYER_LORD_GODALMING) == STRASBOURG);
        assert (getLocation (gv, PLAYER_DR_SEWARD) == ATLANTIC_OCEAN);
        assert (getLocation (gv, PLAYER_VAN_HELSING) == ZURICH);
        assert (getLocation (gv, PLAYER_MINA_HARKER) == BAY_OF_BISCAY);
        assert (getLocation (gv, PLAYER_DRACULA) == CITY_UNKNOWN);
        assert (getHealth (gv, PLAYER_DRACULA) ==
                GAME_START_BLOOD_POINTS);

        puts ("passed");
        disposeGameView (gv);
    } while (0);


    do {////////////////////////////////////////////////////////////////
        puts ("Test for encountering Dracula and hunter history");

        char *trail =
            "GST.... SAO.... HCD.... MAO.... DGE.... "
            "GGED...";
        PlayerMessage messages[] = {
            "Hello", "Rubbish",  "Stuff", "", "Mwahahah",
            "Aha!"};
        GameView gv = newGameView (trail, messages);

        assert (getLocation (gv, PLAYER_DRACULA) == GENEVA);
        assert (getHealth (gv, PLAYER_LORD_GODALMING) == 5);
        assert (getHealth (gv, PLAYER_DRACULA) == 30);
        assert (getLocation (gv, PLAYER_LORD_GODALMING) == GENEVA);

        LocationID history[TRAIL_SIZE];
        getHistory (gv, PLAYER_DRACULA, history);
        assert (history[0] == GENEVA);
        assert (history[1] == UNKNOWN_LOCATION);

        getHistory (gv, PLAYER_LORD_GODALMING, history);
        assert (history[0] == GENEVA);
        assert (history[1] == STRASBOURG);
        assert (history[2] == UNKNOWN_LOCATION);

        getHistory (gv, PLAYER_DR_SEWARD, history);
        assert (history[0] == ATLANTIC_OCEAN);
        assert (history[1] == UNKNOWN_LOCATION);

        puts ("passed");
        disposeGameView (gv);
    } while (0);


    do {////////////////////////////////////////////////////////////////
        puts ("Test for Dracula doubling back at sea, "
              "and losing blood points (Hunter View)");

        char *trail =
            "GGE.... SGE.... HGE.... MGE.... DS?.... "
            "GST.... SST.... HST.... MST.... DD1....";//double back 1 for dracula
        PlayerMessage messages[] = {
            "Hello", "Rubbish", "Stuff", "", "Mwahahah",
            "Aha!", "", "", "", "Back I go"};
        GameView gv = newGameView (trail, messages);

        getLocation (gv, PLAYER_DRACULA);
        assert (getCurrentPlayer (gv) == 0);
        assert (getHealth (gv, PLAYER_DRACULA) ==
                GAME_START_BLOOD_POINTS - 4);
        assert (getLocation (gv, PLAYER_DRACULA) == DOUBLE_BACK_1);
        
        LocationID history[TRAIL_SIZE];
        getHistory (gv, PLAYER_DRACULA, history);
        assert (history[0] == DOUBLE_BACK_1);
        assert (history[1] == SEA_UNKNOWN);

        puts ("passed");
        disposeGameView (gv);
    } while (0);


    do {////////////////////////////////////////////////////////////////
        puts ("Test for Dracula doubling back at sea, "
              "and losing blood points (Drac View)");

        char *trail =
            "GGE.... SGE.... HGE.... MGE.... DEC.... "
            "GST.... SST.... HST.... MST.... DD1....";
        PlayerMessage messages[] = {
            "Hello", "Rubbish", "Stuff", "", "Mwahahah",
            "Aha!", "", "", "", "Back I go"};
        GameView gv = newGameView (trail, messages);

        assert (getCurrentPlayer (gv) == 0);
        assert (getHealth (gv, PLAYER_DRACULA) ==
                GAME_START_BLOOD_POINTS - 4);
        assert (getLocation (gv, PLAYER_DRACULA) == DOUBLE_BACK_1);

        LocationID history[TRAIL_SIZE];
       
        assert (history[0] == DOUBLE_BACK_1);
        assert (history[1] == ENGLISH_CHANNEL);

        puts ("passed");
        disposeGameView (gv);
    } while (0);

    do {////////////////////////////////////////////////////////////////
        puts ("Test for connections");
        char *trail = "";
        PlayerMessage messages[] = {};
        GameView gv = newGameView (trail, messages);

        do {
            puts ("Checking Galatz road connections");
            int size, *edges = connectedLocations (gv, &size,GALATZ, PLAYER_LORD_GODALMING, 0, true, false, false);
            
            
            bool seen[NUM_MAP_LOCATIONS] = {false};
            for (int i = 0; i < size; i++){
                seen[edges[i]] = true;
            }
            assert (size == 5);
            assert (seen[GALATZ]);
            assert (seen[CONSTANTA]);
            assert (seen[BUCHAREST]);
            assert (seen[KLAUSENBURG]);
            assert (seen[CASTLE_DRACULA]);
            puts("passed");
            free (edges);
        } while (0);

        do {
            puts ("Checking Ionian Sea sea connections");
            int size, *edges = connectedLocations (gv, &size,
                IONIAN_SEA, PLAYER_LORD_GODALMING, 0,
                false, false, true);

            bool seen[NUM_MAP_LOCATIONS] = {false};
            for (int i = 0; i < size; i++)
                seen[edges[i]] = true;

            assert (size == 7);
            assert (seen[IONIAN_SEA]);
            assert (seen[BLACK_SEA]);
            assert (seen[ADRIATIC_SEA]);
            assert (seen[TYRRHENIAN_SEA]);
            assert (seen[ATHENS]);
            assert (seen[VALONA]);
            assert (seen[SALONICA]);
            puts("passed");
            free (edges);
        } while (0);

        do {
            puts ("Checking Athens rail connections (none)");
            int size, *edges = connectedLocations (gv, &size,
                ATHENS, PLAYER_LORD_GODALMING, 0,
                false, true, false);
        
            assert (size == 1);
            assert (edges[0] == ATHENS);
            puts("passed");
            free (edges);
        } while (0);
        disposeGameView(gv);
    }while(0);
}*/
void testScore(){
    PlayerMessage messages[] = { "Hello", "Rubbish", "Stuff", "", "Mwahahah"};
    do{
        
        printf("test Dracula score around\n");
        int i=0;
        char *trail[4] = {"GMA.... SLS.... HSN.... MSR.... DVI.... ",
                          "GZU.... SBU.... HCF.... MTO.... DSZ.... ",
                          "GBC.... SBS.... HVR.... MSO.... DVR.... ",
                          "GFL.... SAS.... HZA.... MPR.... DFR.... ",
                          };    
        while(i<4) {                
            GameView gv = newGameView (trail[i], messages);
            assert(getScore (gv)==GAME_START_SCORE-SCORE_LOSS_DRACULA_TURN);
            assert(getHealth (gv,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS);
            
            disposeGameView(gv);
            i++;
        
        printf("passed\n");
           
        }while(0);
        
        
        do{
            printf("test the Vampire Nature and hunter find Vampire before Mature\n");
                         
            char *trail1 = "GGE.... SGE.... HGE.... MGE.... DBD.V.. "
                           "GCF.... SST.... HZU.... MCA.... DZA.... "
                           "GCF.... SFR.... HMU.... MTS.... DSJ.... "
                           "GBO.... SNU.... HZA.... MNP.... DHI.... "
                           "GNA.... SPR.... HSZ.... MBI.... DBE.... "
                           "GLE.... SVI.... HJM.... MAS.... DBC..V. ";//VAMPIRE NATURE
                         
            GameView gv1 = newGameView (trail1, messages);
            printf("score %d   %d\n",getScore (gv1),getRound (gv1));
            //assert(getScore (gv1) == GAME_START_SCORE-getRound (gv1)*SCORE_LOSS_DRACULA_TURN-SCORE_LOSS_VAMPIRE_MATURES);
            assert(getHealth (gv1,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv1,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv1,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
            
            printf("health %d\n",getHealth (gv1,PLAYER_MINA_HARKER ));
            //assert(getHealth (gv1,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS);
            printf("health D %d\n",getHealth (gv1,PLAYER_DRACULA ));
            //assert(getHealth (gv1,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS);
            disposeGameView(gv1);
            
             char *trail2 = "GGE.... SGE.... HGE.... MGE.... DBD.V.. "
                            "GCF.... SST.... HZU.... MCA.... DZA.... "
                            "GCF.... SFR.... HMU.... MTS.... DJM.... "
                            "GBO.... SNU.... HZA.... MNP.... DSJ.... "
                            "GNA.... SPR.... HSZ.... MBI.... DBE.... "
                            "GLE.... SVI.... HBDV... MAS.... DBC.... ";//HUNTER FUND BEFORE VAMPIRE MATURE
             
            GameView gv2 = newGameView (trail2, messages);
            
            assert(getScore (gv2) == GAME_START_SCORE-getRound(gv2)*SCORE_LOSS_DRACULA_TURN);
            //assert(getHealth (gv2,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv2,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
            //assert(getHealth (gv2,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS);
            //assert(getHealth (gv2,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS);
            disposeGameView(gv2);
            printf("passed\n");
        }while(0);
        do{
            printf("test hunter go to hosptial\n");
            char *trail_ho = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                             "GMA.... SCF.... HGA.... MCO.... DSRT... "
                             "GSNT... SMR.... HCD.... MAM.... DMAT... "
                             "GSRT... SCF.... HGA.... MBU.... DHIT... "
                             "GMATTD. SCF.... HGA.... MBU.... DHIT... ";
            
            GameView gv = newGameView (trail_ho, messages);  
            //assert(getScore (gv) == GAME_START_SCORE-getRound(gv)*SCORE_LOSS_DRACULA_TURN-SCORE_LOSS_HUNTER_HOSPITAL);
            //assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS-4*LIFE_LOSS_TRAP_ENCOUNTER-LIFE_LOSS_DRACULA_ENCOUNTER );
            assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS-LIFE_GAIN_CASTLE_DRACULA); 
            //assert(getLocation (gv, PLAYER_DR_SEWARD) == JM);
            disposeGameView(gv);
            printf("passed\n");
            
        }while(0);
    
    }while(0);

}
void testHealth(){
    PlayerMessage messages[] = { "Hello", "Rubbish", "Stuff", "", "Mwahahah"};
    do{
        printf("start hunter health test\n");
        
        do{
            printf("test hunter loose health \n");
            char *trail = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                          "GLS.... SMR.... HCD.... MSNT... DSR.... ";
            
            GameView gv = newGameView (trail, messages);  
            assert(getHealth (gv,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS-LIFE_LOSS_TRAP_ENCOUNTER);
            assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS);
            disposeGameView(gv);
        }while(0);
        do{
            printf("test hunter get health back\n");
            char *trail = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                          "GLS.... SMR.... HCD.... MSNT... DSR.... "
                          "GMA.... SGE.... HCA.... MSN... DBOT... ";
            
            GameView gv = newGameView (trail, messages);
             
            assert(getHealth (gv,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS-LIFE_LOSS_TRAP_ENCOUNTER);
            assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS);
            disposeGameView(gv); 
            
        }while(0);
        do{
            printf("test hunter loose full health\n");
            char *trail = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                          "GLS.... SMR.... HCD.... MSNT... DSR.... "
                          "GMA.... SGE.... HCA.... MSN.... DBOT... "
                          "GSRD... SCF.... HGR.... MBOT... DSRT... "
                          "GBATD.. SCF.... HGR.... MBO.... DBA.... " ;
            GameView gv = newGameView (trail, messages);
            assert(getHealth (gv,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS-2*LIFE_LOSS_DRACULA_ENCOUNTER-LIFE_LOSS_TRAP_ENCOUNTER);
            assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS-2*LIFE_LOSS_TRAP_ENCOUNTER);
            assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS-2*LIFE_LOSS_HUNTER_ENCOUNTER);
            disposeGameView(gv);      
        }while(0);
        do{
            printf("test hunter go to hosptial and get full health\n");
            char *trail = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                          "GLS.... SMR.... HCD.... MSNT... DSR.... "
                          "GMA.... SGE.... HCA.... MSN.... DBOT... "
                          "GSRD... SCF.... HGR.... MBOT... DSRT... "
                          "GBATD.. SCF.... HGR.... MBO.... DBA.... " 
                          "GJM.... SNA.... HAL.... MTO.... DSR.... "
                          "GZA.... SNA.... HAL.... MTO.... DAL.... ";
            GameView gv = newGameView (trail, messages);
            assert(getHealth (gv,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
            assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS-2*LIFE_LOSS_TRAP_ENCOUNTER);
            assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS-2*LIFE_LOSS_HUNTER_ENCOUNTER);
            disposeGameView(gv); 
        printf("pass all hunter health\n");
        }while(0);
        do{
            printf("start Dracula health test");
           
            do{
                printf("test Dracula loose life in sea\n");
                char *trail = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                              "GLS.... SMR.... HCD.... MSNT... DSR.... "
                              "GMA.... SGE.... HCA.... MSN.... DBOT... "
                              "GSRD... SCF.... HGR.... MBOT... DSRT... "
                              "GBATD.. SCF.... HGR.... MBO.... DBA.... " 
                              "GJM.... SNA.... HAL.... MTO.... DSR.... "
                              "GMU.... SLE.... HMS.... MCF.... DMS.... ";
                          
                GameView gv = newGameView (trail, messages);
                assert(getHealth (gv,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS-2*LIFE_LOSS_TRAP_ENCOUNTER);
                assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS-2*LIFE_LOSS_HUNTER_ENCOUNTER-LIFE_LOSS_SEA);
                disposeGameView(gv);
            }while(0);
            do{
                printf("test Dracula loose life meet hunter\n");
                char *trail = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                              "GLS.... SMR.... HCD.... MSNT... DSR.... "
                              "GMA.... SGE.... HCA.... MSN.... DBOT... "
                              "GSRD... SCF.... HGR.... MBOT... DSRT... "
                              "GBATD.. SCF.... HGR.... MBO.... DBA.... " 
                              "GJM.... SNA.... HAL.... MTO.... DSR.... "
                              "GMU.... SLE.... HMS.... MCT.... DMS.... "
                              "GNU.... SBU.... HCAD... MPA.... DCA.... ";
                              
                          
                GameView gv = newGameView (trail, messages);
                assert(getHealth (gv,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS-LIFE_LOSS_DRACULA_ENCOUNTER);
                assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS-2*LIFE_LOSS_TRAP_ENCOUNTER);
                assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS-3*LIFE_LOSS_HUNTER_ENCOUNTER-LIFE_LOSS_SEA);
                disposeGameView(gv);
            }while(0);
            do{
                printf("test Dracula get health\n");
                char *trail = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                              "GLS.... SMR.... HCD.... MSNT... DSR.... "
                              "GMA.... SGE.... HCA.... MSN.... DBOT... "
                              "GSRD... SCF.... HGR.... MBOT... DSRT... "
                              "GBATD.. SCF.... HGR.... MBO.... DBA.... " 
                              "GJM.... SNA.... HAL.... MTO.... DSR.... "
                              "GMU.... SLE.... HMS.... MCT.... DMS.... "
                              "GNU.... SBU.... HCAD... MPA.... DCA.... "
                              "GVI.... SST.... HTS.... MST.... DCATP.. ";
                              
                          
                GameView gv = newGameView (trail, messages);
                assert(getHealth (gv,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS-LIFE_LOSS_DRACULA_ENCOUNTER);
                assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS-2*LIFE_LOSS_TRAP_ENCOUNTER);
                assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS-2*LIFE_LOSS_HUNTER_ENCOUNTER-LIFE_LOSS_SEA);
                disposeGameView(gv);
            }while(0);
            do{
                printf("test Dracula loose full ");
                char *trail = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                              "GLS.... SMR.... HCD.... MSNT... DSR.... "
                              "GMA.... SGE.... HCA.... MSN.... DBOT... "
                              "GSRD... SCF.... HGR.... MBOT... DSRT... "
                              "GBATD.. SCF.... HGR.... MBO.... DBA.... " 
                              "GJM.... SNA.... HAL.... MTO.... DSR.... "
                              "GMU.... SLE.... HMS.... MCT.... DMS.... "
                              "GNU.... SBU.... HCAD... MPA.... DCA.... "
                              "GVI.... SST.... HTS.... MST.... DCATP.. "
                              "GVI.... SST.... HTS.... MST.... DGA.... "
                              "GVI.... SST.... HTS.... MST.... DCN.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... "
                              "GVI.... SST.... HTS.... MST.... DBS.... ";
                              
                          
                GameView gv = newGameView (trail, messages);
                assert(getHealth (gv,PLAYER_LORD_GODALMING ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_DR_SEWARD ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_VAN_HELSING ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_MINA_HARKER ) == GAME_START_HUNTER_LIFE_POINTS);
                assert(getHealth (gv,PLAYER_DRACULA ) == GAME_START_BLOOD_POINTS-2*LIFE_LOSS_HUNTER_ENCOUNTER-10*LIFE_LOSS_SEA);
                disposeGameView(gv);
            }while(0);
        
        }while(0);
        
    
    }while(0);




}
