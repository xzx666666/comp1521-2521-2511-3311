////////////////////////////////////////////////////////////////////////
// COMP2521 18x1 ... the Fury of Dracula
// testHunterView.c: test the HunterView ADT
//
// As supplied, these are very simple tests.  You should write more!
// Don't forget to be rigorous and thorough while writing tests.
//
// 2014-07-01   v1.0    Team Dracula <cs2521@cse.unsw.edu.au>
// 2017-12-02   v1.1    Team Dracula <cs2521@cse.unsw.edu.au>

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "HunterView.h"
void testHistory();
int main (int argc, char *argv[])
{
    testHistory();
    return EXIT_SUCCESS;
}
void testHistory(){
    PlayerMessage messages[] = {"Hello", "Rubbish", "Stuff", "", "Mwahahah" };
    printf("hunter get back to hosptial and check history\n");
    do{//test the history diff between get back hospital and not get back to history 
        int history[6],i;
        char *trail_ho = "GLS.... SMR.... HCD.... MAM.... DSNT... "
                         "GMA.... SCF.... HGA.... MCO.... DSRT... "
                         "GSNT... SMR.... HCD.... MAM.... DMAT... "
                         "GSRT... SCF.... HGA.... MBU.... DHIT... "
                         "GMATTD. SCF.... HGA.... MBU.... DHIT... "
                         "GJM.... SCF.... HGA.... MBU.... DHI.... "
                         "GSJ.... SCF.... HGA.... MBU.... DHI.... ";
        
        HunterView hv = newHunterView (trail, messages);
        giveMeTheTrail ( hv, PLAYER_LORD_GODALMING, history);
        for(i=0;i<6;i++){
            switch(i){
                case 0: assert(history[i]==LISBON);
                case 1: assert(history[i]==MADRID);
                case 2: assert(history[i]==SANTANDER);
                case 3: assert(history[i]==SARAGOSSA);
                case 4: assert(history[i]==MADRID);
                case 5: assert(history[i]==SARAJEVO);
                
            }
        }
    }while(0);
    do{
        int history[6],i;
        char *trail_ho = "GLS.... SMR.... HCD.... MAM.... DSN.... "
                         "GMA.... SCF.... HGA.... MCO.... DSR.... "
                         "GSN.... SMR.... HCD.... MAM.... DMA.... "
                         "GSR.... SCF.... HGA.... MBU.... DHI.... "
                         "GMA.... SCF.... HGA.... MBU.... DHI.... "
                         "GGR.... SCF.... HGA.... MBU.... DHI.... ";
        
        HunterView hv = newHunterView (trail, messages);
        giveMeTheTrail ( hv, PLAYER_LORD_GODALMING, history);
        for(i=0;i<6;i++){
            switch(i){
                case 0: assert(history[i]==LISBON);
                case 1: assert(history[i]==MADRID);
                case 2: assert(history[i]==SANTANDER);
                case 3: assert(history[i]==SARAGOSSA);
                case 4: assert(history[i]==MADRID);
                case 5: assert(history[i]==GRANADA);
                
            }
        }
    }while(0);


}
