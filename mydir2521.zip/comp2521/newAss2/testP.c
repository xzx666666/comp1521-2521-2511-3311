#include <stdio.h>

int main(){
    int i = 0;
    int j = 0;
    int var1,var2;
    for(i = 0; i < 10; i++){
        var1 = var2 = 0;
        for(j = 0; j < 5; j++){
            if(j == 3 && var1 == 0){
                event;
                var1 = 1;
            }
            if(j == 2 && var2 == 0){
                event;
                var2 = 1;
            }
        }
        for(j == 0; j < 5; j++){
            if(j == 2) break;
        }
    }
    printf("i %d\n",i);
    return 0;
}