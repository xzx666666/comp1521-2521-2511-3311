#define MAX_PLAYERS 5
#define LOCATION 1
#define TRAP 3
#define STR_LENGTH 40
#define UNIT_LENGTH 8
#define MAX_HISTORY 6
#define DRA_LOCATION LOCATION * (PLAYER_DRACULA) * UNIT_LENGTH + 1
#define LOR_LOCATION LOCATION * (PLAYER_LORD_GODALMING) * UNIT_LENGTH + 1
#define DR_LOCATION LOCATION * (PLAYER_DR_SEWARD) * UNIT_LENGTH + 1
#define VAN_LOCATION LOCATION * (PLAYER_VAN_HELSING) * UNIT_LENGTH + 1
#define MINA_LOCATION LOCATION * (PLAYER_MINA_HARKER) * UNIT_LENGTH + 1

#define HUN_TRAP 3

#define LOR_TRAP HUN_TRAP
#define DR_TRAP HUN_TRAP + UNIT_LENGTH * PLAYER_DR_SEWARD
#define VAN_TRAP HUN_TRAP + UNIT_LENGTH * PLAYER_VAN_HELSING
#define MINA_TRAP HUN_TRAP + UNIT_LENGTH * PLAYER_MINA_HARKER

#define DRAC_VAMPIRE DRA_LOCATION + 4

#include "Game.h"
#include "Globals.h"

struct _playerView{
    int health;
    LocationID location;
    int loc_history[MAX_HISTORY];
    int *availableLoc;
};

typedef struct _playerView * pView;

int strToId(char *c);
void putLocation(char *loc, LocationID *location, char *start);
void moveArray(int arr[], int new);
int isBeenThere(LocationID loc[], int currLoc, int max, int now);

