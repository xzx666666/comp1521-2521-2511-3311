#include <assert.h>
#include <err.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sysexits.h>
#include <string.h>
#include <stdio.h>

#include "Game.h"
#include "DracView.h"
#include "Globals.h"

//#include "update.h"

#include "updateDrac.h"

void playerAlloc_Drac(DracView new){
    int i = 0;
    for(i = 0; i < MAX_PLAYERS; i++)
        new->players[i] = malloc(sizeof(struct _playerView));
}

void init_Drac(DracView n){
    n->score = 366;
    n->round = 0;
    n->currentPl = PLAYER_DRACULA;
    
    int i = 0;
    int j = 0;
    
    for(i = 0; i < MAX_PLAYERS; i++){
        n->players[i]->health = 9;
        n->players[i]->location = UNKNOWN_LOCATION;
        for(j = 0; j < MAX_HISTORY; j++){
            n->players[i]->loc_history[j] = -1;
        }
    }
    n->players[MAX_PLAYERS-1]->health = 40;
}

int strToHunterHarm_Drac(DracView n,char c){
    switch(c){
        case 'T': return 2;
        case 'V': return 0;
        case 'D': {
            n->players[PLAYER_DRACULA]->health -= 10;
            return 4;
        }
        case '.': return 0;
    }
    return 0;
}

void hunterTrap_Drac(DracView v, char *start, int Player){
    char *move = start;
    int i = 0, lossPoints = 0;
    for(i = 0; i < 4; i++){
        lossPoints = lossPoints + strToHunterHarm_Drac(v,*move);
        move++;
    }
    v->players[Player]->health -= lossPoints;
    if(v->players[Player]->health <= 0){
        v->players[Player]->location = abbrevToID("JM"); //move to the Hospital
    }
}

void lossHealth_Drac(DracView n, int Player, char c){
    n->players[Player]->health -= strToHunterHarm_Drac(n,c);
}

void updatePlayerLocation_Drac(DracView new, int PlayerID, char *loc, char *start){
    //figure out recent move and double back
    int *player_LOC = &new->players[PlayerID]->location;
    if(*player_LOC == ST_JOSEPH_AND_ST_MARYS) new->players[PlayerID]->health = 9;
    putLocation(loc,player_LOC,start);
    if(PlayerID == PLAYER_DRACULA){
        if(*player_LOC == HIDE){
            *player_LOC = new->players[PLAYER_DRACULA]->loc_history[0];
        }
        if(loc[0] == 'D' && loc[1] >= '1' && loc[1] <= '5'){
            *player_LOC = new->players[PLAYER_DRACULA]->loc_history[loc[1] - '1'];
        }
        if(*player_LOC == TELEPORT){
            *player_LOC = CASTLE_DRACULA;
        }
    }
    moveArray(new->players[PlayerID]->loc_history,*player_LOC);
}

void doubleBack_Drac(DracView n, int back){
    //id to abbrev
    int history = n->players[PLAYER_DRACULA]->loc_history[back];
    if(validPlace(history)){
        if(idToType(history) == SEA)
            n->players[PLAYER_DRACULA]->health -= 2;
    }
    else if(!strcmp(idToAbbrev(history),"S?"))
        n->players[PLAYER_DRACULA]->health -= 2;
}

void seaAction_Drac(DracView new, char* loc, char *start){
    if(strToId(loc) == SEA_UNKNOWN || strToId(loc) == SEA)
        new->players[PLAYER_DRACULA]->health -= 2;

    else if(abbrevToID(loc) != -1){
        if(idToType(abbrevToID(loc)) == SEA)
            new->players[PLAYER_DRACULA]->health -= 2;
    }

    if(*start == 'D' && *(start + 1) >= '1' && *(start + 1) <= '5'){
        doubleBack_Drac(new,*(start+1)-'0');
    }
}

void init_DracTraps(void){
    int i = 0;
    for(i = 0; i < NUM_MAP_LOCATIONS; i++){
        all_traps[i] = malloc(sizeof(struct dracTraps));
        all_traps[i]->numVamps = 0;
        all_traps[i]->numTraps = 0;
    }
}

void init_LastMove(){
    for(int i = 0; i < NUM_PLAYERS; i++){
        playersLastMove[i] = malloc(sizeof(struct lastMove));
        playersLastMove[i]->start = UNKNOWN_LOCATION;
        playersLastMove[i]->end = UNKNOWN_LOCATION;
    }    
}

void updateLastMove(int player, LocationID newLocation){
    playersLastMove[player]->start = playersLastMove[player]->end;
    playersLastMove[player]->end = newLocation;
}

void updateDracTrap(DracView dv, char *loc, char *start){
    int currLoc;
    if(*start == 'D' && *(start + 1) >= '1' && *(start + 1) <= '5'){
        currLoc = dv->players[PLAYER_DRACULA]->loc_history[*(start+1) - '0'];
    }
    if(!strcmp(loc,"HI")){
        currLoc = dv->players[PLAYER_DRACULA]->loc_history[1];
    }
    if(!strcmp(loc,"TP")){
        currLoc = CASTLE_DRACULA;
    }
    else if(abbrevToID(loc) != -1){
        currLoc = abbrevToID(loc);
    }
    if(*(start+2) == 'V') all_traps[currLoc]->numVamps++;
    if(*(start+2) == 'T') all_traps[currLoc]->numTraps++;
    if(*(start+3) == 'V') all_traps[currLoc]->numVamps++;
    if(*(start+3) == 'T') all_traps[currLoc]->numTraps++;
}


