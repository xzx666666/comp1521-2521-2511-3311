#include "Game.h"
#include "Globals.h"
#include "DracView.h"
#include "update.h"

struct dracView{
    int score;
    int round;
    int currentPl;
    pView players[MAX_PLAYERS];
};

struct lastMove{
    int start;
    int end;
};

struct dracTraps{
    int numVamps;
    int numTraps;
};

typedef struct lastMove * lM;
typedef struct dracTraps * dT;
dT all_traps[NUM_MAP_LOCATIONS];
lM playersLastMove[NUM_PLAYERS];

void playerAlloc_Drac(DracView new);
void init_Drac(DracView n);
int strToHunterHarm_Drac(DracView n,char c);
void hunterTrap_Drac(DracView v, char *start, int Player);
void lossHealth_Drac(DracView n, int Player, char c);
void updatePlayerLocation_Drac(DracView new, int PlayerID, char *loc, char *start);
void doubleBack_Drac(DracView n, int back);
void seaAction_Drac(DracView new, char* loc, char *start);

void init_DracTraps(void);
void init_LastMove();
void updateLastMove(int player, LocationID newLocation);
void updateDracTrap(DracView dv, char *loc, char *start);
void disposeLastMove();
void disposeTrap();

