#include "Game.h"
#include "GameView.h"
#include "Globals.h"
#include "update.h"

struct gameView {
    int score;
    int round;
    int currentPl;
    pView players[MAX_PLAYERS];
};

void playerAlloc(GameView new);
void init(GameView n);
int strToHunterHarm(GameView n,char c);
void hunterTrap(GameView v, char *start, int Player);
void lossHealth(GameView n, int Player, char c);
void updatePlayerLocation(GameView new, int PlayerID, char *loc, char *start);
void doubleBack(GameView n, int back);
void seaAction(GameView new, char* loc, char *start);

