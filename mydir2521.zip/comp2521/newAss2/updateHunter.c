#include <assert.h>
#include <err.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sysexits.h>
#include <string.h>
#include <stdio.h>

/*
#include "Game.h"
#include "HunterView.h"
#include "Globals.h"

#include "update.h"
*/

void playerAlloc_Hunt(HunterView new){
    int i = 0;
    for(i = 0; i < MAX_PLAYERS; i++)
        new->players[i] = malloc(sizeof(struct _playerView));
}

void init_Hunt(HunterView n){
    n->score = 366;
    n->round = 0;
    n->currentPl = PLAYER_LORD_GODALMING;
    
    int i = 0;
    int j = 0;
    
    for(i = 0; i < MAX_PLAYERS; i++){
        n->players[i]->health = 9;
        n->players[i]->location = UNKNOWN_LOCATION;
        for(j = 0; j < MAX_HISTORY; j++){
            n->players[i]->loc_history[j] = -1;
        }
    }
    n->players[MAX_PLAYERS-1]->health = 40;
}

int strToHunterHarm_Hunt(HunterView n,char c){
    switch(c){
        case 'T': return 2;
        case 'V': return 0;
        case 'D': {
            n->players[PLAYER_DRACULA]->health -= 10;
            return 4;
        }
        case '.': return 0;
    }
    return 0;
}

void hunterTrap_Hunt(HunterView v, char *start, int Player){
    char *move = start;
    int i = 0;
    int lossPoints = 0;
    for(i = 0; i < 4; i++){
        lossPoints = lossPoints + strToHunterHarm_Hunt(v,*move);
        move++;
    }
    v->players[Player]->health -= lossPoints;
    if(v->players[Player]->health <= 0){
        v->players[Player]->location = abbrevToID("JM"); //move to the Hospital
        v->players[Player]->health = 9;
    }
}

void lossHealth_Hunt(HunterView n, int Player, char c){
    n->players[Player]->health -= strToHunterHarm_Hunt(n,c);
}

void updatePlayerLocation_Hunt(HunterView new, int PlayerID, char *loc, char *start){
    //figure out recent move and double back
    int *player_LOC = &new->players[PlayerID]->location;
    putLocation(loc,player_LOC,start);
    if(PlayerID == PLAYER_DRACULA){
        if(*player_LOC == HIDE){
            *player_LOC = new->players[PLAYER_DRACULA]->loc_history[0];
        }
        if(loc[0] == 'D' && loc[1] >= '1' && loc[1] <= '5'){
            *player_LOC = new->players[PLAYER_DRACULA]->loc_history[loc[1] - '1'];
        }
        if(*player_LOC == TELEPORT){
            *player_LOC = CASTLE_DRACULA;
        }
    }
    moveArray(new->players[PlayerID]->loc_history,*player_LOC);
}

void doubleBack_Hunt(HunterView n, int back){
    //id to abbrev
    int history = n->players[PLAYER_DRACULA]->loc_history[back];
    if(validPlace(history)){
        if(idToType(history) == SEA)
            n->players[PLAYER_DRACULA]->health -= 2;
    }
    else if(!strcmp(idToAbbrev(history),"S?"))
        n->players[PLAYER_DRACULA]->health -= 2;
}

void seaAction_Hunt(HunterView new, char* loc, char *start){
    if(strToId(loc) == SEA_UNKNOWN || strToId(loc) == SEA)
        new->players[PLAYER_DRACULA]->health -= 2;

    else if(abbrevToID(loc) != -1){
        if(idToType(abbrevToID(loc)) == SEA)
            new->players[PLAYER_DRACULA]->health -= 2;
    }

    if(*start == 'D' && *(start + 1) >= '1' && *(start + 1) <= '5'){
        doubleBack_Hunt(new,*(start+1)-'0');
    }
}


