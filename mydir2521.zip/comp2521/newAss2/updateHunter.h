#include "Game.h"
#include "HunterView.h"
#include "Globals.h"
#include "update.h"

struct hunterView{
    int score;
    int round;
    int currentPl;
    pView players[MAX_PLAYERS];
};

