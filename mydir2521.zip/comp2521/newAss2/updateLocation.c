#include <assert.h>
#include <err.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sysexits.h>
#include <string.h>
#include <stdio.h>

#include "Game.h"
#include "GameView.h"
#include "Globals.h"

#include "update.h"

int strToId(char *c){
    if(!strcmp(c,"C?")) return CITY_UNKNOWN;
    if(!strcmp(c,"S?")) return SEA_UNKNOWN;
    if(!strcmp(c,"D1")) return DOUBLE_BACK_1;
    if(!strcmp(c,"D2")) return DOUBLE_BACK_2;
    if(!strcmp(c,"D3")) return DOUBLE_BACK_3;
    if(!strcmp(c,"D4")) return DOUBLE_BACK_4;
    if(!strcmp(c,"D5")) return DOUBLE_BACK_5;
    if(!strcmp(c,"HI")) return HIDE;
    if(!strcmp(c,"TP")) return TELEPORT; //teleport case
    return -1;
}

void putLocation(char *loc, LocationID *location, char *start){
    loc[0] = *start, loc[1] = *(start + 1);
    *location = abbrevToID(loc);
    if(*location == -1) *location = strToId(loc);
}

void moveArray(int arr[], int new){
    for(int i = MAX_HISTORY-1; i > 0; i--){
        arr[i] = arr[i-1];
    }

    arr[0] = new;
}

int isBeenThere(LocationID loc[], int currLoc, int max, int now){
    if(currLoc == CASTLE_DRACULA) return 0;

    for(int i = 1; i < max; i++){
        if(loc[i] == currLoc && loc[i] != now)
            return 1;
    }
    return 0;
}
/*
void playerAlloc(GameView new){
    int i = 0;
    for(i = 0; i < MAX_PLAYERS; i++)
        new->players[i] = malloc(sizeof(struct _playerView));
}

void init(GameView n){
    n->score = 366;
    n->round = 0;
    n->currentPl = PLAYER_LORD_GODALMING;
    
    int i = 0;
    int j = 0;
    
    for(i = 0; i < MAX_PLAYERS; i++){
        n->players[i]->health = 9;
        n->players[i]->location = UNKNOWN_LOCATION;
        for(j = 0; j < MAX_HISTORY; j++){
            n->players[i]->loc_history[j] = -1;
        }
    }
    n->players[MAX_PLAYERS-1]->health = 40;
}

int strToHunterHarm(GameView n,char c){
    switch(c){
        case 'T': return 2;
        case 'V': return 0;
        case 'D': {
            n->players[PLAYER_DRACULA]->health -= 10;
            return 4;
        }
        case '.': return 0;
    }
    return 0;
}

void hunterTrap(GameView v, char *start, int Player){
    char *move = start;
    int i = 0;
    int lossPoints = 0;
    for(i = 0; i < 4; i++){
        lossPoints = lossPoints + strToHunterHarm(v,*move);
        move++;
    }
    v->players[Player]->health -= lossPoints;
    if(v->players[Player]->health <= 0){
        v->players[Player]->location = abbrevToID("JM"); //move to the Hospital
        v->players[Player]->health = 9;
    }
}

void lossHealth(GameView n, int Player, char c){
    n->players[Player]->health -= strToHunterHarm(n,c);
}


void updatePlayerLocation(GameView new, int PlayerID, char *loc, char *start){
    int *player_LOC = &new->players[PlayerID]->location;
    putLocation(loc,player_LOC,start);
    moveArray(new->players[PlayerID]->loc_history,*player_LOC);
}

void doubleBack(GameView n, int back){
    //id to abbrev
    int history = n->players[PLAYER_DRACULA]->loc_history[back];
    if(validPlace(history)){
        if(idToType(history) == SEA)
            n->players[PLAYER_DRACULA]->health -= 2;
    }
    else if(!strcmp(idToAbbrev(history),"S?"))
        n->players[PLAYER_DRACULA]->health -= 2;
}

void seaAction(GameView new, char* loc, char *start){
    if(strToId(loc) == SEA_UNKNOWN || strToId(loc) == SEA)
        new->players[PLAYER_DRACULA]->health -= 2;

    else if(abbrevToID(loc) != -1){
        if(idToType(abbrevToID(loc)) == SEA)
            new->players[PLAYER_DRACULA]->health -= 2;
    }

    if(*start == 'D' && *(start + 1) >= '1' && *(start + 1) <= '5'){
        doubleBack(new,*(start+1)-'0');
    }
}*/



