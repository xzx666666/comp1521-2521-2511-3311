// removeValue.c 
// Written by Ashesh Mahidadia, August 2017

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "DLList.h"


/* 
    You will submit only this one file.

    Implement the function "removeValue" below. Read the exam paper for 
    detailed specification and description of your task.  

    - DO NOT modify code in the file DLList.h . 
    - You can add helper functions in this file.  
    - DO NOT add "main" function in this file. 
    
*/



void removeValue(DLList L, int value){
    DLListNode *curr =L->first;
    if(curr == NULL){
        return;
    
    }
    else if(curr->value<0){
        DLListNode *d = curr;
        if(curr->next ==NULL){
            L->first = NULL;
            L->last = NULL;
            L->curr = NULL;
            free(d);
        
        }
        else{
            L->first = curr->next;
            L->first->prev = NULL;
            L->curr = curr->next;
            free(d);
            removeValue(L,value);
            
        }
        L->nitems--;
    
    }
    else{
        while(curr!=NULL){
            if(curr->value<0){
                L->nitems--;
                DLListNode *delete = curr;
                if(curr == L->last){
                    L->last= L->last->prev;
                    L->last->next = NULL;
                    free(delete);
                    curr = NULL;
                }
                else{
                   
                     curr->prev->next=curr->next;
                     curr->next->prev = curr->prev;
                     free(delete);
                   
                }
            
            }
            else{
                curr=curr->next;
            
            }
        }
    
    }
    
    
	
}



