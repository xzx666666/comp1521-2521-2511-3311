// removeValue.c 
// Written by Ashesh Mahidadia, August 2017

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "DLList.h"


/* 
    You will submit only this one file.

    Implement the function "removeValue" below. Read the exam paper for 
    detailed specification and description of your task.  

    - DO NOT modify code in the file DLList.h . 
    - You can add helper functions in this file.  
    - DO NOT add "main" function in this file. 
    
*/



void removeValue(DLList L, int value){
    DLListNode *curr = L->first;
    
    if(curr == NULL || curr->next == NULL){
        return;
    
    }
    
    while(curr!=NULL){
        DLListNode *loop = curr->next;
        while(loop!=NULL){
            
            if(loop->value == curr->value){
               L->nitems--;
               DLListNode *d = curr;
               
                if(curr ==L->first){
                    L->first = L->first->next;
                    L->first->prev = NULL;
                    free(d);
                    removeValue(L, value);

                }
                
                else{
                    curr->prev->next=curr->next;
                    curr->next->prev=curr->prev;
                    curr->prev = L-> curr;
                    free(d);
                    curr = L->curr;
               
                }
                
            }
            loop = loop->next;
        }
    
         curr=curr->next;
    }
    
    
    
	
}



