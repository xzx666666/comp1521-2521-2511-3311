// removeValue.c 
// Written by Ashesh Mahidadia, August 2017

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "DLList.h"


/* 
    You will submit only this one file.

    Implement the function "removeValue" below. Read the exam paper for 
    detailed specification and description of your task.  

    - DO NOT modify code in the file DLList.h . 
    - You can add helper functions in this file.  
    - DO NOT add "main" function in this file. 
    
*/



void removeValue(DLList L, int value){
    DLListNode *curr = L->first;
   
    if(curr == NULL){
        return;
    }
    else if(curr->value == value){
        if(L->curr->next == NULL){
            L->first = NULL;
            L->last = NULL;
            L->curr = NULL;
            free(curr); 
            L->nitems--; 
        }
        else{
            L->first = curr->next;
            L->curr = curr->next;
            free(curr);
            curr = L->curr;
            curr->next->prev =NULL;
            L->nitems--;
             
        }
        removeValue(L, value);
        
    }
    
    else if(L->last->value == value){
        DLListNode *bug = L->last;
        L->last=bug->prev;
        bug->prev->next = NULL;
        
        free(bug);
        L->nitems--;
        removeValue(L, value);
    
    }
    
    
    else{
        while(curr != NULL){
            
            if(curr->value == value){
               
                curr->prev->next = curr->next;
                curr->next->prev = curr->prev;
                L->curr = curr->next;
                free(curr);
                curr = L->curr;
                L->nitems--;
                
                }
            
            else{
                curr = curr->next;
            }
           
        }
    
    
    }

	
}



