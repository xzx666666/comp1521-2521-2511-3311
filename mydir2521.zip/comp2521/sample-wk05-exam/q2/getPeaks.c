// getPeaks.c 
// Written by Ashesh Mahidadia, August 2017

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "DLList.h"


/* 
    You will submit only this one file.

    Implement the function "getPeaks" below. Read the exam paper for 
    detailed specification and description of your task.  

    - DO NOT modify code in the file DLList.h . 
    - You can add helper functions in this file.  
    - DO NOT add "main" function in this file. 
    
*/

DLList getPeaks(DLList L){
    DLListNode *curr = L->first;
	
	DLList peaksL = newDLList();
	
	if(curr == NULL|| curr->next ==NULL ||curr->next->next == NULL ){
	    return peaksL;
	
	}
	curr =curr->next;
	while(curr->next!=NULL){
	    
	    if( (curr->value<curr->prev->value) && (curr->value<curr->next->value) ){
	        
	        DLListNode *new = newDLListNode(curr->value);
	        
	        if(peaksL->nitems == 0){
	            peaksL->curr = new;
	            peaksL->first = new;
	            peaksL->last = new;
	            peaksL->nitems++;
	        }
	        else{
	            peaksL->curr->next = new;
	            peaksL->curr = peaksL->curr->next;
	            peaksL->last = peaksL->curr;
	            peaksL->nitems++;
	        }
	    
	    }
	    curr = curr->next;
	
	
	}
	
	return peaksL;

}



