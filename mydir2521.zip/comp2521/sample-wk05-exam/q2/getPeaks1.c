// getPeaks.c 
// Written by Ashesh Mahidadia, August 2017

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "DLList.h"


/* 
    You will submit only this one file.

    Implement the function "getPeaks" below. Read the exam paper for 
    detailed specification and description of your task.  

    - DO NOT modify code in the file DLList.h . 
    - You can add helper functions in this file.  
    - DO NOT add "main" function in this file. 
    
*/

DLList getPeaks(DLList L){
    DLListNode *curr = L->first;
	
	DLList peaksL = newDLList();
	
	DLListNode *this = peaksL->first;
	if(curr == NULL||curr->next == NULL||curr->next->next == NULL){
	    return peaksL;
	
	}
	curr=curr->next;
	
	while(curr->next != NULL){
            
        if((curr->prev->value<curr->value)&&(curr->next->value<curr->value)){
           
                if(peaksL->nitems == 0){
                    this = newDLListNode(curr->value);
                    peaksL->first = this;
                    peaksL->last = this;
                    peaksL->curr = this;
                    peaksL->nitems++;
                   
                    }
                else{
                    DLListNode *new = newDLListNode(curr->value);
                    peaksL->curr->next = new;
                    new->prev = peaksL->curr;
                    peaksL->last = new;
                    peaksL->curr = new;
                    peaksL->nitems++;
                }
            
        }
        curr = curr->next;
        
    }
    
	return peaksL;

}



