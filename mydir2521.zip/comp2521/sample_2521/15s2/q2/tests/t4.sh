./q2 < tests/t4.in | sort
