./q2 < tests/t5.in | sort
