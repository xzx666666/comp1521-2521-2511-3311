./q2 < tests/t8.in | sort
