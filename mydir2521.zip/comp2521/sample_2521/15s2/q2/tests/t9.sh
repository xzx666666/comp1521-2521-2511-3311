./q2 < tests/t9.in | sort
