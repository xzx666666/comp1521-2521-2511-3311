./q3 tests/graph1 6 3 | sort -n
