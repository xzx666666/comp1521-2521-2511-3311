./q3 tests/graph2 3 99 | sort -n
