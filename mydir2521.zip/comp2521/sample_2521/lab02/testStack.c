#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "Item.h"
#include "Stack.h"

//This function should contain
//tests that have access to the internal structure 
//of the stack. It should be implemented in arrayStack.c
void whiteBoxTests(void);
void stack_cycle(Stack s,int num);

int main (int argc, char *argv[]){
    printf("Black Box tests:\n");
    Stack s;
    
    whiteBoxTests();
    s = createStack();
    assert(stackSize(s)==0);
    printf("pass test1\n");
    
    stack_cycle(s,5);
    
    
    destroyStack(s);
    //etc

    return 0;
}   


void stack_cycle(Stack s,int num){
    int i;
    for(i=0;i<num;i++){
        push (s, i);
        assert(stackSize(s)==i+1);
    }
    
    printf("push %d elements test passed!\n",i);
    
    
    for(i=0;i<num;i++){
        assert(pop(s)==num-1-i);
        assert(stackSize(s)==num-i-1);
    }
    printf("pop %d elemnets test passed!\n",i);


}





    
