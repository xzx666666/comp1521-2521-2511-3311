// bst.c ... client for BSTree ADT

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "BST.h"
#include "Queue.h"
#define MAXVALS 1000
void test(treelink T,int a[],int result[],int leaves[],int odd,int even,int negative,int max);

int main(int argc, char *argv[])
{
	treelink T = NULL;
    int *p ;
    int q[6] = {5,2,6,7,8,1};
    int leaves[6] = {1,1,2,2,2,2};
    int result[6] = {5,2,6,1,7,8};
	int odd = 3;
	int even = 3;
	int negative = 0;
	int max = 6;
	
    printf("test1\n");
    test(T,q,result,leaves,odd,even,negative,max);
	
	printf("Test1 passed\n");
	//////////////////
	treelink t0 = NULL;
	 int *p1 ;
     int q1[6] = {1,2,-3,4,5,6};
     int leaves1[6] = {1,1,2,2,2,2};
     int result1[6] = {1,-3,2,4,5,6};
	 odd = 3;
	 even = 3;
	 negative = 1;
	 max = 6;
	
    printf("test2\n");
    test(t0,q1,result1,leaves1,odd,even,negative,max);
	
	printf("Test2 passed\n");
	
	return 0;
}
void test(treelink T,int q[],int result[],int leaves[],int odd,int even,int negative,int max){
    
    int *p ;
    
	int i=0;
	int num;
    /*
    build tree link that 5
                        /\
                       2  6    
                      /\  /\
                     1      7
                            \
                            8
    */
    
    for(i=0;i<max;i++){
	    T = insertTreeNode(T,q[i]);//add 5 2 6 7 8 1
	    num = countLeaves(T);
	    assert(num ==leaves[i]);
	}
	
	p = levelOrderTraversal(T); 
	for(i=0;i<max;i++){
	    assert(p[i]==result[i]);
	
	}
	assert(countIf(T,isEven) == even);
    
    assert(countIf(T,isOdd) == odd);
    
    assert(countIf(T,isNegative) == negative);


}

