#include "isMinHeap.h"
#include <stdio.h>
//To compile, run and test
//gcc -Wall -Werror -O -std=c99 -o testIsMinHeap testIsMinHeap.c isMinHeap.c


//return 1 if the array heap with a sepcified number of items is in heap order 
//You must assume that the heap items are in indexes 1..heapSize and that index 0 
//is empty and not used to store items.
int isMinHeap(int heap[], int heapSize){
    int i =0;
    for(i=0;i<heapSize;i++){
        
        if((2*i+2)<=heapSize){
            if(heap[i] > heap[2*i + 1] || heap[i] > heap[2*i + 2]){
            
                return 0;
            }
          
        }
        if((2*i+1) <= heapSize){
            if(heap[i]>heap[2*i+1]) {
            
                return 0;
            }
        }
        
        
    }
    return 1;
}
