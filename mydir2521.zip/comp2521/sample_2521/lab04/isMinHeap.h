int isMinHeap(int heap[], int heapSize);
