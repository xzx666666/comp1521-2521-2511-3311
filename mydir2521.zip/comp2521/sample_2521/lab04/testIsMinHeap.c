#include <assert.h>
#include <stdio.h>

#include "isMinHeap.h"

void testValidMinHeaps(int num[],int size);
void testInvalidMinHeaps(int num[],int size);

int main(int argc, char * argv[]){
    //Stops output being buffered, so we get all printf output
    //before program crashes/aborts etc
    setbuf(stdout, NULL);
    int heap[10];
    int i=0;
    for(i=0;i<10;i++){
        heap[i] = i;
    }
    testValidMinHeaps(heap,9);//0 1 2 3 4 5 6 7 8 9
    heap[9] = 8;
    heap[8] = 9;//0 1 2 3 4 5 6 7 9 8
    testValidMinHeaps(heap,9);
    
    for(i = 5;i<8;i++){
        heap[i] = 1;
    
    }
    
    testInvalidMinHeaps(heap,9);//0 1 2 3 4 1 1 1 9 8 
    
    
    return 0;
}


void testValidMinHeaps(int num[],int size){
    
    printf("Test 1: Some valid heaps\n");
    assert(isMinHeap(num,size));
    printf("passed\n");

    //ADD MORE TESTS HERE
}

void testInvalidMinHeaps(int num[],int size){
     
     printf("Test Invalid heap\n");
     assert(!isMinHeap(num,size));
     printf("passed\n");

     //ADD MORE TESTS HERE
}
