#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "isMinHeapOrdered.h"

void testIsMinHeapOrderedTrue(void);
void testIsMinHeapOrderedFalse(void);
Link newnode(int num);

int main (int argc, const char * argv[]) {
    //Stops output being buffered, so we get all printf output
    //before program crashes/aborts etc
   setbuf(stdout, NULL);
   testIsMinHeapOrderedTrue();
   testIsMinHeapOrderedFalse();

   printf ("All tests passed!\n");
  
   return EXIT_SUCCESS;
}


void testIsMinHeapOrderedTrue (void) {
   
   Link newNode1,newNode2,newNode3,newNode4,newNode6,newNode7,newNode8,newNode9,newNode10,newNode11,newNode12,newNode5;
   Link newTree = NULL;
   printf("Tests for trees that are heap ordered\n");
   printf("Test ture heap 1 : Empty tree\n");
   
   assert(isMinHeapOrdered(newTree));
   printf("Passed\n");

   newTree = newnode(9);
   
   newNode1 = newnode(15);
   newNode2 = newnode(11);
   newNode3 = newnode(20);
   newNode4 = newnode(21);
   newNode5 = newnode(22);
   newNode6 = newnode(23);
   newNode7 = newnode(24);
   newTree->left = newNode1;
   newTree->right = newNode2;
   
   newNode1->left = newNode3;
   newNode1->right = newNode4;
   
   newNode2->left = newNode5;
   newNode2->right = newNode6;
   
   newNode3->left = newNode7;
   
   printf("Test ture heap 2 \n");
   assert(isMinHeapOrdered(newTree)); 
   printf("Passed\n");

   newNode8 = newnode(34);
   newNode9 = newnode(35);
   newNode10 = newnode(36);
   
   newNode11 = newnode(45);
   newNode12 = newnode(46);
   
   newNode3->right = newNode8; 
   
   newNode4->left = newNode9;
   newNode4->right = newNode10;
   
   newNode5->left = newNode11;
   newNode5->right = newNode12;
   
   printf("Test ture heap 3 \n");
   assert(isMinHeapOrdered(newTree) );
   printf("Passed\n");
   
   free(newNode1);
   free(newNode2);
   free(newNode3);
   free(newNode4);
   free(newNode5);
   free(newNode6);
   free(newNode7);
   free(newNode8);
   free(newNode9);
   free(newNode10);
   free(newNode11);
   free(newNode12);
   free(newTree);

}

void testIsMinHeapOrderedFalse (void) {

 
   Link newTree = NULL;
   printf("Tests for trees that are not heap ordered\n");
   Link newNode1,newNode2,newNode3,newNode4,newNode6,newNode7,newNode8,newNode9,newNode10,newNode11,newNode12,newNode5;
  
   
   assert(isMinHeapOrdered(newTree));
   printf("Passed\n");

   newTree = newnode(9);
   
   newNode1 = newnode(6);
   newNode2 = newnode(17);
   newNode3 = newnode(20);
   newNode4 = newnode(21);
   newNode5 = newnode(22);
   newNode6 = newnode(23);
   newNode7 = newnode(24);
   newTree->left = newNode1;
   newTree->right = newNode2;
   
   newNode1->left = newNode3;
   newNode1->right = newNode4;
   
   newNode2->left = newNode5;
   newNode2->right = newNode6;
   
   newNode3->left = newNode7;
   
   newNode8 = newnode(34);
   newNode9 = newnode(35);
   newNode10 = newnode(36);
   
   newNode11 = newnode(45);
   newNode12 = newnode(46);
   
   newNode3->right = newNode8; 
   
   newNode4->left = newNode9;
   newNode4->right = newNode10;
   
   newNode5->left = newNode11;
   newNode5->right = newNode12;
   
   printf("Test false heap 3 \n");
   assert(!isMinHeapOrdered(newTree) );
   printf("Passed\n");
   
   free(newNode1);
   free(newNode2);
   free(newNode3);
   free(newNode4);
   free(newNode5);
   free(newNode6);
   free(newNode7);
   free(newNode8);
   free(newNode9);
   free(newNode10);
   free(newNode11);
   free(newNode12);
   free(newTree);

  
}
Link newnode(int num){
    Link new  = malloc(sizeof(struct node));
    new->item = num;
    new->left = NULL;
    new->right = NULL;
    return new;

}



