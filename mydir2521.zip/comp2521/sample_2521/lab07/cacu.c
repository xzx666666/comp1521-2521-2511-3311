#include<stdio.h>
int main(void){
    int i;
    double n;
    double sum_a =0.0,sum_b=0.0,sum_c=0.0,sum_d=0.0,sum_e=0.0;
    for(i=0;i<25;i++){

        scanf("%lf",&n);
        if(i%5==0){
            sum_a = n+sum_a;
        }
        if(i%5==1){
            sum_b = n+sum_b;
        }
        if(i%5==2){
            sum_c = n+sum_c;
        }
        if(i%5==3){
            sum_d = n+sum_d;
        }
        if(i%5==4){
            sum_e = n+sum_e;
        }
        
    
    }
    printf("size 2 M %lf\n",sum_a/5.0);
    printf("size 4 M %lf\n",sum_b/5.0);
    printf("size 6 M %lf\n",sum_c/5.0);
    printf("size 8 M %lf\n",sum_d/5.0);
    printf("size 10 M %lf\n",sum_e/5.0);
    
    return 0;

}
