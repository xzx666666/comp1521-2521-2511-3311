#include<stdio.h>
int main(void){
    int i;
    double n;
    double sum_a =0.0,sum_b=0.0,sum_c=0.0;//sum_e=0.0;
    for(i=0;i<15;i++){

        scanf("%lf",&n);
        if(i<5){
            sum_a = n+sum_a;
        }
        if(i>=5&&i<10){
            sum_b = n+sum_b;
        }
        if(i>=10){
            sum_c = n+sum_c;
        }
        
        
    
    }
    printf("size 10000* %lf\n",sum_a/5.0);
    printf("size 20000* %lf\n",sum_b/5.0);
    printf("size 50000* %lf\n",sum_c/5.0);
    //printf("size 70000* %lf\n",sum_d/5.0);
    //printf("size 10 M %lf\n",sum_e/5.0);
    
    return 0;

}
