#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define STATE_MAX 5

#define SIZE_MAX 3
#define PAR_SIZE 6
#define TIMES 5

//void quickSort(int items[],int l, int r);
void quickSort(int a[], int l, int r, int arg, int M);
void quickSortMT(int items[],int l, int r);
void quickSortRD(int *, int, int);
void swap(int index1, int index2, int items[]);
int partition(int a[], int l, int r);
int partitionRD(int a[], int l, int r);
void printArr(int *arr, int size,int);
void insertionSort(int a[], int l, int r);
void otherQuickSort(int *a, int, int ,int);
void anotherQuickSort(int *, int, int, int);
int other(int argc, char** argv);

double avrg[100] = {0};
int move = 0;
FILE *out;
/*
struct stable{
    int num;
    int order;
};

void randData(struct stable *s, int size){
    int i = 0;
    srand(time(NULL));
    for(;i < size; i++){
        s[i].num = rand() % size;
        s[i].order = i;
    }
}
*/

/*
int isOrdered(int arr[], int l, int r){
    if(l >= r) return 1;
    if(r - l == 1){
        if(arr[l] > arr[r]) return 0;
        else return 1;
    }
    int mid = (l + r) / 2;
    return isOrdered(arr,l,mid) && isOrdered(arr,mid,r);
}*/


/*void genData(int arr[], int size){
    int i = 0;
    srand(time(0));
    for(i = 0; i < size; i++){
        arr[i] = rand() % size;
    }
}
*/
int main(){
    out = fopen("result.txt","w");
    char *s = "./a.out";
    char *state[STATE_MAX] = {"-pn", "-pm", "-pr","-sa","-sb"};
    char *parSize[PAR_SIZE] = {"2","4","6","8","10"};
    //char *test[SIZE_MAX] = {"100000", "1000000", "2000000", "5000000", "10000000"};
    int times = 0;
    char *test[SIZE_MAX] = {"10000","20000","50000"};
    int i = 0, j = 0, k = 0;
    for(i = 0; i < STATE_MAX; i++){
        for(j = 0; j < SIZE_MAX; j++){
            for(times = 0; times < TIMES; times++){
                printf("state %s test %s times %d\n",state[i],test[j], times);
                fprintf(out, "state %s test %s times %d\n",state[i],test[j], times);

                if(state[i][1] != 's')
                    k = PAR_SIZE;
                else k = 0;
                    
                do{
                    char* test_main[4];
                    test_main[0] = s;
                    if(state[i][1] == 's'){
                        printf("test in M size %d\n",atoi(parSize[k]));
                        fprintf(out, "test in M size %d\n",atoi(parSize[k]));
                        int len1 = strlen(state[i]), len2 = strlen(parSize[k]);
                        char *c = malloc(len1 + len2 + 1);
                        strcpy(c, state[i]); strcat(c,parSize[k]);
                        test_main[1] = c;
                    }
                    else
                        test_main[1] = state[i];
                        
                    test_main[2] = "-q";
                    test_main[3] = test[j];
                    other(4,test_main);
                    k++;
                }while(k < PAR_SIZE-1);
                printf("\n");
            }
        }
    }

    //other(4,"./a.out -pn -q 10000");
    return 0;
}

int other(int argc, char **argv){
    if(argc < 2){
        fprintf(stderr, "Usage: ./sort -p<r/m/n> <-q>\n");
        exit(1);
    }
    int i,size,arg;
    clock_t  begin, end;
    if(argc == 4)
        size = atoi(argv[3]);
    //printf("size = %d\n",size);
    //printf("Enter number of elements:");
    //scanf("%d",&size);
    int * a = malloc(size * sizeof(int));
    //int * stab = malloc(size * sizeof(int));
    /*
    for(i = 0; i < size; i++){
        stab[i] = i;
    }*/
    //printf("Enter elements:\n");
    /*
    for(i = 0;i < size;i++)
	    scanf("%d",&a[i]);
    */
    //struct stable *arr = malloc(sizeof(struct stable));
    //genData(a,size);
    
    for(i = 0; i < size; i++){
        a[i] = size-i;
    }   //ordered
/*
    for(i = 0; i < size; i++){
        a[i] = size - i - 1;
    }
*/   //reversed
    //randData(arr,size);
    
    arg = argv[1][2];
    if(argv[1][2] == 'm'){
        begin = clock();
        quickSortMT(a,0,size-1);
        end = clock();
    }
    else{
        if(argv[1][1] != 's'){
            begin = clock();
            quickSort(a,0,size-1,argv[1][2],0);
            end = clock();
        }
        else{
            begin = clock();
            char* c = &argv[1][3];
            quickSort(a,0,size-1,argv[1][2], atoi(c));
            if(argv[1][2] == 'b') insertionSort(a, 0, size-1);
            end = clock();
        }
    }
    double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
    //avrg[move] = time_spent;
    //move++;

    if(argc < 3)
        printArr(a, size, arg);

    else if(argv[2][1] != 'q')
        printArr(a, size, arg);
    else
        printArr(a,0,arg);

    printf("time spent: %f\n",time_spent);
    fprintf(out,"time spent: %f\n",time_spent);
    free(a);
    return 0;
}


void printArr(int *arr, int size, int arg){
    if(arg == 'n')
        printf("Sorted with naive piviot");
    else if(arg == 'm')
        printf("Sorted with median of three pivot");
    else if(arg == 'r')
        printf("Sorted with randomised piviot");
    else
        printf("Other sort");
    printf("\n");
    if(size == 0)
        return;
    int i = 0;
    for(i = 0; i < size; i++)
        printf("%d ",arr[i]);
    printf("\n");
    fprintf(out,"\n");
}

void quickSort(int a[], int l, int r, int arg, int M){
    int i;
    if(r <= l)
        return;
    switch(arg){
        case 'n':{
            i = partition(a,l,r);
            break;
        }
        case 'r':{
            i = partitionRD(a,l,r);
            break;
        }
        case 'a':{
            if(r - l < M){
                insertionSort(a,l,r);
                return;
            }
            else
                i = partition(a,l,r);
            break;
        }
        case 'b':{
            if(r - l < M)
                return;
            else   
                i = partition(a,l,r);
            break;
        }
    }
    quickSort(a,l,i-1,arg,M);
    quickSort(a,i+1,r,arg,M);
}

void quickSortMT(int a[], int l, int r){         	
   int i;  
   if  (r <= l) {
       return;
   } 
   if(r-l > 1){
       int mid = (r+l)/2;

       swap(r-1,mid,a);
       if(a[r-1] < a[l]){
           swap(r-1,l,a);
       }
       if(a[r] < a[l]){
           swap(r,l,a);
       }
       if(a[r] < a[r-1]){
           swap(r,r-1,a);
       }
     
       i = partition(a,l+1,r-1);
   } else {
       i = partition(a,l,r);  
   }  
 
   quickSortMT (a, l, i-1);  
   quickSortMT (a, i+1, r);
}

int partition (int a[], int l, int r) {   
   int i = l-1;
   int j = r;   
   int pivot = a[r]; //rightmost is pivot  	
   for(;;){   
        while ( a[++i] < pivot);
        while ( pivot <  a[--j] && j != l);
        if (i >= j) { 
            break;
        }
        swap(i,j,a);  
    }
    //put pivot into place  
    swap(i,r,a);  
    return i; //Index of the pivot
}

int partitionRD (int a[], int l, int r){
    srand(time(NULL));
    int inx = l + rand() % (r-l+1);
    int pivot = a[inx];
    int i = l - 1, j = l;
    swap(inx,r,a);
    inx = r;
    for(j;j < r; j++){
        if(a[j] <= pivot){
            i = i + 1;
            swap(i,j,a);
        }
    }
    swap(inx,i+1,a);
    return i+1;
}

void swap(int index1, int index2, int items[]){
    int tmp;
    tmp = items[index1];
    items[index1] = items[index2];
    items[index2] = tmp;
}

/*
void otherQuickSort(int a[], int l, int r, int M){
    if(r <= l)
        return;
    if(r - l < M){
        insertionSort(a,l,r);
        return;
    }
    int i = partition(a,l,r);
    otherQuickSort(a,l,i-1,M);
    otherQuickSort(a,i+1,r,M);
}

void anotherQuickSort(int a[], int l, int r, int M){
    if(r <= l)
        return;
    if(r - l < M){
        return;
    }
    int i = partition(a,l,r);
    otherQuickSort(a,l,i-1,M);
    otherQuickSort(a,i+1,r,M);
}*/

void insertionSort(int a[], int l, int r){
    int max = a[l], i = l+1;
    for(; i <= r; i++){
        if(a[i] > max) max = a[i];
        
        else if(a[i] < max){
            int j = i, key = a[i];
            while(j > l){
                a[j] = a[j-1];
                j--;
                if(j > l){
                    if(a[j-1] < key){
                        a[j] = key;
                        break;
                    }
                }
                else a[l] = key;
            }
        }
    }
}


