void quickSort(int items[],int l, int r);
void swap(int index1, int index2, int items[]);
int partition(int a[], int l, int r);
void quickSortMT(int items[],int l, int r);
