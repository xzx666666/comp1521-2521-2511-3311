
/* hasPath.c 
   Written by Ashesh Mahidadia, October 2017
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "Graph.h"



/* 
    You will submit only this one file.

    Implement the function "hasPath" below. Read the exam paper for 
    detailed specification and description of your task.  

    - You can add helper functions in this file, if required.  

    - DO NOT modify code in the file BSTree.h . 
    - DO NOT add "main" function in this file. 
*/

int sea(Graph g,Vertex src,Vertex dest);
int *visited;  // array of visited


int hasPath(Graph g, Vertex src, Vertex dest)
{
   visited = malloc(g->nV*sizeof(int));
   int n;
   for(n=0;n<g->nV;n++){
        visited[n]=0;    
   }
	// Implement this function, 
	// also change the return value below!
    return sea(g,src,dest);
}
int sea(Graph g,Vertex src,Vertex dest){
    Vertex v;
    for(v=0;v<g->nV;v++){
        if(adjacent(g,src,v))continue;
           
        visited[v]=1;
        if(v==dest)return 1;
        
        else if (sea(g,v,dest))return 1;
    
    }

    return 0;

}

